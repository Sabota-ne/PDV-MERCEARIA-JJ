
import React, { useState, useEffect, useCallback } from "react";

// ── Storage helpers ──────────────────────────────────────────────
const STORAGE_KEY = "pdv_data_v1";

const defaultData = {
  produtos: [
    { id: 1, nome: "Coca-Cola 350ml", preco: 5.5, estoque: 48, categoria: "Bebidas", custo: 3.2, estoqueMin: 10 },
    { id: 2, nome: "Pão Francês", preco: 0.75, estoque: 120, categoria: "Padaria", custo: 0.4, estoqueMin: 20 },
    { id: 3, nome: "Arroz 5kg", preco: 28.9, estoque: 30, categoria: "Mercearia", custo: 18.0, estoqueMin: 5 },
    { id: 4, nome: "Feijão 1kg", preco: 9.5, estoque: 45, categoria: "Mercearia", custo: 6.0, estoqueMin: 5 },
    { id: 5, nome: "Leite Integral 1L", preco: 6.8, estoque: 60, categoria: "Laticínios", custo: 4.5, estoqueMin: 10 },
  ],
  clientes: [
    { id: 1, nome: "João Silva", telefone: "11999990001", limite: 200, saldo: 45.5, endereco: "", obs: "", aniversario: "" },
    { id: 2, nome: "Maria Santos", telefone: "11999990002", limite: 300, saldo: 0, endereco: "", obs: "", aniversario: "" },
  ],
  vendas: [],
  compras: [],
  fornecedores: [],
  fiado: [],
  perdas: [],
  taxas: { pix: 0, credito: 3.5, debito: 1.5 },
  nextId: { produto: 6, cliente: 3, venda: 1, compra: 1, fiado: 1, fornecedor: 1, perda: 1 },
};

// ── Backup do usuário — carregado se localStorage estiver vazio ──
const USER_BACKUP = {"produtos":[{"id":1,"nome":"Coca-Cola 350ml Original ","preco":5,"estoque":12,"categoria":"Bebidas","custo":3.19,"barcode":"7894900010015","imagem":""},{"id":3,"nome":"Arroz Camil 5KG","preco":22,"estoque":2,"categoria":"Mercearia","custo":15,"barcode":"7896006711155","imagem":""},{"id":6,"nome":"Leite Condensado Moça","preco":9,"custo":5.36,"estoque":30,"categoria":"Laticínios","barcode":"7898215152002","imagem":""},{"id":7,"nome":"Mistura Lactea Condensada MOCOCA 395G","preco":6.5,"custo":3.19,"estoque":28,"categoria":"Laticínios","barcode":"7891030300207","imagem":""},{"id":8,"nome":"BOMBOM WAFER LACTA OURO BRANCO ","preco":2,"custo":0.89,"estoque":28,"categoria":"DOCES","barcode":"78939318","imagem":""},{"id":9,"nome":"BOMBOM WAFER SONHO DE VALSA","preco":2,"custo":0.89,"estoque":25,"categoria":"DOCES","barcode":"78939301","imagem":""},{"id":10,"nome":"Milho Verde Predilecta 200g","preco":4.5,"custo":2.99,"estoque":23,"categoria":"Mercearia","barcode":"7896292340503","imagem":""},{"id":11,"nome":"ERVILHA PREDILECTA","preco":4.5,"custo":2.99,"estoque":23,"categoria":"Mercearia ","barcode":"3799034640326","imagem":""},{"id":12,"nome":"Macarrão Instantâneo Lámen Galinha Caipira Nissin Miojo 85g","preco":3.5,"custo":2.08,"estoque":21,"categoria":"Mercearia","barcode":"7891079000229","imagem":""},{"id":13,"nome":"Extrato de Tomate Elefante Trad 300G","preco":8.75,"custo":5.81,"estoque":21,"categoria":"Mercearia ","barcode":"7896036000717","imagem":""},{"id":14,"nome":"Creme de Leite Piracanjuba 200g","preco":3.95,"custo":2.59,"estoque":14,"categoria":"Laticínios","barcode":"7898215151784","imagem":""},{"id":15,"nome":"Velho Carreiro Cachaça 500ML","preco":4,"custo":2.29,"estoque":13,"categoria":"Bebidas","barcode":"7898312690001","imagem":""},{"id":16,"nome":"Catchup Val 400G Trad","preco":9.2,"custo":5.17,"estoque":12,"categoria":"Mercearia ","barcode":"7898045700466","imagem":""},{"id":17,"nome":"Mistura de Leite Mococa 200g creme","preco":2.85,"custo":1.79,"estoque":12,"categoria":"Laticínios","barcode":"7891030300306","imagem":""},{"id":18,"nome":"Farinha de Trigo Dona Benta 1KG","preco":7,"custo":4.866,"estoque":10,"categoria":"Mercearia ","barcode":"7896005202074","imagem":""},{"id":19,"nome":"Macarrão Renata Espaguete ","preco":5,"custo":3.5,"estoque":9,"categoria":"Mercearia ","barcode":"7896022200282","imagem":""},{"id":20,"nome":"Sal Refinado Marinho Lebre 1kg","preco":4,"custo":2.19,"estoque":9,"categoria":"Mercearia","barcode":"7896110100043","imagem":""},{"id":21,"nome":"Macarrão Instantâneo Apti Galinha 70g","preco":2.5,"custo":0.89,"estoque":8,"categoria":"Mercearia","barcode":"7896327514558","imagem":""},{"id":22,"nome":"Pipoca kisabor Natural ","preco":4,"custo":2.65,"estoque":7,"categoria":"Mercearia ","barcode":"","imagem":""},{"id":23,"nome":"Cominho Em Pó Da Terrinha","preco":5,"custo":3.5,"estoque":7,"categoria":"Mercearia ","barcode":"7896046580919","imagem":""},{"id":24,"nome":"Macarrão Instantâneo Lámen Carne Nissin Miojo Pacote 85g","preco":3.5,"custo":2.32,"estoque":6,"categoria":"Mercearia","barcode":"7891079000205","imagem":""},{"id":25,"nome":"Arroz São João 1KG","preco":6.5,"custo":5.5,"estoque":6,"categoria":"Mercearia ","barcode":"4896016003366","imagem":""},{"id":26,"nome":"Toddy em Pó 370g","preco":13.5,"custo":8.86,"estoque":5,"categoria":"Mercearia ","barcode":"7892840819507","imagem":""},{"id":27,"nome":"Nescau 350","preco":13.5,"custo":8.64,"estoque":5,"categoria":"Mercearia ","barcode":"15576432","imagem":""},{"id":28,"nome":"Café Caboclo 250G","preco":17.5,"custo":12,"estoque":4,"categoria":"Mercearia ","barcode":"5564089011203","imagem":""},{"id":29,"nome":"Sal Grosso Cisne 1KG","preco":6,"custo":4.09,"estoque":5,"categoria":"Mercearia ","barcode":"907035786018","imagem":""},{"id":30,"nome":"Açúcar da Barra Ref 1KG","preco":5,"custo":3,"estoque":3,"categoria":"Mercearia ","barcode":"040405643921","imagem":""},{"id":31,"nome":"Óleo de Soja Soya 800ML","preco":9.65,"custo":7,"estoque":5,"categoria":"Mercearia ","barcode":"7891107101621","imagem":""},{"id":32,"nome":"Salgadinho Bacon Fritop 200G ","preco":8.99,"custo":5.75,"estoque":5,"categoria":"Salgadinhos","barcode":"7820126322380","imagem":""},{"id":33,"nome":"Macarrão Galo Espaguete","preco":5,"custo":3.5,"estoque":5,"categoria":"Mercearia ","barcode":"7896022204082","imagem":""},{"id":34,"nome":"Macarrão de semôla Todeschini ","preco":4,"custo":2.39,"estoque":5,"categoria":"Mercearia ","barcode":"7896022206031","imagem":""},{"id":35,"nome":"Salgadinho Requeijão Fritop 200G","preco":8.99,"custo":5.75,"estoque":5,"categoria":"Salgadinhos","barcode":"7898026322373","imagem":""},{"id":36,"nome":"Cheetos Parmesão 143G","preco":16.99,"custo":9.99,"estoque":3,"categoria":"Salgadinhos","barcode":"7892840822736","imagem":""},{"id":37,"nome":"Sazon Massas ","preco":7.5,"custo":5.6,"estoque":4,"categoria":"Temperos","barcode":"","imagem":""},{"id":38,"nome":"Maionese Helmmans 500G","preco":12.75,"custo":8.6,"estoque":4,"categoria":"Mercearia ","barcode":"7894000050034","imagem":""},{"id":39,"nome":"Molho de Pimenta  Gota Marata 150ML","preco":4.4,"custo":2.75,"estoque":2,"categoria":"Mercearia ","barcode":"7898286190316","imagem":""},{"id":40,"nome":"Pringles Original 109G","preco":15.99,"custo":8.5,"estoque":4,"categoria":"Salgadinhos ","barcode":"9599460006277","imagem":""},{"id":41,"nome":"Sazon Carnes","preco":7.5,"custo":5.6,"estoque":4,"categoria":"Temperos","barcode":"7891132019281","imagem":""},{"id":42,"nome":"Macarrão Instantâneo Galinha Nissin","preco":3.5,"custo":2.33,"estoque":3,"categoria":"Mercearia ","barcode":"7891079000212","imagem":""},{"id":43,"nome":"Café Moraes 500G","preco":32.5,"custo":21.99,"estoque":2,"categoria":"Mercearia ","barcode":"7896235100027","imagem":""},{"id":44,"nome":"Pitu Lata 350ML","preco":8,"custo":4.65,"estoque":5,"categoria":"Bebidas","barcode":"7896607100044","imagem":""},{"id":45,"nome":"Feijão Preto Camil 1KG ","preco":7.6,"custo":6.09,"estoque":3,"categoria":"Mercearia ","barcode":"7896006751113","imagem":""},{"id":46,"nome":"Feijão Carioca Tipo1 Camil","preco":9.5,"custo":7.89,"estoque":3,"categoria":"Mercearia ","barcode":"7896006744115","imagem":""},{"id":47,"nome":"Milho Verde Quero em conserva","preco":4.5,"custo":2.99,"estoque":3,"categoria":"Mercearia ","barcode":"7896102500608","imagem":""},{"id":48,"nome":"Maionese Helmmans 250G","preco":9.25,"custo":7.39,"estoque":2,"categoria":"Mercearia ","barcode":"7894000050027","imagem":""},{"id":49,"nome":"Colorifico Temp Kisabor Coloral","preco":3.5,"custo":2.29,"estoque":1,"categoria":"Temperos","barcode":"7898416523366","imagem":""},{"id":50,"nome":"Pringles Cebola e Salsa 109G","preco":16.99,"custo":8.5,"estoque":1,"categoria":"Salgadinhos","barcode":"556400006239","imagem":""},{"id":51,"nome":"Batata Ruffles 134G","preco":16.99,"custo":9.99,"estoque":1,"categoria":"Salgadinhos ","barcode":"","imagem":""},{"id":52,"nome":"Cheetos Requeijão 160G","preco":16.99,"custo":9.99,"estoque":1,"categoria":"Salgadinhos ","barcode":"7892840822323","imagem":""},{"id":53,"nome":"Vinagre Álcool Vitalia ","preco":3.25,"custo":2.2,"estoque":2,"categoria":"Mercearia ","barcode":"7896048284792","imagem":""},{"id":54,"nome":"Feijão Carioca Biguá 1KG","preco":7.5,"custo":6.5,"estoque":1,"categoria":"Mercearia ","barcode":"7898008920191","imagem":""},{"id":55,"nome":"Leite Moça Lata 395G","preco":11.4,"custo":8.48,"estoque":1,"categoria":"Mercearia ","barcode":"7891000100103","imagem":""},{"id":56,"nome":"Macarrão Espaguete Todeschini ","preco":4.5,"custo":2.39,"estoque":8,"categoria":"Mercearia ","barcode":"7896022205775","imagem":""},{"id":57,"nome":"Mostarda Cepera 200G","preco":8,"custo":4.49,"estoque":5,"categoria":"Mercearia ","barcode":"7896025802308","imagem":""},{"id":58,"nome":"Azeitona Vale Fértil 160G","preco":5,"custo":2.5,"estoque":5,"categoria":"Mercearia ","barcode":"7896272000496","imagem":""},{"id":59,"nome":"Cigarro EGT","preco":7,"custo":4,"estoque":30,"categoria":"Fumo","barcode":"78400924","imagem":""},{"id":60,"nome":"Molho de Tomate Tradicional Predilecta Sachê 300g","preco":2.6,"custo":1.29,"estoque":5,"categoria":"Mercearia","barcode":"7896292333000","imagem":""},{"id":61,"nome":"Nissin Cup Noodles Costela com Molho de Churrasco 68g","preco":7.9,"custo":5.5,"estoque":4,"categoria":"Mercearia","barcode":"7891079013083","imagem":""},{"id":62,"nome":"Molho Sabor Catchup D Lanche 200g","preco":3.3,"custo":2.3,"estoque":2,"categoria":"Mercearia","barcode":"7898946867077","imagem":""},{"id":63,"nome":"Caldo Tablete Galinha Maggi  57g 6 Unidades","preco":4,"custo":2.8,"estoque":15,"categoria":"Mercearia","barcode":"7891000250174","imagem":""},{"id":64,"nome":"Tempero Arisco Alho e Sal 300g","preco":10.7,"custo":7.49,"estoque":6,"categoria":"Mercearia","barcode":"7891700012102","imagem":""},{"id":65,"nome":"Sardinha Coqueiro com Óleo 125g","preco":8.6,"custo":4.91,"estoque":3,"categoria":"Mercearia","barcode":"7896009301049","imagem":""},{"id":66,"nome":"Sardinha Palmeira em Óleo 125g","preco":7.5,"custo":4.5,"estoque":7,"categoria":"Mercearia","barcode":"7896117100350","imagem":""},{"id":67,"nome":"Canela Em Casca Da Sabor ","preco":2.99,"custo":1.79,"estoque":8,"categoria":"Especiarias ","barcode":"7896746901212","imagem":""},{"id":68,"nome":"Sardinha Sulpesca em Lata 125G","preco":7.5,"custo":4.5,"estoque":3,"categoria":"Mercearia ","barcode":"7896117101043","imagem":""},{"id":69,"nome":"Mostarda e Mel Kisabor 240ML","preco":9,"custo":6.3,"estoque":5,"categoria":"Mercearia ","barcode":"7898416524486","imagem":""},{"id":70,"nome":"Gelatina Dr.Oetker Fini Beijos","preco":3,"custo":1.6,"estoque":3,"categoria":"Mercearia ","barcode":"7891048084526","imagem":""},{"id":71,"nome":"Gelatina Cereja Dr.Oetker","preco":3,"custo":1.6,"estoque":3,"categoria":"Mercearia ","barcode":"7891048050620","imagem":""},{"id":72,"nome":"Mini Bolo Brigadeiro Animal","preco":2,"custo":1.19,"estoque":15,"categoria":"Doces","barcode":"7896064202381","imagem":""},{"id":73,"nome":"Mini Bolo Marshmallow y Morango Animal","preco":2,"custo":1.19,"estoque":15,"categoria":"Doces","barcode":"7896064205542","imagem":""},{"id":74,"nome":"Molho de Tomate Trad Fugini 300G","preco":2.6,"custo":1.29,"estoque":36,"categoria":"Mercearia ","barcode":"7897517206086","imagem":""},{"id":75,"nome":"Colorífico 97G Marata","preco":2.6,"custo":1.29,"estoque":10,"categoria":"Mercearia ","barcode":"7898617582285","imagem":""},{"id":76,"nome":"Bebida Láctea Shefa Chocolate 200ml","preco":3,"custo":1.05,"estoque":25,"categoria":"Bebidas","barcode":"7896185310910","imagem":"","codigo":""},{"id":77,"nome":"Salgadinho de Milho Doritos Queijo Nacho 120g","preco":15.99,"custo":9.99,"estoque":2,"categoria":"Snacks","barcode":"7892840822446","imagem":""},{"id":78,"nome":"Gelatina Dr. Oetker Morango 20g","preco":3,"custo":1.59,"estoque":3,"categoria":"Mercearia","barcode":"7891048050668","imagem":"","codigo":""},{"id":79,"nome":"Apti Mistura para Bolo Festa 400g","preco":6.5,"custo":3.49,"estoque":3,"categoria":"Mercearia","barcode":"7896327501398","imagem":"","codigo":""},{"id":80,"nome":"Mistura para Bolo Apti Sabor Limão 400g","preco":6.5,"custo":3.49,"estoque":3,"categoria":"Mercearia","barcode":"7896327510772","imagem":"","codigo":""},{"id":81,"nome":"Leite Ninho 380G Integral Instantâneo ","preco":25.5,"custo":17.85,"estoque":3,"categoria":"Mercearia ","barcode":"2458000393284","imagem":"","codigo":""},{"id":82,"nome":"Leite Ninho Integral","preco":25.5,"custo":17.85,"estoque":1,"categoria":"Mercearia ","barcode":"7891000325858","imagem":"","codigo":""},{"id":83,"nome":"Leite em pó 200G Piracanjuba Integal ","preco":9.5,"custo":6.28,"estoque":3,"categoria":"Mercearia ","barcode":"6636100376192","imagem":"","codigo":""},{"id":84,"nome":"Leite em Pó Piracanjuba 400G Integral ","preco":17,"custo":11.23,"estoque":2,"categoria":"Mercearia ","barcode":"7898215152347","imagem":"","codigo":""},{"id":85,"nome":"Leite Em Pó Merilú 400G","preco":10,"custo":5.6,"estoque":2,"categoria":"Mercearia ","barcode":"7898239260745","imagem":"","codigo":""},{"id":86,"nome":"Meu Papá Ceral Arroz Infantil 180G","preco":8,"custo":5.49,"estoque":3,"categoria":"Mercearia ","barcode":"7898080642820","imagem":"","codigo":""},{"id":87,"nome":"Meu Papa Ceral Milho Infantil 180G","preco":8,"custo":5.49,"estoque":2,"categoria":"Mercearia ","barcode":"1280744642813","imagem":"","codigo":""},{"id":88,"nome":"Fort'Lon Cereal Arroz 180G","preco":7.5,"custo":5,"estoque":6,"categoria":"Mercearia ","barcode":"7898617581257","imagem":"","codigo":""},{"id":89,"nome":"Amido de Milho Maizena 200G","preco":6.5,"custo":4.29,"estoque":3,"categoria":"Mercearia ","barcode":"7891150055070","imagem":"","codigo":""},{"id":90,"nome":"Aveia em Flocos Fazenda Sedrez 165G","preco":6,"custo":3.96,"estoque":1,"categoria":"Mercearia ","barcode":"7898966974700","imagem":"","codigo":""},{"id":91,"nome":"Aveia Em Flocos Kisabor 170G","preco":6,"custo":3.96,"estoque":2,"categoria":"Mercearia ","barcode":"4898947864801","imagem":"","codigo":""},{"id":92,"nome":"Aveia Em Flocos Italac 165G","preco":6,"custo":3.96,"estoque":0,"categoria":"Mercearia ","barcode":"7898080642936","imagem":"","codigo":""},{"id":93,"nome":"Mistura para Bolo Apti Abacaxi 400G","preco":6.5,"custo":3.49,"estoque":3,"categoria":"Mercearia ","barcode":"7896327501251","imagem":"","codigo":""},{"id":94,"nome":"Mistura para Bolo Laranja Italac 400G","preco":7,"custo":4.6,"estoque":2,"categoria":"Mercearia ","barcode":"7898080641618","imagem":"","codigo":""},{"id":95,"nome":"Coco Ralado Menina 100G","preco":4,"custo":2.6,"estoque":24,"categoria":"Mercearia ","barcode":"7896028030654","imagem":"","codigo":""},{"id":96,"nome":"Coco Ralado Menina 50G","preco":2.5,"custo":1.65,"estoque":11,"categoria":"Mercearia ","barcode":"7896028030661","imagem":"","codigo":""},{"id":97,"nome":"Goiabada 500G Xavante","preco":12.5,"custo":8.25,"estoque":3,"categoria":"Mercearia ","barcode":"7896235800293","imagem":"","codigo":""},{"id":98,"nome":"Goiabada 250G Xavant ","preco":6.5,"custo":4.29,"estoque":6,"categoria":"Mercearia ","barcode":"7896235800286","imagem":"","codigo":""},{"id":99,"nome":"Leite de Coco Mais Coco 200ML","preco":8,"custo":5.28,"estoque":1,"categoria":"Mercearia ","barcode":"7896004400297","imagem":"","codigo":""},{"id":100,"nome":"Farinha de Mandioca Fina Pachá","preco":10,"custo":5.4,"estoque":1,"categoria":"Mercearia ","barcode":"7896602900076","imagem":"","codigo":""},{"id":101,"nome":"Farofa Tradicional Yoki 400G","preco":8.5,"custo":4.8,"estoque":21,"categoria":"Mercearia ","barcode":"7891095911486","imagem":"","codigo":""},{"id":102,"nome":"Biscoito Cream Cracker Trad Vitarella 350G","preco":7.8,"custo":5.15,"estoque":2,"categoria":"Mercearia ","barcode":"7896213006235","imagem":"","codigo":""},{"id":103,"nome":"Biscoito Cream Cracker Especial Marilan 350G","preco":8.9,"custo":5.88,"estoque":2,"categoria":"Mercearia ","barcode":"7896003738629","imagem":"","codigo":""},{"id":104,"nome":"Biscoito Cream Cracker 350G","preco":8.9,"custo":5.88,"estoque":2,"categoria":"Mercearia ","barcode":"7896003738605","imagem":"","codigo":""},{"id":105,"nome":"Biscoito sabor Leite Marilan 300G","preco":7.9,"custo":5.22,"estoque":1,"categoria":"Mercearia ","barcode":"7896003740240","imagem":"","codigo":""},{"id":106,"nome":"Biscoito Sabor Maizena Marilan 300G","preco":7.9,"custo":5.22,"estoque":1,"categoria":"Mercearia ","barcode":"7896003740226","imagem":"","codigo":""},{"id":107,"nome":"Biscoito Sabor Coco Marilan 300G","preco":7.9,"custo":5.22,"estoque":1,"categoria":"Mercearia ","barcode":"7896003740233","imagem":"","codigo":""},{"id":108,"nome":"Torrada Trad Viscont  120G","preco":5,"custo":3.5,"estoque":3,"categoria":"Mercearia ","barcode":"7891962052564","imagem":"","codigo":""},{"id":109,"nome":"Biscoito Maizena 140G","preco":3.8,"custo":2.52,"estoque":2,"categoria":"Mercearia ","barcode":"7896003740325","imagem":"","codigo":""},{"id":110,"nome":"Biscoito Tucs Pizza 100G","preco":2.5,"custo":1.25,"estoque":1,"categoria":"Mercearia ","barcode":"7896061301865","imagem":"","codigo":""},{"id":111,"nome":"Biscoito Passatempo Morango 130G","preco":4,"custo":2,"estoque":9,"categoria":"Mercearia ","barcode":"7891000241295","imagem":"","codigo":""},{"id":112,"nome":"Biscoito Passatempo Chocolate 130G","preco":4,"custo":2,"estoque":5,"categoria":"Mercearia ","barcode":"7891000241356","imagem":"","codigo":""},{"id":113,"nome":"Biscoito Morango Glub Mania 100G","preco":2.5,"custo":1,"estoque":8,"categoria":"Mercearia ","barcode":"7897426030659","imagem":"","codigo":""},{"id":114,"nome":"Biscoito Glub Mania 100G ","preco":2.5,"custo":1,"estoque":5,"categoria":"Mercearia ","barcode":"7897426030642","imagem":"","codigo":""},{"id":115,"nome":"Biscoito Fazendinha Morango 108G","preco":2.5,"custo":1,"estoque":2,"categoria":"Mercearia ","barcode":"7896061302237","imagem":"","codigo":""},{"id":116,"nome":"Biscoito Leite Fazendinha 102G","preco":2.5,"custo":1,"estoque":2,"categoria":"Mercearia ","barcode":"7896061302138","imagem":"","codigo":""},{"id":117,"nome":"Biscoito Adria Chocolate ao Leite 130G","preco":4,"custo":2.9,"estoque":2,"categoria":"Mercearia ","barcode":"7896085086496","imagem":"","codigo":""},{"id":118,"nome":"Biscoito Cookie Chocolate Bauducco 96G","preco":5.9,"custo":3.6,"estoque":1,"categoria":"Mercearia ","barcode":"6898962054124","imagem":"","codigo":""},{"id":119,"nome":"Biscoito Chocolate com Recheio de Morango Toddy Pacote 100g","preco":3.5,"custo":2,"estoque":6,"categoria":"Biscoitos","barcode":"7896071024433","imagem":"","codigo":""},{"id":120,"nome":"Biscoito Recheado Toddy Chocolate 100g","preco":3.5,"custo":2,"estoque":7,"categoria":"Biscoitos","barcode":"7896071024839","imagem":"","codigo":""},{"id":121,"nome":"Rosquinhas Marilan Coco 300g","preco":5.9,"custo":3.9,"estoque":1,"categoria":"Biscoitos","barcode":"7896003738483","imagem":"","codigo":""},{"id":122,"nome":"Marilan Rosquinha de Leite 300g","preco":5.9,"custo":3.9,"estoque":1,"categoria":"Biscoitos","barcode":"7896003738421","imagem":"","codigo":""},{"id":123,"nome":"Leite Líquido Bonolat 1L","preco":5.5,"custo":3,"estoque":6,"categoria":"Mercearia ","barcode":"7898994095156","imagem":"","codigo":""},{"id":124,"nome":"Leite Líquido Cooper Rita 1L","preco":5.5,"custo":3,"estoque":1,"categoria":"Mercearia ","barcode":"7898005653504","imagem":"","codigo":""},{"id":125,"nome":"Cha Leão Capim Cidreira 10G","preco":6,"custo":3.96,"estoque":3,"categoria":"Mercearia ","barcode":"7891098000156","imagem":"","codigo":""},{"id":126,"nome":"Chá Leão Erva Doce","preco":6,"custo":3.96,"estoque":2,"categoria":"Mercearia ","barcode":"7891098001504","imagem":"","codigo":""},{"id":127,"nome":"Caixa Bombom Garoto 250G","preco":18.99,"custo":13.99,"estoque":4,"categoria":"Doces","barcode":"7891008116632","imagem":"","codigo":""},{"id":128,"nome":"Caixa Bombom Nestlé ","preco":19.99,"custo":14.99,"estoque":4,"categoria":"Doces","barcode":"7891000325131","imagem":"","codigo":""},{"id":129,"nome":"Caixa Bombom Lacta 250G","preco":19.99,"custo":14.99,"estoque":4,"categoria":"Doces","barcode":"7622210596413","imagem":"","codigo":""},{"id":130,"nome":"Bis Lacta Original 126G","preco":9,"custo":5.3,"estoque":3,"categoria":"Biscoitos","barcode":"7622210575975","imagem":"","codigo":""},{"id":131,"nome":"Ovo Branco","preco":1,"custo":0.666,"estoque":25,"categoria":"Mercearia ","barcode":"","imagem":"","codigo":"01"},{"id":132,"nome":"Isqueiro Chama","preco":3,"custo":0.94,"estoque":9,"categoria":"Mercearia ","barcode":"","imagem":"","codigo":"02"},{"id":133,"nome":"Fósforo Pinheiro Fiat Lux","preco":1,"custo":0.27,"estoque":199,"categoria":"Mercearia ","barcode":"7896007912124","imagem":"","codigo":""},{"id":134,"nome":"Vela Paraná ","preco":1,"custo":0.49,"estoque":15,"categoria":"Mercearia ","barcode":"7896080901091","imagem":"","codigo":"1091"},{"id":135,"nome":"Papel Higiênico Neve  4 Rolos","preco":10.85,"custo":6.1,"estoque":1,"categoria":"Higiene","barcode":"7891172421174","imagem":"","codigo":""},{"id":136,"nome":"Papel Higiênico Sublime 4 Rolos","preco":7.2,"custo":4.1,"estoque":1,"categoria":"Higiene ","barcode":"7896061915109","imagem":"","codigo":""},{"id":137,"nome":"Papel Higiênico Paloma 4 Rolos","preco":4.99,"custo":2.49,"estoque":4,"categoria":"Higiene","barcode":"7896026838245","imagem":"","codigo":""},{"id":138,"nome":"Papel Higiênico Personal Vip 4 Rolos","preco":9.8,"custo":5.5,"estoque":3,"categoria":"Higiene","barcode":"7896110000176","imagem":"","codigo":""},{"id":139,"nome":"Biscoito Trakinas Chocolate 126G","preco":4.25,"custo":2.25,"estoque":8,"categoria":"Biscoitos","barcode":"7622210592750","imagem":"","codigo":""},{"id":140,"nome":"Biscoito Morango Patrulha Canina Marilan 80G","preco":3,"custo":1.8,"estoque":3,"categoria":"Biscoitos","barcode":"7896003739329","imagem":"","codigo":""},{"id":141,"nome":"Biscoito Chocolate Patrulha Canina 80G","preco":3,"custo":1.8,"estoque":4,"categoria":"Biscoitos","barcode":"7896003739312","imagem":"","codigo":""},{"id":142,"nome":"Biscoito Marilan Chocolate 70G","preco":3,"custo":1.8,"estoque":3,"categoria":"Biscoitos","barcode":"","imagem":"","codigo":"9299"},{"id":143,"nome":"Biscoito Wafer Chocolate Marilan 70G","preco":3,"custo":1.8,"estoque":7,"categoria":"Biscoitos","barcode":"7896003740585","imagem":"","codigo":""},{"id":144,"nome":"Biscoito Wafer Marilan Brigadeiro 70G","preco":3,"custo":1.8,"estoque":3,"categoria":"Biscoitos","barcode":"7896003740578","imagem":"","codigo":"0578"},{"id":145,"nome":"Biscoito Wafer Morango Marilan 70G","preco":3,"custo":1.8,"estoque":8,"categoria":"0608","barcode":"7896003740608","imagem":"","codigo":""},{"id":146,"nome":"Papel Higiênico Sublime 8 Rolos","preco":13,"custo":7.29,"estoque":2,"categoria":"Higiene ","barcode":"7896061915208","imagem":"","codigo":""},{"id":147,"nome":"Absorvente Sym C/Abas ","preco":4.99,"custo":2.82,"estoque":6,"categoria":"Higiene ","barcode":"7896110002248","imagem":"","codigo":""},{"id":148,"nome":"Guardanapo Coquetel ","preco":3.65,"custo":2,"estoque":6,"categoria":"Higiene ","barcode":"7896301800028","imagem":"","codigo":""},{"id":149,"nome":"Acetona Farmax 80ML","preco":4.25,"custo":2.4,"estoque":8,"categoria":"Higiene ","barcode":"7896902200494","imagem":"","codigo":""},{"id":150,"nome":"Sanito 50L C/10 Saco Para Lixo Pretão","preco":6.9,"custo":3.9,"estoque":3,"categoria":"Higiene ","barcode":"7896450910500","imagem":"","codigo":""},{"id":151,"nome":"Sanito 100L C/15 Utilix Saco Para Lixo","preco":13.59,"custo":7.99,"estoque":2,"categoria":"Higiene ","barcode":"7896082824336","imagem":"","codigo":""},{"id":152,"nome":"Algodão Cotondela 50G Bolas de Algodão","preco":6.5,"custo":3.65,"estoque":5,"categoria":"Higiene","barcode":"7898916237244","imagem":"","codigo":""},{"id":153,"nome":"Shampoo + Condicionador Liso Perfeito Seda","preco":23.99,"custo":14.99,"estoque":1,"categoria":"Beleza","barcode":"","imagem":"","codigo":""},{"id":154,"nome":"Shampoo + Condionador Cachos Definidos Seda","preco":23.99,"custo":14.99,"estoque":1,"categoria":"Beleza","barcode":"7891150097353","imagem":"","codigo":""},{"id":155,"nome":"Creme de Cabelo Babosa Skala Expert 1KG","preco":14.99,"custo":9.99,"estoque":2,"categoria":"Beleza","barcode":"7897042005062","imagem":"","codigo":"5062"},{"id":156,"nome":"Creme de Cabelo Uva Skala 1KG","preco":14.99,"custo":9.99,"estoque":1,"categoria":"Beleza ","barcode":"7897042019311","imagem":"","codigo":"9311"},{"id":157,"nome":"Creme de Cabelo Abacate Skala 1KG","preco":14.99,"custo":9.99,"estoque":1,"categoria":"Beleza","barcode":"7897042005048","imagem":"","codigo":""},{"id":158,"nome":"Creme de Cabelo Coco 1K Skala","preco":14.99,"custo":9.99,"estoque":1,"categoria":"Beleza","barcode":"7897042010974","imagem":"","codigo":""},{"id":159,"nome":"Creme de Pele Amêndoas Doces Skala 400ML","preco":11.99,"custo":7.99,"estoque":1,"categoria":"Beleza ","barcode":"7897042015856","imagem":"","codigo":"5856"},{"id":160,"nome":"Creme de Pele Rosas e Amêndoas Skala 400ML","preco":11.99,"custo":7.99,"estoque":1,"categoria":"Beleza","barcode":"7897042015825","imagem":"","codigo":""},{"id":161,"nome":"Creme de Pele Aveia Skala 400ML","preco":11.99,"custo":7.99,"estoque":2,"categoria":"Beleza","barcode":"7897042015818","imagem":"","codigo":""},{"id":162,"nome":"Creme de Pele Frescor Natural Skala 400ML","preco":11.99,"custo":7.99,"estoque":1,"categoria":"Beleza","barcode":"7897042015863","imagem":"","codigo":"5863"},{"id":163,"nome":"Creme de Pele Lavanda Skala 400ML","preco":11.99,"custo":7.99,"estoque":1,"categoria":"Beleza","barcode":"7897042015894","imagem":"","codigo":"5894"},{"id":164,"nome":"Shampoo Hidratação Intensiva Monange 325ML","preco":11.99,"custo":7.99,"estoque":2,"categoria":"Beleza","barcode":"7896235353324","imagem":"","codigo":""},{"id":165,"nome":"Condicionador Reparação Pós Química Monange 325ML","preco":11.99,"custo":7.99,"estoque":2,"categoria":"Beleza","barcode":"7896235353423","imagem":"","codigo":"3423"},{"id":166,"nome":"Esponja de Aço Bom Bril ","preco":3.5,"custo":2,"estoque":23,"categoria":"Limpeza","barcode":"7891022868036","imagem":"","codigo":"8036"},{"id":167,"nome":"Creme Dental Sorriso 70G Tripla Limpeza","preco":4.5,"custo":2.7,"estoque":8,"categoria":"Higiene ","barcode":"7891528029498","imagem":"","codigo":""},{"id":168,"nome":"Creme Dental Closeup 70G Dentes Fortes","preco":5.5,"custo":3.3,"estoque":6,"categoria":"Higiene ","barcode":"7891150049888","imagem":"","codigo":"9888"},{"id":169,"nome":"Creme Dental Colgate Máxima Proteção 90G","preco":7.9,"custo":4.5,"estoque":3,"categoria":"Higiene ","barcode":"7891024134702","imagem":"","codigo":"4702"},{"id":170,"nome":"Creme Dental Colgate 90G Tripla Ação ","preco":7.9,"custo":4.5,"estoque":3,"categoria":"Higiene ","barcode":"7891024132128","imagem":"","codigo":"2128"},{"id":171,"nome":"Creme Dental Oral B Anticaries 70G","preco":6.8,"custo":4,"estoque":11,"categoria":"Higiene","barcode":"7506339363883","imagem":"","codigo":"3883"},{"id":172,"nome":"Inseticida Aerossol Baygon 217G","preco":15.99,"custo":10.5,"estoque":3,"categoria":"Limpeza","barcode":"7894650003787","imagem":"","codigo":"3787"},{"id":173,"nome":"Ares Gold Lava Roupas 900ML","preco":7.9,"custo":4.75,"estoque":2,"categoria":"Limpeza ","barcode":"7898973291005","imagem":"","codigo":"1005"},{"id":174,"nome":"Lava Roupas em pó Omo 400G","preco":12,"custo":7.95,"estoque":2,"categoria":"Limpeza","barcode":"7891150065284","imagem":"","codigo":""},{"id":175,"nome":"Lava Roupas em Pó Omo 800G","preco":17.9,"custo":11.65,"estoque":1,"categoria":"Limpeza ","barcode":"7891150064317","imagem":"","codigo":"4317"},{"id":176,"nome":"Sabonete Lírio Azul Lux 85G","preco":3.3,"custo":2.2,"estoque":7,"categoria":"Higiene","barcode":"7891150059917","imagem":"","codigo":"9917"},{"id":177,"nome":"Sabonete Flor de Verbena Lux 85G","preco":3.3,"custo":2.2,"estoque":7,"categoria":"Higiene","barcode":"7891150059856","imagem":"","codigo":"9856"},{"id":178,"nome":"Sabonete Camomila Livy 85G","preco":2.2,"custo":1.45,"estoque":7,"categoria":"Higiene","barcode":"7896023408199","imagem":"","codigo":"8199"},{"id":179,"nome":"Sabonete Laranjeira e Damasco Ypê 85G","preco":2.75,"custo":1.8,"estoque":2,"categoria":"Higiene","barcode":"7896098902240","imagem":"","codigo":"2240"},{"id":180,"nome":"Sabonete Água de coco e Alecrim Ypê 85G","preco":2.75,"custo":1.8,"estoque":3,"categoria":"Higiene ","barcode":"7896098902257","imagem":"","codigo":"2257"},{"id":181,"nome":"Saboneteira Nitron","preco":6.4,"custo":3.6,"estoque":5,"categoria":"Higiene","barcode":"7896779619320","imagem":"","codigo":"9320"},{"id":182,"nome":"Desodorante Aerossol Bozzano 150ML","preco":12.7,"custo":8.4,"estoque":3,"categoria":"Higiene","barcode":"7891350032970","imagem":"","codigo":"2970"},{"id":183,"nome":"Desodorante Rosas e Amêndoas Skala 60ML","preco":11,"custo":6.99,"estoque":2,"categoria":"Higiene","barcode":"7897042007301","imagem":"","codigo":"7301"},{"id":184,"nome":"Desodorante Cristal Skala 60ML","preco":11,"custo":6.99,"estoque":3,"categoria":"Higiene ","barcode":"7897042008780","imagem":"","codigo":"8780"},{"id":185,"nome":"Escova de Dente Pro Oral B ","preco":4.5,"custo":2.6,"estoque":5,"categoria":"Higiene","barcode":"7500435134415","imagem":"","codigo":""},{"id":186,"nome":"Escova de Dente Condor","preco":4.5,"custo":2.6,"estoque":1,"categoria":"Higiene ","barcode":"7891055337349","imagem":"","codigo":""},{"id":187,"nome":"Escova de Dente Limpus Kids","preco":3.5,"custo":1.6,"estoque":6,"categoria":"Higiene ","barcode":"","imagem":"","codigo":"05"},{"id":188,"nome":"Gel Bozzano 300G","preco":16.99,"custo":9.5,"estoque":6,"categoria":"Beleza","barcode":"7891350034868","imagem":"","codigo":"4868"},{"id":189,"nome":"Escova Multiuso Condor","preco":4.99,"custo":2.99,"estoque":6,"categoria":"Limpeza","barcode":"7891055111604","imagem":"","codigo":"1604"},{"id":190,"nome":"Esponja Lava Louça Tinindo ","preco":2.6,"custo":1.71,"estoque":7,"categoria":"Limpeza","barcode":"7891040128082","imagem":"","codigo":"8082"},{"id":191,"nome":"Esponja Tinindo C/4","preco":6.49,"custo":3.64,"estoque":7,"categoria":"Limpeza","barcode":"7891040198726","imagem":"","codigo":"8726"},{"id":192,"nome":"Palito de Dente Gina C/100 ","preco":1.65,"custo":1,"estoque":21,"categoria":"Higiene ","barcode":"7896051020127","imagem":"","codigo":"0127"},{"id":193,"nome":"Hastes Flexíveis Contonela C/75 Contonete","preco":2.6,"custo":1.56,"estoque":3,"categoria":"Higiene","barcode":"7898916237015","imagem":"","codigo":"7015"},{"id":194,"nome":"Hastes Flexíveis Topz C/75 Cotonete ","preco":3.49,"custo":1.95,"estoque":12,"categoria":"Higiene ","barcode":"7896004814162","imagem":"","codigo":"4162"},{"id":195,"nome":"Detergente Ypê Clear 500ML","preco":3.5,"custo":2.2,"estoque":9,"categoria":"Limpeza ","barcode":"7896098900253","imagem":"","codigo":""},{"id":196,"nome":"Detergente Ypê Maçã 500Ml","preco":3.5,"custo":2.2,"estoque":6,"categoria":"Limpeza ","barcode":"7896098900215","imagem":"","codigo":"0215"},{"id":197,"nome":"Detergente Ypê Clear Care 500ML","preco":3.5,"custo":2.2,"estoque":1,"categoria":"Limpeza","barcode":"7896098900277","imagem":"","codigo":"0277"},{"id":198,"nome":"Detergente Ypê Neutro 500ML","preco":3.5,"custo":2.2,"estoque":3,"categoria":"Limpeza","barcode":"7896098900208","imagem":"","codigo":"0208"},{"id":199,"nome":"Detergente Minuano Neutro 500ML","preco":3,"custo":2,"estoque":9,"categoria":"Limpeza ","barcode":"7897664130036","imagem":"","codigo":"0036"},{"id":200,"nome":"Detergente Candura Neutro 500ML","preco":2.75,"custo":1.6,"estoque":1,"categoria":"Limpeza ","barcode":"7896105501022","imagem":"","codigo":"1022"},{"id":201,"nome":"Detergente Candura Clear 500ML","preco":2.75,"custo":1.6,"estoque":11,"categoria":"Limpeza ","barcode":"7896105501060","imagem":"","codigo":"1060"},{"id":202,"nome":"Desinfetante Pinho Lavanda Ypê 500ML","preco":4.5,"custo":2.97,"estoque":6,"categoria":"Limpeza ","barcode":"7896098900628","imagem":"","codigo":"0628"},{"id":203,"nome":"Desinfetante Bak Floral Ypê 500ML","preco":6.5,"custo":3.78,"estoque":3,"categoria":"Limpeza","barcode":"7896098903612","imagem":"","codigo":"3612"},{"id":204,"nome":"Lava Roupas Primavera Tixan Ypê 400G","preco":7.5,"custo":4.7,"estoque":11,"categoria":"Limpeza ","barcode":"7896098909720","imagem":"","codigo":"9720"},{"id":205,"nome":"Lava Roupas Primavera Tixan 800G","preco":13,"custo":8.59,"estoque":6,"categoria":"Limpeza","barcode":"7896098909744","imagem":"","codigo":"9744"},{"id":206,"nome":"Lava Roupa Maciez Tixan 800G","preco":13,"custo":8.59,"estoque":1,"categoria":"Limpeza ","barcode":"","imagem":"","codigo":""},{"id":207,"nome":"Sabão Glicerinado Neutro Ypê ","preco":4.5,"custo":2.55,"estoque":8,"categoria":"Limpeza ","barcode":"7896098905906","imagem":"","codigo":"5906"},{"id":208,"nome":"Sabão Glicerinado Multiativo Ypê 160G","preco":4.5,"custo":2.55,"estoque":12,"categoria":"Limpeza ","barcode":"7896098905937","imagem":"","codigo":"5937"},{"id":209,"nome":"Multiuso Limpol Bom Bril 500ML","preco":7,"custo":4.9,"estoque":6,"categoria":"Limpeza ","barcode":"7891022860580","imagem":"","codigo":"0580"},{"id":210,"nome":"Multiuso + Bicarbonato Luar 500ML","preco":4.2,"custo":2.9,"estoque":2,"categoria":"Limpeza ","barcode":"7898650860418","imagem":"","codigo":"0418"},{"id":211,"nome":"Desengordurante Cozinha Cif 500ML","preco":17.99,"custo":11.9,"estoque":2,"categoria":"Limpeza ","barcode":"7891150071643","imagem":"","codigo":"1643"},{"id":212,"nome":"Neutralizado de Odores Bom Ar Campos de Lavanda 360ML ","preco":17.9,"custo":11.8,"estoque":3,"categoria":"Limpeza ","barcode":"7891035325595","imagem":"","codigo":"5595"},{"id":213,"nome":"Álcool 42% Safra 1L","preco":8.5,"custo":4.8,"estoque":11,"categoria":"Limpeza","barcode":"898840563966","imagem":"","codigo":"3966"},{"id":214,"nome":"Amaciante Paixão Sedutora Urca 2L","preco":8.3,"custo":5.8,"estoque":4,"categoria":"Limpeza ","barcode":"7896056401129","imagem":"","codigo":"1129"},{"id":215,"nome":"Amaciante Primavera Ypê 2L","preco":12,"custo":7.99,"estoque":2,"categoria":"Limpeza ","barcode":"7896098902417","imagem":"","codigo":"2417"},{"id":216,"nome":"Amaciante Intenso Ypê 2L","preco":12,"custo":7.99,"estoque":4,"categoria":"Limpeza ","barcode":"7896098903032","imagem":"","codigo":"3032"},{"id":217,"nome":"Água Sanitária Candura 1L","preco":4.5,"custo":2.6,"estoque":2,"categoria":"Limpeza","barcode":"7896105500018","imagem":"","codigo":"0018"},{"id":218,"nome":"Água Sanitária Candura 2L","preco":6.99,"custo":3.8,"estoque":4,"categoria":"Limpeza ","barcode":"7896105500094","imagem":"","codigo":"0094"},{"id":219,"nome":"Água Sanitária Triex 2L","preco":5.99,"custo":2.99,"estoque":8,"categoria":"Limpeza","barcode":"5890527702663","imagem":"","codigo":"2663"},{"id":220,"nome":"Rosquinha Leite Panco 350G","preco":8.9,"custo":6.13,"estoque":6,"categoria":"Biscoitos","barcode":"7891203063489","imagem":"","codigo":"3489"},{"id":221,"nome":"Rosquinha de Coco Panco 350G","preco":6.9,"custo":4.72,"estoque":6,"categoria":"Biscoitos","barcode":"7891203063465","imagem":"","codigo":"3465"},{"id":222,"nome":"Pão de Forma Premium Panco 500G","preco":11,"custo":7.38,"estoque":4,"categoria":"Mercearia ","barcode":"7891203010056","imagem":"","codigo":"0056"},{"id":223,"nome":"Rosquinha de Leite Panco 500G","preco":11.9,"custo":8.21,"estoque":3,"categoria":"Biscoitos","barcode":"7891203021151","imagem":"","codigo":"1151"},{"id":224,"nome":"Rosquinha de Coco Panco 500G","preco":9.6,"custo":6.59,"estoque":2,"categoria":"Biscoitos","barcode":"7891203021106","imagem":"","codigo":"1106"},{"id":225,"nome":"Rosquinha de Chocolate Panco 500G","preco":11.9,"custo":7.75,"estoque":6,"categoria":"Biscoitos","barcode":"7891203021168","imagem":"","codigo":"1168"},{"id":226,"nome":"Biscoito Cream Cracker 200G Panco ","preco":5.9,"custo":3.34,"estoque":6,"categoria":"Biscoitos ","barcode":"7891203020765","imagem":"","codigo":"0765"},{"id":227,"nome":"Pão de Mel C/Chocolate 200G Panco ","preco":11.99,"custo":7.04,"estoque":4,"categoria":"Biscoitos","barcode":"7891203020260","imagem":"","codigo":"0260"},{"id":228,"nome":"Biscoito Morango Panco 140G","preco":4,"custo":2.31,"estoque":15,"categoria":"Biscoitos ","barcode":"7891203063250","imagem":"","codigo":"3250"},{"id":229,"nome":"Biscoito Chocolate Panco 140G","preco":4,"custo":2.31,"estoque":15,"categoria":"Biscoitos ","barcode":"7891203063243","imagem":"","codigo":"3243"},{"id":230,"nome":"Rosquinha de Chocolate 500G Panco","preco":11.5,"custo":7.75,"estoque":0,"categoria":"Biscoitos ","barcode":"7891403021166","imagem":"","codigo":"1166"},{"id":231,"nome":"Biscoito Água e Sal Panco 200G","preco":5.9,"custo":3.34,"estoque":3,"categoria":"Biscoitos","barcode":"7891203050526","imagem":"","codigo":"0526"},{"id":232,"nome":"Biscoito Sequilhinho 350G Panco","preco":10.9,"custo":7.16,"estoque":4,"categoria":"Biscoitos","barcode":"7891203063519","imagem":"","codigo":"3519"},{"id":233,"nome":"Cerveja Crystal 350ML Lata","preco":3.5,"custo":2.29,"estoque":28,"categoria":"Bebidas","barcode":"7897395060107","imagem":"","codigo":"0107"},{"id":234,"nome":"Salgadinho Cebola y Salsa Fritop 200G","preco":8.99,"custo":5.75,"estoque":5,"categoria":"Salgadinhos ","barcode":"","imagem":"","codigo":"2366"},{"id":235,"nome":"Cerveja Skol 350ML Lata ","preco":5,"custo":2.99,"estoque":5,"categoria":"Cervejas","barcode":"7891149200504","imagem":"","codigo":""},{"id":236,"nome":"Japira Limão 500ML Corote ","preco":5,"custo":2.49,"estoque":10,"categoria":"Bebidas","barcode":"7897507402344","imagem":"","codigo":"2344"},{"id":237,"nome":"Sminorff Ice Limão 275ML","preco":10,"custo":5.99,"estoque":5,"categoria":"Bebidas","barcode":"7893218003603","imagem":"","codigo":"3606"},{"id":238,"nome":"Askov Ice Blueberry 275ML","preco":8,"custo":4.99,"estoque":2,"categoria":"Bebidas","barcode":"7896092503740","imagem":"","codigo":""},{"id":239,"nome":"Askov Ice Limão 275ML","preco":8,"custo":4.99,"estoque":2,"categoria":"Bebidas","barcode":"7896092502378","imagem":"","codigo":"2378"},{"id":240,"nome":"Redebull Tradicional 250ML","preco":12,"custo":7,"estoque":21,"categoria":"Bebidas","barcode":"611269991000","imagem":"","codigo":""},{"id":241,"nome":"Monster Tradicional 473ML","preco":12,"custo":8,"estoque":8,"categoria":"Bebidas","barcode":"070847022015","imagem":"","codigo":"2015"},{"id":242,"nome":"Baly Tropical 473ML","preco":8,"custo":3.99,"estoque":5,"categoria":"Bebidas","barcode":"888484664273","imagem":"","codigo":"4273"},{"id":243,"nome":"Baly Melancia 473ML ","preco":8,"custo":3.99,"estoque":10,"categoria":"Bebidas","barcode":"7898080664402","imagem":"","codigo":"4402"},{"id":244,"nome":"Baly Maçã 473ML Energético","preco":8,"custo":3.99,"estoque":4,"categoria":"Bebidas","barcode":"7898080664587","imagem":"","codigo":"4587"},{"id":245,"nome":"TNT Tradicional 473ML ","preco":10,"custo":5.99,"estoque":3,"categoria":"Bebidas ","barcode":"7897395031626","imagem":"","codigo":"1626"},{"id":246,"nome":"Draft 600ML","preco":12.5,"custo":7.5,"estoque":5,"categoria":"Bebidas","barcode":"7896494207314","imagem":"","codigo":"7314"},{"id":247,"nome":"Monster Absolute Zero 473ML","preco":12,"custo":8,"estoque":2,"categoria":"Bebidas","barcode":"070847022305","imagem":"","codigo":"2305"},{"id":248,"nome":"Chocolate Branco Garoto 80G","preco":11.4,"custo":6.85,"estoque":12,"categoria":"Doces ","barcode":"7891008125214","imagem":"","codigo":"5214"},{"id":249,"nome":"Chocolate ao Leite Garoto 80G","preco":11.4,"custo":6.85,"estoque":15,"categoria":"Doces","barcode":"7891008123975","imagem":"","codigo":"3975"},{"id":250,"nome":"Baton Garoto 16G","preco":2.5,"custo":1.44,"estoque":20,"categoria":"Doces ","barcode":"78912359","imagem":"","codigo":"2359"},{"id":251,"nome":"Suco Fruvale Frutas Cítricas 300ML","preco":3,"custo":1.59,"estoque":8,"categoria":"Bebidas","barcode":"7897507404270","imagem":"","codigo":"4270"},{"id":252,"nome":"Guaraná Antarctica 200ML","preco":3,"custo":1.59,"estoque":2,"categoria":"Bebidas","barcode":"7891991014908","imagem":"","codigo":"4908"},{"id":253,"nome":"ITI Laranja 2L","preco":7.5,"custo":4.85,"estoque":9,"categoria":"Bebidas","barcode":"7898377662487","imagem":"","codigo":"2487"},{"id":254,"nome":"Xereta Maçã 2L","preco":6.5,"custo":3.79,"estoque":4,"categoria":"Bebidas ","barcode":"896480300132","imagem":"","codigo":"0132"},{"id":255,"nome":"Fanta Laranja 2L","preco":12,"custo":8,"estoque":4,"categoria":"Bebidas","barcode":"","imagem":"","codigo":"1515"},{"id":256,"nome":"ITI Lemon Ice 2L","preco":7.5,"custo":4.85,"estoque":12,"categoria":"Bebidas","barcode":"7898377662463","imagem":"","codigo":"2463"},{"id":257,"nome":"Xereta Guaraná 2L","preco":6.5,"custo":3.79,"estoque":2,"categoria":"Bebidas ","barcode":"7896186300118","imagem":"","codigo":"0118"},{"id":258,"nome":"Sukita Laranja ","preco":7.5,"custo":5.8,"estoque":5,"categoria":"Bebidas","barcode":"7891149440801","imagem":"","codigo":"0801"},{"id":259,"nome":"ITI Cola 2L","preco":7.5,"custo":4.85,"estoque":8,"categoria":"Bebidas","barcode":"7898377662401","imagem":"","codigo":"2401"},{"id":260,"nome":"ITI Guaraná 2L","preco":7.5,"custo":4.79,"estoque":8,"categoria":"Bebidas","barcode":"7898377662425","imagem":"","codigo":"2425"},{"id":261,"nome":"Suco Del Valle Laranja 1,5L","preco":8,"custo":5.4,"estoque":4,"categoria":"Bebidas ","barcode":"7894900556063","imagem":"","codigo":"6063"},{"id":262,"nome":"Suco Del Valle Uva 1,5L","preco":8,"custo":5.4,"estoque":5,"categoria":"Bebidas","barcode":"7894900550061","imagem":"","codigo":"0061"},{"id":263,"nome":"Flying Horse 2L ","preco":12,"custo":8,"estoque":2,"categoria":"Bebidas ","barcode":"7898132844493","imagem":"","codigo":"4493"},{"id":264,"nome":"Baly Maçã 2L","preco":13,"custo":7.99,"estoque":5,"categoria":"Bebidas","barcode":"7898080664563","imagem":"","codigo":""},{"id":265,"nome":"Fanta Laranja Retornável 2L","preco":9,"custo":6.64,"estoque":6,"categoria":"Bebidas ","barcode":"7894900034219","imagem":"","codigo":"4219"},{"id":266,"nome":"Coca Cola Original 2L","preco":13,"custo":9.25,"estoque":5,"categoria":"Bebidas","barcode":"7894900027013","imagem":"","codigo":"7013"},{"id":267,"nome":"Brahma Lata 350ML","preco":5,"custo":3.05,"estoque":17,"categoria":"Cervejas","barcode":"7891149010509","imagem":"","codigo":"0509"},{"id":268,"nome":"Askov Ice Maracujá 275ML","preco":8,"custo":4.99,"estoque":3,"categoria":"Bebidas","barcode":"7896092503306","imagem":"","codigo":"3306"},{"id":269,"nome":"Monster Mango Loco 473ML","preco":12,"custo":8,"estoque":5,"categoria":"Bebidas","barcode":"070847033301","imagem":"","codigo":"3301"},{"id":270,"nome":"Baly Melancia 2L","preco":13,"custo":8,"estoque":5,"categoria":"Bebidas","barcode":"7898080664389","imagem":"","codigo":"4389"},{"id":271,"nome":"Coca Cola Retornável 2L","preco":9,"custo":7.55,"estoque":9,"categoria":"Bebidas ","barcode":"7894900014211","imagem":"","codigo":"4211"},{"id":272,"nome":"Geladinho Americano ","preco":0.5,"custo":0.29,"estoque":200,"categoria":"Sorvetes","barcode":"7896704100015","imagem":"","codigo":"0015"},{"id":273,"nome":"Fanta 200ML ","preco":3,"custo":1.69,"estoque":24,"categoria":"Bebidas ","barcode":"78936478","imagem":"","codigo":"6478"}],"clientes":[{"id":3,"nome":"Vó Vera","telefone":"","limite":700,"saldo":32.5,"endereco":"","obs":"","aniversario":""}],"vendas":[{"id":1,"data":"2026-03-09T19:35:56.461Z","itens":[{"id":12,"nome":"Macarrão Instantâneo Lámen Galinha Caipira Nissin Miojo 85g","qty":2,"preco":3.5}],"subtotal":7,"desconto":0,"total":7,"liquido":6.9657,"taxaValor":0.0343,"pagamento":"pix","clienteId":null},{"id":2,"data":"2026-03-13T00:41:25.618Z","itens":[{"id":1,"nome":"Coca-Cola 350ml Original ","qty":1,"preco":5}],"subtotal":5,"desconto":0,"total":5,"liquido":5,"taxaValor":0,"pagamento":"fiado","clienteId":3,"cancelada":true},{"id":3,"data":"2026-03-15T15:49:48.458Z","itens":[{"id":183,"nome":"Desodorante Rosas e Amêndoas Skala 60ML","qty":1,"preco":11}],"subtotal":11,"desconto":0,"total":11,"liquido":11,"taxaValor":0,"pagamento":"dinheiro","clienteId":null},{"id":4,"data":"2026-03-16T15:18:26.395Z","itens":[{"id":248,"nome":"Chocolate Branco Garoto 80G","qty":1,"preco":11.4},{"id":14,"nome":"Creme de Leite Piracanjuba 200g","qty":1,"preco":3.95}],"subtotal":15.350000000000001,"desconto":0,"total":15.350000000000001,"liquido":14.752885000000001,"taxaValor":0.5971150000000005,"pagamento":"credito","clienteId":null},{"id":5,"data":"2026-03-16T16:13:52.669Z","itens":[{"id":250,"nome":"Baton Garoto 16G","qty":1,"preco":2.5}],"subtotal":2.5,"desconto":0,"total":2.5,"liquido":2.5,"taxaValor":0,"pagamento":"dinheiro","clienteId":null},{"id":6,"data":"2026-03-16T18:16:43.858Z","itens":[{"id":28,"nome":"Café Caboclo 250G","qty":1,"preco":17.5}],"subtotal":17.5,"desconto":0,"total":17.5,"liquido":17.20775,"taxaValor":0.29224999999999923,"pagamento":"debito","clienteId":null},{"id":7,"data":"2026-03-16T18:17:00.831Z","itens":[{"id":43,"nome":"Café Moraes 500G","qty":1,"preco":32.5}],"subtotal":32.5,"desconto":0,"total":32.5,"liquido":32.5,"taxaValor":0,"pagamento":"fiado","clienteId":3},{"id":8,"data":"2026-03-16T20:51:12.097Z","itens":[{"id":44,"nome":"Pitu Lata 350ML","qty":8,"preco":8}],"subtotal":64,"desconto":0,"total":64,"liquido":64,"taxaValor":0,"pagamento":"dinheiro","clienteId":null}],"compras":[{"id":1,"data":"2026-03-11T20:53:35.281Z","fornecedor":"Avant Distribuidora","itens":[{"id":74,"nome":"Molho de Tomate Trad Fugini 300G","qty":27,"custo":1.29},{"id":73,"nome":"Mini Bolo Marshmallow y Morango Animal","qty":15,"custo":1.19},{"id":72,"nome":"Mini Bolo Brigadeiro Animal","qty":15,"custo":1.19}],"total":70.52999999999999},{"id":2,"data":"2026-03-11T21:01:58.612Z","fornecedor":"Avant Distribuidora","itens":[{"id":75,"nome":"Colorífico 97G Marata","qty":10,"custo":1.29}],"total":12.9},{"id":3,"data":"2026-03-11T21:19:57.561Z","fornecedor":"Avant Distribuidora ","itens":[{"id":76,"nome":"Bebida Láctea Shefa Chocolate 200ml","qty":27,"custo":1.05}],"total":28.35},{"id":4,"data":"2026-03-11T21:33:45.945Z","fornecedor":"Avant Distribuidora ","fornecedorId":2,"itens":[{"id":74,"nome":"Molho de Tomate Trad Fugini 300G","qty":9,"custo":1.29}],"total":11.61,"notaFiscal":"","obs":"","cancelada":false},{"id":5,"data":"2026-03-15T16:50:22.376Z","fornecedor":"Panco","fornecedorId":6,"itens":[{"id":220,"nome":"Rosquinha Leite Panco 350G","qty":6,"custo":6.13},{"id":221,"nome":"Rosquinha de Coco Panco","qty":6,"custo":4.72},{"id":223,"nome":"Rosquinha de Leite Panco 500G","qty":3,"custo":8.21},{"id":224,"nome":"Rosquinha de Coco Panco 500G","qty":3,"custo":6.59},{"id":225,"nome":"Rosquinha de Chocolate 500G","qty":6,"custo":7.75},{"id":231,"nome":"Biscoito Água e Sal Panco 200G","qty":3,"custo":3.34},{"id":226,"nome":"Biscoito Cream Cracker 200G Panco ","qty":6,"custo":3.34},{"id":232,"nome":"Biscoito Sequilhinho 350G Panco","qty":4,"custo":7.16},{"id":229,"nome":"Biscoito Chocolate Panco 140G","qty":15,"custo":2.31},{"id":228,"nome":"Biscoito Morango Panco 140G","qty":15,"custo":2.31},{"id":227,"nome":"Pão de Mel C/Chocolate 200G Panco ","qty":4,"custo":7.04},{"id":222,"nome":"Pão de Forma Premium Panco","qty":4,"custo":7.38}],"total":341.68,"notaFiscal":"","obs":"","cancelada":false},{"id":6,"data":"2026-03-16T16:18:21.644Z","fornecedor":"Esperança ","fornecedorId":7,"itens":[{"id":271,"nome":"Coca Cola Retornável 2L","qty":9,"custo":7.55}],"total":67.95,"notaFiscal":"","obs":"","cancelada":false},{"id":7,"data":"2026-03-16T17:56:30.263Z","fornecedor":"Spani ","fornecedorId":8,"itens":[{"id":273,"nome":"Fanta 200ML ","qty":24,"custo":1.69},{"id":272,"nome":"Geladinho Americano ","qty":200,"custo":0.29}],"total":98.56,"notaFiscal":"","obs":"","cancelada":false,"editadaEm":"2026-03-16T17:57:23.317Z"}],"fornecedores":[{"id":1,"nome":"Ambev","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":2,"nome":"Avant Distribuidora ","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":3,"nome":"Vila Nova","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":4,"nome":"Coca Cola","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":5,"nome":"Skimel","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":6,"nome":"Panco","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":7,"nome":"Esperança ","telefone":"","cnpj":"","email":"","produtos":"","obs":""},{"id":8,"nome":"Spani ","telefone":"","cnpj":"","email":"","produtos":"","obs":""}],"fiado":[{"id":1,"clienteId":3,"vendaId":2,"valor":5,"data":"2026-03-13T00:41:25.619Z","pago":true,"cancelado":true,"dataPagamento":"2026-03-13T00:47:36.632Z"},{"id":2,"clienteId":3,"vendaId":7,"valor":32.5,"data":"2026-03-16T18:17:00.831Z","pago":false}],"perdas":[{"id":1,"produtoId":224,"nome":"Rosquinha de Coco Panco 500G","qty":1,"custo":6.59,"motivo":"Erro operacional","obs":"Não veio","data":"2026-03-15T16:51:56.526Z"}],"taxas":{"pix":0.49,"credito":3.89,"debito":1.67},"nextId":{"produto":274,"cliente":4,"venda":9,"compra":8,"fiado":3,"fornecedor":9,"perda":2}};

// ── Cookie helpers (backup secundário) ──────────────────────────
const COOKIE_KEY = "pdv_session_v1";

function saveCookie(data) {
  try {
    const json = JSON.stringify(data);
    // Cookies têm limite de 4KB — divide em chunks de 3KB
    const chunks = [];
    for (let i = 0; i < json.length; i += 3000) chunks.push(json.slice(i, i + 3000));
    // Limpa cookies antigos
    for (let i = 0; i < 20; i++) document.cookie = `${COOKIE_KEY}_${i}=;max-age=0;path=/`;
    // Salva novos chunks
    chunks.forEach((chunk, i) => {
      document.cookie = `${COOKIE_KEY}_${i}=${encodeURIComponent(chunk)};max-age=2592000;path=/`; // 30 dias
    });
    document.cookie = `${COOKIE_KEY}_total=${chunks.length};max-age=2592000;path=/`;
  } catch {}
}

function loadCookie() {
  try {
    const cookies = Object.fromEntries(document.cookie.split(";").map(c => c.trim().split("=").map(decodeURIComponent)));
    const total = parseInt(cookies[`${COOKIE_KEY}_total`] || "0");
    if (!total) return null;
    let json = "";
    for (let i = 0; i < total; i++) json += cookies[`${COOKIE_KEY}_${i}`] || "";
    return json ? JSON.parse(json) : null;
  } catch { return null; }
}

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Se o localStorage tem menos produtos que o backup, prefere o backup
      if ((parsed.produtos || []).length >= (USER_BACKUP.produtos || []).length) {
        return { ...defaultData, ...parsed };
      }
    }
  } catch {}
  try {
    const fromCookie = loadCookie();
    if (fromCookie && (fromCookie.produtos || []).length >= (USER_BACKUP.produtos || []).length) {
      saveData({ ...defaultData, ...fromCookie });
      return { ...defaultData, ...fromCookie };
    }
  } catch {}
  // Usa o backup do usuário e salva no localStorage para as próximas vezes
  const initial = { ...defaultData, ...USER_BACKUP };
  saveData(initial);
  return initial;
}

function saveData(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
  try { saveCookie(data); } catch {}
}

// ══════════════════════════════════════════════════════════════════
// FIREBASE — acesso via firebase.js (window.FirebaseDB)
// Edite o arquivo firebase.js para configurar sua conexão.
// ══════════════════════════════════════════════════════════════════
const FB = () => window.FirebaseDB || null;

// ══════════════════════════════════════════════════════════════════
// BANCO LOCAL — +100 produtos brasileiros mais vendidos
// ══════════════════════════════════════════════════════════════════
const PRODUTOS_BR = {
  "7894900011517": { nome: "Coca-Cola 2L", categoria: "Bebidas" },
  "7894900001044": { nome: "Coca-Cola Lata 350ml", categoria: "Bebidas" },
  "7894900700060": { nome: "Coca-Cola 600ml", categoria: "Bebidas" },
  "7894900020076": { nome: "Coca-Cola Zero Lata 350ml", categoria: "Bebidas" },
  "7891991010887": { nome: "Pepsi Cola 2L", categoria: "Bebidas" },
  "7891991010856": { nome: "Pepsi Cola Lata 350ml", categoria: "Bebidas" },
  "7896065200046": { nome: "Guaraná Antarctica 2L", categoria: "Bebidas" },
  "7896065200015": { nome: "Guaraná Antarctica Lata 350ml", categoria: "Bebidas" },
  "7896065200091": { nome: "Guaraná Antarctica 600ml", categoria: "Bebidas" },
  "7896036090046": { nome: "Fanta Laranja 2L", categoria: "Bebidas" },
  "7894900700329": { nome: "Sprite 2L", categoria: "Bebidas" },
  "7896050700089": { nome: "Água Crystal 500ml", categoria: "Bebidas" },
  "7896085882703": { nome: "Suco Del Valle Laranja 200ml", categoria: "Bebidas" },
  "7891150012325": { nome: "Red Bull Energy Drink 250ml", categoria: "Bebidas" },
  "7896183100355": { nome: "Cerveja Brahma Lata 350ml", categoria: "Bebidas" },
  "7896183100058": { nome: "Cerveja Skol Lata 350ml", categoria: "Bebidas" },
  "7896183100102": { nome: "Cerveja Antarctica Lata 350ml", categoria: "Bebidas" },
  "7891991301416": { nome: "Cerveja Heineken Lata 350ml", categoria: "Bebidas" },
  "7898215151776": { nome: "Leite Integral Itambé 1L", categoria: "Laticínios" },
  "7896051130079": { nome: "Leite Integral Parmalat 1L", categoria: "Laticínios" },
  "7898080640029": { nome: "Leite Integral Piracanjuba 1L", categoria: "Laticínios" },
  "7896397000485": { nome: "Leite Condensado Moça 395g", categoria: "Laticínios" },
  "7896397000416": { nome: "Creme de Leite Nestlé 200g", categoria: "Laticínios" },
  "7891025101651": { nome: "Manteiga Aviação com Sal 200g", categoria: "Laticínios" },
  "7891515902316": { nome: "Iogurte Danone Natural 170g", categoria: "Laticínios" },
  "7896085812022": { nome: "Margarina Qualy 500g", categoria: "Laticínios" },
  "7896006744214": { nome: "Arroz Camil Tipo 1 5kg", categoria: "Mercearia" },
  "7896006700029": { nome: "Arroz Camil 1kg", categoria: "Mercearia" },
  "7896006740001": { nome: "Arroz Camil 2kg", categoria: "Mercearia" },
  "7896084600027": { nome: "Arroz Tio João 5kg", categoria: "Mercearia" },
  "7896084600010": { nome: "Arroz Tio João 1kg", categoria: "Mercearia" },
  "7891080100035": { nome: "Feijão Carioca Kicaldo 1kg", categoria: "Mercearia" },
  "7891000315002": { nome: "Macarrão Miojo Nissin Galinha 85g", categoria: "Mercearia" },
  "7891000100036": { nome: "Macarrão Miojo Nissin Carne 85g", categoria: "Mercearia" },
  "7896001270017": { nome: "Açúcar Cristal União 1kg", categoria: "Mercearia" },
  "7896001270031": { nome: "Açúcar Refinado União 1kg", categoria: "Mercearia" },
  "7896036090084": { nome: "Sal Refinado Cisne 1kg", categoria: "Mercearia" },
  "7896102500008": { nome: "Farinha de Trigo Renata 1kg", categoria: "Mercearia" },
  "7891132010300": { nome: "Óleo de Soja Liza 900ml", categoria: "Mercearia" },
  "7891132010157": { nome: "Óleo de Soja Soya 900ml", categoria: "Mercearia" },
  "7896040800099": { nome: "Extrato de Tomate Elefante 190g", categoria: "Mercearia" },
  "7897772100029": { nome: "Molho de Tomate Heinz 340g", categoria: "Mercearia" },
  "7622210575975": { nome: "Bis Lacta 126g", categoria: "Biscoitos" },
  "7622300988853": { nome: "Oreo Original 144g", categoria: "Biscoitos" },
  "7891962047119": { nome: "Biscoito Passatempo 130g", categoria: "Biscoitos" },
  "7891962045795": { nome: "Biscoito Cream Cracker Bauducco 200g", categoria: "Biscoitos" },
  "7896003738116": { nome: "Biscoito Maisena Piraquê 200g", categoria: "Biscoitos" },
  "7891000257241": { nome: "Wafer Nestlé Baunilha 110g", categoria: "Biscoitos" },
  "7896286600018": { nome: "Biscoito Recheado Trakinas Chocolate 126g", categoria: "Biscoitos" },
  "7892840810443": { nome: "Salgadinho Cheetos 140g", categoria: "Snacks" },
  "7892840810450": { nome: "Ruffles Original 157g", categoria: "Snacks" },
  "7892840818395": { nome: "Doritos Nacho 110g", categoria: "Snacks" },
  "7622300849917": { nome: "Chocolate Lacta Ao Leite 90g", categoria: "Chocolates" },
  "7622300388728": { nome: "Chocolate Milka 100g", categoria: "Chocolates" },
  "7891000053508": { nome: "Chocolate Nestlé Alpino 90g", categoria: "Chocolates" },
  "7891000065907": { nome: "Kit Kat Nestlé 45g", categoria: "Chocolates" },
  "7891045004673": { nome: "Chocolate Hershey's Meio Amargo 92g", categoria: "Chocolates" },
  "7891000100272": { nome: "Nescau Achocolatado 400g", categoria: "Chocolates" },
  "7896259100075": { nome: "Achocolatado Toddy 400g", categoria: "Chocolates" },
  "7896045201035": { nome: "Café Pilão Torrado e Moído 500g", categoria: "Café" },
  "7896093600020": { nome: "Café Melitta Tradicional 500g", categoria: "Café" },
  "7896018400030": { nome: "Café 3 Corações Tradicional 500g", categoria: "Café" },
  "7891024141007": { nome: "Sabonete Dove Original 90g", categoria: "Higiene" },
  "7891024141038": { nome: "Sabonete Lux 85g", categoria: "Higiene" },
  "7891024038018": { nome: "Shampoo Head & Shoulders 200ml", categoria: "Higiene" },
  "7891024036540": { nome: "Shampoo Pantene 200ml", categoria: "Higiene" },
  "7891150051583": { nome: "Creme Dental Colgate 90g", categoria: "Higiene" },
  "7891150040082": { nome: "Creme Dental Sorriso 90g", categoria: "Higiene" },
  "7896016100018": { nome: "Desodorante Rexona 90g", categoria: "Higiene" },
  "7891010014629": { nome: "Desodorante Dove 50g", categoria: "Higiene" },
  "7896007017090": { nome: "Papel Higiênico Neve 12 Rolos", categoria: "Higiene" },
  "7896007060042": { nome: "Papel Higiênico Personal 12 Rolos", categoria: "Higiene" },
  "7891022000026": { nome: "Detergente Ypê 500ml", categoria: "Limpeza" },
  "7891022800015": { nome: "Detergente Limpol 500ml", categoria: "Limpeza" },
  "7896013000455": { nome: "Água Sanitária Qboa 1L", categoria: "Limpeza" },
  "7891152000027": { nome: "Sabão em Pó Omo 1kg", categoria: "Limpeza" },
  "7891152000188": { nome: "Sabão em Pó Ariel 1kg", categoria: "Limpeza" },
  "7891037500016": { nome: "Amaciante Downy 1L", categoria: "Limpeza" },
  "7896003702209": { nome: "Pão de Forma Seven Boys 450g", categoria: "Padaria" },
  "7896207400085": { nome: "Pão de Forma Pullman 450g", categoria: "Padaria" },
  "7896020001064": { nome: "Sucrilhos Kellog's 300g", categoria: "Cereais" },
  "7896020001071": { nome: "Corn Flakes Kellog's 300g", categoria: "Cereais" },
  "7896020009244": { nome: "Aveia em Flocos Quaker 500g", categoria: "Cereais" },
  "7896536900019": { nome: "Batata Palito McCain 400g", categoria: "Congelados" },
  // Conservas e Enlatados
  "7896292340503": { nome: "Milho Verde Predilecta 200g", categoria: "Mercearia" },
  "7896292340510": { nome: "Milho Verde Predilecta 170g escorrido", categoria: "Mercearia" },
  "7896292340091": { nome: "Ervilha Predilecta 200g", categoria: "Mercearia" },
  "7896292340107": { nome: "Atum Predilecta em Óleo 170g", categoria: "Mercearia" },
  "7896292340466": { nome: "Sardinha Predilecta em Óleo 125g", categoria: "Mercearia" },
  "7896292340473": { nome: "Sardinha Predilecta Molho de Tomate 125g", categoria: "Mercearia" },
  "7896036091319": { nome: "Milho Verde Bonduelle 200g", categoria: "Mercearia" },
  "7896036091302": { nome: "Ervilha Bonduelle 200g", categoria: "Mercearia" },
  "7891167021011": { nome: "Atum Coqueiro em Óleo 170g", categoria: "Mercearia" },
  "7891167021028": { nome: "Sardinha Coqueiro em Óleo 125g", categoria: "Mercearia" },
  "7896292340282": { nome: "Atum Gomes da Costa em Óleo 170g", categoria: "Mercearia" },
  "7896036091289": { nome: "Milho Verde Quero 200g", categoria: "Mercearia" },
  "7896036091272": { nome: "Molho de Tomate Quero 520g", categoria: "Mercearia" },
  // Temperos, Condimentos e Molhos
  "7896098900016": { nome: "Maionese Hellmann's 500g", categoria: "Mercearia" },
  "7896098900023": { nome: "Ketchup Heinz 397g", categoria: "Mercearia" },
  "7896098900047": { nome: "Mostarda Heinz 200g", categoria: "Mercearia" },
  "7896004004026": { nome: "Caldo de Galinha Knorr 57g", categoria: "Mercearia" },
  "7896004004019": { nome: "Caldo de Carne Knorr 57g", categoria: "Mercearia" },
  "7896004004033": { nome: "Tempero Completo Knorr 60g", categoria: "Mercearia" },
  "7891132029180": { nome: "Colorau Arretado 100g", categoria: "Mercearia" },
  // Massas
  "7896036090022": { nome: "Macarrão Espaguete Barilla 500g", categoria: "Mercearia" },
  "7896033101011": { nome: "Macarrão Penne Barilla 500g", categoria: "Mercearia" },
  "7896098200022": { nome: "Macarrão Espaguete Renata 500g", categoria: "Mercearia" },
  // Snacks / Guloseimas
  "7891118013022": { nome: "Bala Halls Menta 28g", categoria: "Snacks" },
  "7891118013039": { nome: "Bala Halls Morango 28g", categoria: "Snacks" },
  "7622300849979": { nome: "Chiclete Trident Hortelã 8g", categoria: "Snacks" },
  "7896286600025": { nome: "Pipoca Yoki para Micro-ondas 100g", categoria: "Snacks" },
  "7896286600049": { nome: "Amendoim Crocante Yoki 150g", categoria: "Snacks" },
};

// ── Barcode lookup — 3 camadas: banco local → Open Food Facts → Cosmos ──
// Todas as APIs são gratuitas e não precisam de chave.
// Funciona tanto aqui no chat quanto hospedado no Netlify/tiiny.host.


// Cache de barcodes já buscados nesta sessão (evita buscas repetidas)
const barcodeCache = {};

async function buscarPorBarcode(codigo) {
  // 0️⃣ Cache da sessão
  if (barcodeCache[codigo] !== undefined) return barcodeCache[codigo];

  // 1️⃣ Banco local
  const local = PRODUTOS_BR[codigo];
  if (local) {
    barcodeCache[codigo] = { ...local, imagem: "", fonte: "Base BR Local ⚡" };
    return barcodeCache[codigo];
  }

  // 2️⃣ Claude com Web Search
  for (let tentativa = 0; tentativa < 3; tentativa++) {
    try {
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 400,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          system: `Você identifica produtos brasileiros pelo código EAN/barcode.\nUse web_search para pesquisar o código e descobrir o produto real.\nPesquise em sites como: Meli, Google Shopping, Embalagem, Tudo Gostoso, qualquer loja.\nResponda SOMENTE com JSON puro (sem markdown, sem explicação):\nEncontrou: {"nome":"nome completo do produto","categoria":"categoria","encontrado":true}\nNão encontrou: {"encontrado":false}\nNUNCA invente. Só confirme o que encontrar na busca.\nCategorias válidas: Bebidas, Laticínios, Mercearia, Biscoitos, Chocolates, Snacks, Higiene, Limpeza, Padaria, Cereais, Congelados, Café, Outros`,
          messages: [{ role: "user", content: `Código de barras EAN: ${codigo}. Qual é esse produto? Busque na internet e me diga o nome exato.` }]
        }),
      });

      if (!resp.ok) {
        const status = resp.status;
        if (status === 429 || status === 529 || status === 503) {
          await new Promise(r => setTimeout(r, (tentativa + 1) * 2000));
          continue;
        }
        return { erro: `Erro ${status} na API`, encontrado: false };
      }

      const d = await resp.json();
      const textos = (d.content || []).filter(b => b.type === "text");
      const text = (textos[textos.length - 1]?.text || "")
        .replace(/```[a-z]*/g, "").replace(/```/g, "").trim();

      if (text) {
        const parsed = JSON.parse(text);
        if (parsed.encontrado && parsed.nome) {
          const resultado = { nome: parsed.nome, categoria: parsed.categoria || "Outros", imagem: "", fonte: "Busca Web 🌐" };
          barcodeCache[codigo] = resultado;
          return resultado;
        }
        barcodeCache[codigo] = null;
        return null;
      }
    } catch (e) {
      if (tentativa < 2) { await new Promise(r => setTimeout(r, 1500)); continue; }
      return { erro: "Sem conexão. Verifique a internet e tente de novo.", encontrado: false };
    }
  }
  return { erro: "Serviço temporariamente indisponível. Aguarde alguns segundos e tente de novo.", encontrado: false };
}
// ── Helpers ─────────────────────────────────────────────────────
const fmt = (v) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v ?? 0);

function calcLiquido(valor, forma, taxas) {
  const t = taxas[forma] ?? 0;
  return valor * (1 - t / 100);
}

function today() {
  return new Date().toISOString().split("T")[0];
}

function filterByPeriod(vendas, periodo) {
  const now = new Date();
  return vendas.filter((v) => {
    const d = new Date(v.data);
    if (periodo === "dia") return d.toDateString() === now.toDateString();
    if (periodo === "semana") {
      const diff = (now - d) / 86400000;
      return diff >= 0 && diff < 7;
    }
    if (periodo === "mes") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    if (periodo === "ano") return d.getFullYear() === now.getFullYear();
    return true;
  });
}

// ── Icons (inline SVG) ──────────────────────────────────────────
const icons = {
  caixa: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <rect x={2} y={7} width={20} height={14} rx={2} />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  ),
  estoque: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2Z" />
      <path d="M12 12h.01M8 12h.01M16 12h.01" />
      <path d="M6 7V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2" />
    </svg>
  ),
  fiado: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx={9} cy={7} r={4} />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
  relatorios: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M3 3v18h18" />
      <path d="M18 17V9M13 17V5M8 17v-3" />
    </svg>
  ),
  cadastro: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx={9} cy={7} r={4} />
      <line x1={19} y1={8} x2={19} y2={14} />
      <line x1={22} y1={11} x2={16} y2={11} />
    </svg>
  ),
  compras: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
      <line x1={3} y1={6} x2={21} y2={6} />
      <path d="M16 10a4 4 0 0 1-8 0" />
    </svg>
  ),
  taxas: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={20} height={20}>
      <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
    </svg>
  ),
  trash: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={16} height={16}>
      <path d="M3 6h18M19 6l-1 14H6L5 6M10 11v6M14 11v6M9 6V4h6v2" />
    </svg>
  ),
  plus: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} width={16} height={16}>
      <line x1={12} y1={5} x2={12} y2={19} />
      <line x1={5} y1={12} x2={19} y2={12} />
    </svg>
  ),
  check: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} width={16} height={16}>
      <polyline points="20 6 9 17 4 12" />
    </svg>
  ),
};

// ══════════════════════════════════════════════════════════════════
// CAMERA SCANNER — usa BarcodeDetector nativo do Chrome/Android
// ══════════════════════════════════════════════════════════════════
function CameraScanner({ onDetected, onClose }) {
  const videoRef = React.useRef(null);
  const streamRef = React.useRef(null);
  const rafRef = React.useRef(null);
  const detectorRef = React.useRef(null);
  const [status, setStatus] = useState("iniciando");
  const [erroMsg, setErroMsg] = useState("");
  const [flashLine, setFlashLine] = useState(false);

  useEffect(() => {
    let active = true;

    const iniciar = async () => {
      try {
        // 1) Pede câmera (traseira no celular)
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        if (!active) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        // 2) Verifica se BarcodeDetector está disponível (Chrome 83+ / Android Chrome)
        if (!("BarcodeDetector" in window)) {
          setStatus("nobarcodedetector");
          return;
        }

        detectorRef.current = new window.BarcodeDetector({
          formats: ["ean_13", "ean_8", "code_128", "code_39", "upc_a", "upc_e", "qr_code", "data_matrix"]
        });

        setStatus("ativo");

        // 3) Loop de detecção
        const detectLoop = async () => {
          if (!active || !videoRef.current || videoRef.current.readyState < 2) {
            rafRef.current = requestAnimationFrame(detectLoop);
            return;
          }
          try {
            const barcodes = await detectorRef.current.detect(videoRef.current);
            if (barcodes.length > 0) {
              const code = barcodes[0].rawValue;
              if (code) {
                setFlashLine(true);
                setTimeout(() => setFlashLine(false), 400);
                setTimeout(() => { if (active) onDetected(code); }, 200);
                return; // Para o loop após detectar
              }
            }
          } catch {}
          rafRef.current = requestAnimationFrame(detectLoop);
        };
        rafRef.current = requestAnimationFrame(detectLoop);

      } catch (e) {
        if (!active) return;
        const msg = e.name === "NotAllowedError"
          ? "Permissão de câmera negada. Toque no ícone de câmera na barra do navegador e permita o acesso."
          : e.name === "NotFoundError"
          ? "Nenhuma câmera encontrada neste dispositivo."
          : "Não foi possível acessar a câmera: " + e.message;
        setErroMsg(msg);
        setStatus("erro");
      }
    };

    iniciar();

    return () => {
      active = false;
      cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, []);

  return (
    <div className="modal-overlay" style={{ zIndex: 300, background: "rgba(0,0,0,.95)", padding: 0 }}>
      <div style={{ width: "100%", maxWidth: 460, display: "flex", flexDirection: "column", gap: 0, borderRadius: 18, overflow: "hidden", background: "#11141e", border: "1px solid #2a2f45" }}>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 20px", borderBottom: "1px solid #1e2235" }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#e8eaf0", display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 20 }}>📷</span> Escanear Código de Barras
          </div>
          <button className="btn btn-ghost" onClick={onClose} style={{ padding: "6px 14px", fontSize: 13 }}>✕ Fechar</button>
        </div>

        {/* Viewfinder */}
        <div style={{ position: "relative", width: "100%", background: "#000", aspectRatio: "4/3", maxHeight: 340 }}>
          <video
            ref={videoRef}
            autoPlay playsInline muted
            style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          />

          {/* Mira de scan */}
          {status === "ativo" && (
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
              <div style={{ position: "relative", width: "72%", height: 110 }}>
                {/* Cantos */}
                {[[{top:0,left:0},{borderTopLeftRadius:4}],[{top:0,right:0},{borderTopRightRadius:4}],[{bottom:0,left:0},{borderBottomLeftRadius:4}],[{bottom:0,right:0},{borderBottomRightRadius:4}]].map(([pos, rad], i) => (
                  <div key={i} style={{ position:"absolute", width:22, height:22, borderColor: flashLine ? "#22c97a" : "#4f8ef7", borderStyle:"solid", borderWidth:0, ...Object.fromEntries(Object.entries(pos).map(([k])=>[`border${k.charAt(0).toUpperCase()+k.slice(1)}Width`,"3px"])), ...rad, transition:"border-color .2s" }} />
                ))}
                {/* Linha animada */}
                <style>{`@keyframes scanY{0%{top:6px}50%{top:calc(100% - 6px)}100%{top:6px}}.scanbar{position:absolute;left:6px;right:6px;height:2px;background:linear-gradient(90deg,transparent,${flashLine?"#22c97a":"#4f8ef7"},transparent);animation:scanY 1.8s ease-in-out infinite;transition:background .2s}`}</style>
                <div className="scanbar" />
                {/* Overlay escuro nas bordas */}
                <div style={{ position:"absolute", inset:-9999, background:"rgba(0,0,0,.45)", boxShadow:"0 0 0 9999px rgba(0,0,0,.45)", borderRadius:4 }} />
              </div>
            </div>
          )}

          {/* Iniciando */}
          {status === "iniciando" && (
            <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:10, background:"#000" }}>
              <div style={{ width:36, height:36, border:"3px solid #4f8ef7", borderTopColor:"transparent", borderRadius:"50%", animation:"spin .8s linear infinite" }} />
              <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
              <div style={{ color:"#a0a8c0", fontSize:13 }}>Iniciando câmera...</div>
            </div>
          )}

          {/* Sem BarcodeDetector */}
          {status === "nobarcodedetector" && (
            <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:10, background:"#11141e", padding:24, textAlign:"center" }}>
              <div style={{ fontSize:34 }}>⚠️</div>
              <div style={{ color:"#f0b429", fontWeight:700, fontSize:14 }}>Navegador não suportado</div>
              <div style={{ color:"#6b7499", fontSize:12, lineHeight:1.6 }}>
                Este recurso requer o <strong style={{color:"#e8eaf0"}}>Google Chrome</strong> (versão 83+) no Android ou desktop.<br/>
                Tente abrir o sistema no Chrome.
              </div>
            </div>
          )}

          {/* Erro */}
          {status === "erro" && (
            <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:10, background:"#11141e", padding:24, textAlign:"center" }}>
              <div style={{ fontSize:34 }}>🚫</div>
              <div style={{ color:"#e05260", fontWeight:700, fontSize:14 }}>Câmera indisponível</div>
              <div style={{ color:"#6b7499", fontSize:12, lineHeight:1.6 }}>{erroMsg}</div>
            </div>
          )}
        </div>

        {/* Rodapé */}
        <div style={{ padding:"14px 20px", textAlign:"center" }}>
          {status === "ativo"
            ? <div style={{ fontSize:12, color:"#6b7499", lineHeight:1.6 }}>Aponte a câmera para o código de barras.<br/>A leitura é <strong style={{color:"#4f8ef7"}}>automática</strong> — sem precisar tirar foto.</div>
            : status === "erro"
            ? <button className="btn btn-primary" onClick={onClose} style={{ width:"100%" }}>Fechar e digitar manualmente</button>
            : null
          }
        </div>
      </div>
    </div>
  );
}
function ConfirmModal({ titulo, descricao, onConfirm, onCancel }) {
  return (
    <div className="modal-overlay" style={{ zIndex: 200 }}>
      <div className="modal" style={{ maxWidth: 380, textAlign: "center" }}>
        <div style={{
          width: 56, height: 56, borderRadius: "50%",
          background: "#2e1018", border: "2px solid #e05260",
          display: "flex", alignItems: "center", justifyContent: "center",
          margin: "0 auto 16px",
        }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="#e05260" strokeWidth={2.5} width={26} height={26}>
            <path d="M3 6h18M19 6l-1 14H6L5 6M10 11v6M14 11v6M9 6V4h6v2" />
          </svg>
        </div>
        <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 8, color: "#e8eaf0" }}>{titulo}</div>
        <div style={{ fontSize: 13, color: "#6b7499", marginBottom: 24, lineHeight: 1.6 }}>{descricao}</div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-ghost" onClick={onCancel} style={{ flex: 1, padding: "11px" }}>
            Cancelar
          </button>
          <button className="btn btn-danger" onClick={onConfirm}
            style={{ flex: 1, padding: "11px", fontSize: 13 }}>
            Sim, excluir
          </button>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// MAIN APP
// ══════════════════════════════════════════════════════════════════
export default function PDV() {
  const [data, setData] = useState(loadData);
  const [aba, setAba] = useState("caixa");
  const [showBackup, setShowBackup] = useState(false);
  const [importText, setImportText] = useState("");
  const [importMsg, setImportMsg] = useState(null);
  const [carrinhoCount, setCarrinhoCount] = useState(0);



  // ── Firebase — fbStatus: "local" | "conectado" | "erro"
  const [fbStatus, setFbStatus] = useState("local");

  useEffect(() => {
    const fb = window.FirebaseDB;
    // firebase.js não configurado → modo local imediato, sem loading, sem travamento
    if (!fb || !fb.estaConfigurado()) {
      setFbStatus("local");
      return;
    }

    let unsubscribe = null;

    // 1. Carrega TODOS os dados (config + subcollections vendas/fiado/compras)
    fb.carregar().then((fbData) => {
      if (fbData && fbData.produtos) {
        const merged = { ...defaultData, ...fbData };
        saveData(merged);
        setData(merged);
      }

      // 2. onSnapshot no documento config (produtos/clientes/taxas/nextId)
      //    Atualiza em tempo real quando outro dispositivo altera o estoque ou cadastros.
      //    Vendas/fiado/compras são somente leitura após o startup (append-only).
      unsubscribe = fb.ouvir((configPartial) => {
        setData((prev) => {
          // Mescla apenas as partes do config que vieram do Firestore,
          // preservando vendas/fiado/compras já carregados na memória.
          const next = {
            ...prev,
            produtos : configPartial.produtos ?? prev.produtos,
            clientes : configPartial.clientes ?? prev.clientes,
            taxas    : configPartial.taxas    ?? prev.taxas,
            nextId   : configPartial.nextId   ?? prev.nextId,
          };
          // Só atualiza se algo realmente mudou (evita loops)
          if (JSON.stringify(next) === JSON.stringify(prev)) return prev;
          saveData(next);
          return next;
        });
      });

      setFbStatus("conectado");
    }).catch((err) => {
      console.error("[PDV] Erro ao conectar Firebase:", err);
      setFbStatus("erro");
    });

    return () => { if (unsubscribe) unsubscribe(); };
  }, []);

  // ── diffSync: detecta exatamente o que mudou e chama o CRUD correto ────
  //
  //  Estratégia de escrita no Firestore:
  //  • produtos, clientes, taxas, nextId → pdv/config (documento estável)
  //  • vendas, fiado, compras           → subcollections (crescem infinitamente)
  //
  //  Isso evita o limite de 1MB por documento e garante que a coleção
  //  de vendas nunca trave o sistema independente do volume histórico.
  const diffSync = useCallback((prev, next) => {
    const fb = window.FirebaseDB;
    if (!fb || !fb.estaConfigurado()) return;

    // ── 1. Vendas novas → subcollection /vendas ───────────────────
    const prevVIds = new Set(prev.vendas.map(v => v.id));
    next.vendas.forEach(v => {
      if (!prevVIds.has(v.id)) fb.adicionarVenda(v);
    });

    // ── 2. Fiados novos → subcollection /fiado ────────────────────
    const prevFIds = new Set(prev.fiado.map(f => f.id));
    const fiadosNovos = next.fiado.filter(f => !prevFIds.has(f.id));
    fiadosNovos.forEach(f => fb.adicionarFiado(f));

    // Quitação: fiados que mudaram de pago=false para pago=true
    const prevFMap = Object.fromEntries(prev.fiado.map(f => [f.id, f]));
    const fiadosQuitados = next.fiado.filter(f =>
      prevFMap[f.id] && !prevFMap[f.id].pago && f.pago
    );
    if (fiadosQuitados.length > 0) {
      // Identifica o clienteId e chama quitarFiado com o estado atual
      const clienteId = fiadosQuitados[0].clienteId;
      fb.quitarFiado(clienteId, next.fiado);
    }

    // ── 3. Compras novas → subcollection /compras ─────────────────
    const prevCpIds = new Set(prev.compras.map(c => c.id));
    next.compras.forEach(c => {
      if (!prevCpIds.has(c.id)) fb.adicionarCompra(c);
    });

    // ── 4. Config → pdv/config (toda vez que produtos/clientes/taxas mudam)
    //    Um único set() é mais barato que múltiplos writes por campo.
    const configMudou =
      JSON.stringify(prev.produtos) !== JSON.stringify(next.produtos) ||
      JSON.stringify(prev.clientes) !== JSON.stringify(next.clientes) ||
      JSON.stringify(prev.taxas)    !== JSON.stringify(next.taxas)    ||
      JSON.stringify(prev.nextId)   !== JSON.stringify(next.nextId);

    if (configMudou) fb.salvarConfig(next);

  }, []);

  const exportarDados = () => {
    try {
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `pdv-backup-${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch(e) {
      copiarJSON();
    }
  };

  const copiarJSON = () => {
    const json = JSON.stringify(data);
    setImportText(json);
    setImportMsg({ ok: true, msg: "✅ JSON pronto abaixo! Toque nele, segure e escolha Selecionar Tudo → Copiar." });
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(json).catch(() => {});
      }
    } catch(e) {}
  };

  const importarDados = () => {
    try {
      const parsed = JSON.parse(importText);
      if (!parsed.produtos || !parsed.clientes) {
        setImportMsg({ ok: false, msg: "❌ Arquivo inválido. Certifique-se de usar um backup gerado por este sistema." });
        return;
      }
      const merged = { ...defaultData, ...parsed };
      saveData(merged);
      setData(merged);
      try { window.FirebaseDB?.migrarDeBackup(merged); } catch {}
      setImportMsg({ ok: true, msg: `✅ Dados importados! ${merged.produtos.length} produtos, ${merged.clientes.length} clientes, ${merged.vendas.length} vendas.` });
      setTimeout(() => { setShowBackup(false); setImportText(""); setImportMsg(null); }, 2500);
    } catch(e) {
      setImportMsg({ ok: false, msg: "❌ JSON inválido. Verifique o conteúdo e tente novamente. (" + (e.message || "erro") + ")" });
    }
  };

  const importarArquivo = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setImportText(ev.target.result);
    reader.readAsText(file);
  };

  const update = useCallback((fn) => {
    setData((prev) => {
      const next = fn(prev);
      saveData(next);    // sempre salva localmente (offline-first)
      diffSync(prev, next); // sync granular por coleção no Firestore
      return next;
    });
  }, [diffSync]);

  const nextId = (key) => {
    let id;
    update((d) => {
      id = d.nextId[key];
      return { ...d, nextId: { ...d.nextId, [key]: id + 1 } };
    });
    return id;
  };

  const abas = [
    { key: "caixa", label: "Caixa", icon: icons.caixa },
    { key: "estoque", label: "Estoque", icon: icons.estoque },
    { key: "fiado", label: "Fiado", icon: icons.fiado },
    { key: "relatorios", label: "Relatórios", icon: icons.relatorios },
    { key: "cadastro", label: "Cadastro", icon: icons.cadastro },
    { key: "compras", label: "Compras", icon: icons.compras },
    { key: "taxas", label: "Taxas", icon: icons.taxas },
  ];

  return (
    <div style={{ fontFamily: "'Sora', 'Segoe UI', sans-serif", minHeight: "100vh", background: "#0f1117", color: "#e8eaf0" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #1a1d27; }
        ::-webkit-scrollbar-thumb { background: #2e3248; border-radius: 3px; }
        input, select, button { font-family: inherit; }
        .btn { border: none; cursor: pointer; border-radius: 8px; font-weight: 600; transition: all .15s; }
        .btn:hover { filter: brightness(1.12); transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }
        .btn-primary { background: #4f8ef7; color: #fff; padding: 9px 18px; font-size: 13px; }
        .btn-success { background: #22c97a; color: #fff; padding: 9px 18px; font-size: 13px; }
        .btn-danger { background: #e05260; color: #fff; padding: 7px 12px; font-size: 12px; }
        .btn-ghost { background: #1e2130; color: #a0a8c0; border: 1px solid #2a2f45; padding: 8px 14px; font-size: 13px; }
        .btn-ghost:hover { color: #e8eaf0; border-color: #4f8ef7; }
        .input { background: #1a1d27; border: 1.5px solid #2a2f45; color: #e8eaf0; padding: 9px 13px; border-radius: 8px; font-size: 13px; width: 100%; transition: border .15s; outline: none; }
        .input:focus { border-color: #4f8ef7; }
        .card { background: #161923; border: 1px solid #22263a; border-radius: 14px; padding: 20px; }
        .tag { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
        .tag-green { background: #163829; color: #22c97a; }
        .tag-yellow { background: #2e2510; color: #f0b429; }
        .tag-red { background: #2e1018; color: #e05260; }
        .tag-blue { background: #0e1e3a; color: #4f8ef7; }
        .table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .table th { padding: 10px 12px; text-align: left; font-weight: 600; color: #6b7499; border-bottom: 1px solid #22263a; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; }
        .table td { padding: 10px 12px; border-bottom: 1px solid #1a1d27; }
        .table tr:hover td { background: #1a1d27; }
        .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        .grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; }
        .grid4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
        @media(max-width:700px){.grid2,.grid3,.grid4{grid-template-columns:1fr 1fr;} .sidebar{display:none!important;} }
        @media(max-width:480px){.grid2,.grid3,.grid4{grid-template-columns:1fr;} }
        .sidebar { width: 200px; min-height: 100vh; background: #11141e; border-right: 1px solid #1e2235; padding: 20px 14px; position: fixed; top: 0; left: 0; z-index: 10; display: flex; flex-direction: column; gap: 4px; }
        .main-content { margin-left: 200px; padding: 24px; min-height: 100vh; }
        @media(max-width:700px){ .main-content { margin-left: 0; padding: 12px; } }
        .nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; cursor: pointer; transition: all .15s; font-size: 13px; font-weight: 500; color: #6b7499; }
        .nav-item:hover { background: #1a1d27; color: #c0c8e0; }
        .nav-item.active { background: #1a2545; color: #4f8ef7; }
        .mobile-nav { display: none; }
        @media(max-width:700px){ .mobile-nav { display: flex; position: fixed; bottom: 0; left: 0; right: 0; background: #11141e; border-top: 1px solid #1e2235; z-index: 20; justify-content: space-around; } .mobile-nav-item { flex: 1; display: flex; flex-direction: column; align-items: center; padding: 10px 4px 8px; font-size: 9px; gap: 4px; cursor: pointer; color: #6b7499; } .mobile-nav-item.active { color: #4f8ef7; } }
        .stat-card { background: #161923; border: 1px solid #22263a; border-radius: 14px; padding: 18px; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 100; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .modal { background: #161923; border: 1px solid #2a2f45; border-radius: 16px; padding: 24px; width: 100%; max-width: 460px; max-height: 90vh; overflow-y: auto; }
        .section-title { font-size: 22px; font-weight: 700; color: #e8eaf0; margin-bottom: 20px; }
        .label { font-size: 12px; font-weight: 600; color: #6b7499; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .5px; }
        .badge-pix { background: #0d2c1e; color: #22c97a; }
        .badge-credito { background: #0e1e3a; color: #4f8ef7; }
        .badge-debito { background: #2a1a3a; color: #b57cf7; }
        .badge-dinheiro { background: #2e2510; color: #f0b429; }
        .badge-fiado { background: #2e1018; color: #e05260; }
      `}</style>


      {/* Modal Backup */}
      {showBackup && (
        <div className="modal-overlay" style={{ zIndex: 200 }}>
          <div className="modal" style={{ maxWidth: 480 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}>
              💾 Backup de Dados
            </div>
            <div style={{ fontSize: 12, color: "#6b7499", marginBottom: 20, lineHeight: 1.6 }}>
              Exporte seus dados para levar para outro dispositivo ou servidor. Importe um backup para restaurar seus produtos, clientes e vendas.
            </div>

            {/* EXPORTAR */}
            <div style={{ background: "#11141e", borderRadius: 12, padding: 16, marginBottom: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: "#22c97a", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
                ⬇️ Exportar meus dados
              </div>
              <div style={{ fontSize: 12, color: "#6b7499", marginBottom: 12, lineHeight: 1.5 }}>
                Gera um arquivo <strong style={{ color: "#e8eaf0" }}>.json</strong> com todos os seus produtos, clientes, vendas, compras e configurações.
                Salve esse arquivo e importe no outro sistema.
              </div>
              <div style={{ display: "flex", gap: 10, alignItems: "center", fontSize: 12, color: "#6b7499", marginBottom: 12 }}>
                <span>📦 {data.produtos.length} produtos</span>
                <span>👥 {data.clientes.length} clientes</span>
                <span>🧾 {data.vendas.length} vendas</span>
              </div>
              <button className="btn btn-success" onClick={exportarDados} style={{ width: "100%", padding: 11, fontSize: 13, marginBottom: 8 }}>
                ⬇️ Baixar Backup (.json)
              </button>
              <button className="btn" onClick={copiarJSON}
                style={{ width: "100%", padding: 11, fontSize: 13, background: "#1a2545", color: "#4f8ef7", border: "1.5px solid #4f8ef7" }}>
                📋 Ver / Copiar JSON (celular)
              </button>
            </div>

            {/* IMPORTAR */}
            <div style={{ background: "#11141e", borderRadius: 12, padding: 16, marginBottom: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: "#4f8ef7", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
                ⬆️ Importar backup
              </div>
              <div style={{ fontSize: 12, color: "#6b7499", marginBottom: 12, lineHeight: 1.5 }}>
                Selecione o arquivo .json exportado anteriormente ou cole o conteúdo abaixo.
              </div>
              <label style={{ display: "block", marginBottom: 10 }}>
                <div style={{ background: "#1a2545", border: "1.5px dashed #4f8ef7", borderRadius: 8, padding: "12px", textAlign: "center", cursor: "pointer", fontSize: 13, color: "#4f8ef7", fontWeight: 600 }}>
                  📂 Clique para selecionar arquivo .json
                </div>
                <input type="file" accept=".json" onChange={importarArquivo} style={{ display: "none" }} />
              </label>
              <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6, textAlign: "center" }}>— ou cole o JSON abaixo —</div>
              <textarea
                className="input"
                placeholder='{"produtos":[...],"clientes":[...],...}'
                value={importText}
                onChange={e => { setImportText(e.target.value); setImportMsg(null); }}
                style={{ height: 90, resize: "vertical", fontSize: 11, fontFamily: "monospace" }}
              />
              {importMsg && (
                <div style={{ marginTop: 8, padding: "9px 12px", borderRadius: 8, fontSize: 12, fontWeight: 600,
                  background: importMsg.ok ? "#163829" : "#2e1018",
                  color: importMsg.ok ? "#22c97a" : "#e05260",
                  border: `1px solid ${importMsg.ok ? "#22c97a44" : "#e0526044"}` }}>
                  {importMsg.msg}
                </div>
              )}
              <button className="btn btn-primary" onClick={importarDados}
                disabled={!importText.trim()}
                style={{ width: "100%", padding: 11, fontSize: 13, marginTop: 10, opacity: importText.trim() ? 1 : 0.5 }}>
                ⬆️ Importar e Restaurar Dados
              </button>
            </div>

            <button className="btn btn-ghost" onClick={() => { setShowBackup(false); setImportText(""); setImportMsg(null); }}
              style={{ width: "100%", padding: 10 }}>Fechar</button>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <div className="sidebar">
        <div style={{ marginBottom: 24, paddingLeft: 4 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#4f8ef7", letterSpacing: -0.5 }}>⚡ PDV Pro</div>
          <div style={{ fontSize: 11, color: "#6b7499", marginTop: 2 }}>Sistema de Vendas</div>
        </div>
        {abas.map((a) => (
          <div key={a.key} className={`nav-item ${aba === a.key ? "active" : ""}`} onClick={() => setAba(a.key)}>
            {a.icon} {a.label}
          </div>
        ))}
        <div style={{ marginTop: "auto", paddingTop: 16, borderTop: "1px solid #1e2235" }}>
          {/* Status Firebase */}
          <div style={{
            display: "flex", alignItems: "center", gap: 7,
            padding: "7px 10px", borderRadius: 8, marginBottom: 8, fontSize: 11, fontWeight: 600,
            background: fbStatus === "conectado" ? "#0d2c1e" : fbStatus === "erro" ? "#2e1018" : "#1a1d27",
            color:      fbStatus === "conectado" ? "#22c97a" : fbStatus === "erro" ? "#e05260" : "#6b7499",
          }}>
            <span style={{ fontSize: 14 }}>
              {fbStatus === "conectado" ? "☁️" : fbStatus === "erro" ? "⚠️" : "💾"}
            </span>
            {fbStatus === "conectado" ? "☁️ Nuvem ativa" : fbStatus === "erro" ? "⚠️ Erro Firebase" : "💾 Modo Local"}
          </div>
          <button className="btn btn-ghost" onClick={() => setShowBackup(true)}
            style={{ width: "100%", fontSize: 12, padding: "9px 10px", display: "flex", alignItems: "center", gap: 7 }}>
            💾 Backup / Importar
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      <div className="mobile-nav">
        {abas.map((a) => (
          <div key={a.key} className={`mobile-nav-item ${aba === a.key ? "active" : ""}`} onClick={() => setAba(a.key)} style={{ position: "relative" }}>
            {a.icon}
            {a.key === "caixa" && carrinhoCount > 0 && (
              <span style={{ position: "absolute", top: 6, right: "50%", transform: "translateX(10px)", background: "#e05260", color: "#fff", borderRadius: "50%", width: 16, height: 16, fontSize: 9, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {carrinhoCount > 9 ? "9+" : carrinhoCount}
              </span>
            )}
            <span>{a.label}</span>
          </div>
        ))}
        <div className="mobile-nav-item" onClick={() => setShowBackup(true)}>
          <span style={{ fontSize: 16 }}>💾</span>
          <span>Backup</span>
        </div>
      </div>

      {/* Content */}
      <div className="main-content" style={{ paddingBottom: 80 }}>
        {aba === "caixa" && <AbaCaixa data={data} update={update} onCarrinhoChange={setCarrinhoCount} />}
        {aba === "estoque" && <AbaEstoque data={data} update={update} />}
        {aba === "fiado" && <AbaFiado data={data} update={update} />}
        {aba === "relatorios" && <AbaRelatorios data={data} update={update} />}
        {aba === "cadastro" && <AbaCadastro data={data} update={update} />}
        {aba === "compras" && <AbaCompras data={data} update={update} />}
        {aba === "taxas" && <AbaTaxas data={data} update={update} />}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// ABA CAIXA
// ══════════════════════════════════════════════════════════════════
function AbaCaixa({ data, update, onCarrinhoChange }) {
  const [carrinho, setCarrinho] = useState([]);
  const [busca, setBusca] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [barcodeStatus, setBarcodeStatus] = useState(null);
  const [barcodeMsg, setBarcodeMsg] = useState("");
  const [estoqueAviso, setEstoqueAviso] = useState(null);
  const [pagamento, setPagamento] = useState("dinheiro");
  const [clienteFiado, setClienteFiado] = useState("");
  const [desconto, setDesconto] = useState(0);
  const [sucesso, setSucesso] = useState(false);
  const [sucessoMsg, setSucessoMsg] = useState("");
  const [valorRecebido, setValorRecebido] = useState("");
  const [showCamera, setShowCamera] = useState(false);
  // Notifica PDV do tamanho do carrinho para o badge
  useEffect(() => {
    const total = carrinho.reduce((s, i) => s + i.qty, 0);
    onCarrinhoChange?.(total);
  }, [carrinho, onCarrinhoChange]);

  // ── Serviço / Troco na Maquininha ──
  const [showServico, setShowServico] = useState(false);
  const [svcDescricao, setSvcDescricao] = useState("");
  const [svcValorCobrado, setSvcValorCobrado] = useState("");
  const [svcValorEntregue, setSvcValorEntregue] = useState("");
  const [svcPagamento, setSvcPagamento] = useState("credito");

  const svcTaxa = data.taxas[svcPagamento] ?? 0;
  const svcLiquido = Number(svcValorCobrado) * (1 - svcTaxa / 100);
  const svcTaxaValor = Number(svcValorCobrado) - svcLiquido;
  const svcLucro = svcLiquido - Number(svcValorEntregue);

  const finalizarServico = () => {
    if (!svcValorCobrado || Number(svcValorCobrado) <= 0) return;
    const id = data.nextId.venda;
    const desc = svcDescricao || "Serviço / Troco na Maquininha";
    const venda = {
      id, data: new Date().toISOString(),
      itens: [{ id: 0, nome: desc, qty: 1, preco: Number(svcValorCobrado) }],
      subtotal: Number(svcValorCobrado),
      desconto: 0,
      total: Number(svcValorCobrado),
      liquido: svcLiquido,
      taxaValor: svcTaxaValor,
      pagamento: svcPagamento,
      tipo: "servico",
      valorEntregue: Number(svcValorEntregue) || 0,
      lucroServico: svcLucro,
      clienteId: null,
    };
    update((d) => ({
      ...d,
      vendas: [...d.vendas, venda],
      nextId: { ...d.nextId, venda: id + 1 },
    }));
    setShowServico(false);
    setSvcDescricao(""); setSvcValorCobrado(""); setSvcValorEntregue(""); setSvcPagamento("credito");
    setSucessoMsg(`Serviço registrado! Você cobrou ${fmt(Number(svcValorCobrado))} e recebeu líquido ${fmt(svcLiquido)}.`);
    setSucesso(true); setTimeout(() => { setSucesso(false); setSucessoMsg(""); }, 3500);
  };

  const produtosFiltrados = data.produtos.filter((p) => {
    if (p.estoque <= 0) return false;
if (!busca.trim()) return true;
    return p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      (p.barcode && p.barcode.includes(busca)) ||
      (p.codigo && p.codigo.toLowerCase().includes(busca.toLowerCase()));
  });

  const addItem = (prod) => {
    const noCarrinho = carrinho.find(i => i.id === prod.id);
    const qtyNoCarrinho = noCarrinho ? noCarrinho.qty : 0;
    const qtyAposAdd = qtyNoCarrinho + 1;

    if (prod.estoque <= 0) {
      setEstoqueAviso({ nome: prod.nome, estoque: prod.estoque, qty: qtyAposAdd });
    } else if (qtyAposAdd > prod.estoque) {
      setEstoqueAviso({ nome: prod.nome, estoque: prod.estoque, qty: qtyAposAdd });
    }

    setCarrinho((c) => {
      const ex = c.find((i) => i.id === prod.id);
      if (ex) return c.map((i) => (i.id === prod.id ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { ...prod, qty: 1 }];
    });
  };

  const handleBarcodeCaixa = async (cod) => {
    const c = cod.trim();
    if (!c) return;
    const local = data.produtos.find((p) => p.barcode === c && p.estoque > 0);
    if (local) {
      addItem(local);
      setBarcodeStatus("ok");
      setBarcodeMsg("✅ " + local.nome + " adicionado ao carrinho!");
      setBarcodeInput("");
      setTimeout(() => { setBarcodeStatus(null); setBarcodeMsg(""); }, 2500);
      return;
    }
    // Busca por código interno
    const porCodigo = data.produtos.find((p) => p.codigo && p.codigo.toLowerCase() === c.toLowerCase() && p.estoque > 0);
    if (porCodigo) {
      addItem(porCodigo);
      setBarcodeStatus("ok");
      setBarcodeMsg("✅ " + porCodigo.nome + " adicionado ao carrinho!");
      setBarcodeInput("");
      setTimeout(() => { setBarcodeStatus(null); setBarcodeMsg(""); }, 2500);
      return;
    }
    const semEstoque = data.produtos.find((p) => (p.barcode === c || (p.codigo && p.codigo.toLowerCase() === c.toLowerCase())) && p.estoque <= 0);
    if (semEstoque) {
      setBarcodeStatus("warn");
      setBarcodeMsg("⚠️ \"" + semEstoque.nome + "\" está sem estoque");
      setTimeout(() => { setBarcodeStatus(null); setBarcodeMsg(""); }, 3000);
      return;
    }
    setBarcodeStatus("loading");
    setBarcodeMsg("🔍 Produto não cadastrado. Buscando nome online...");
    const info = await buscarPorBarcode(c);
    if (info) {
      setBarcodeStatus("nocadastro");
      setBarcodeMsg("📦 \"" + info.nome + "\" encontrado via " + info.fonte + " — Cadastre no Estoque com preço e quantidade para vender.");
    } else {
      setBarcodeStatus("notfound");
      setBarcodeMsg("❌ Código " + c + " não encontrado. Cadastre manualmente no Estoque.");
    }
    setTimeout(() => { setBarcodeStatus(null); setBarcodeMsg(""); }, 7000);
  };

  const removeItem = (id) => setCarrinho((c) => c.filter((i) => i.id !== id));
  const setQty = (id, qty) => {
    const max = data.produtos.find((p) => p.id === id)?.estoque ?? qty;
    const v = Math.max(1, Math.min(qty, max));
    setCarrinho((c) => c.map((i) => (i.id === id ? { ...i, qty: v } : i)));
  };

  const subtotal = carrinho.reduce((s, i) => s + i.preco * i.qty, 0);
  const totalComDesc = Math.max(0, subtotal - Number(desconto));
  const liquido = calcLiquido(totalComDesc, pagamento, data.taxas);
  const taxaValor = totalComDesc - liquido;

  const finalizar = () => {
    if (!carrinho.length) return;
    if (pagamento === "fiado" && !clienteFiado) return alert("Selecione um cliente para o fiado.");
    const id = data.nextId.venda;
    const venda = {
      id, data: new Date().toISOString(),
      itens: carrinho.map((i) => ({ id: i.id, nome: i.nome, qty: i.qty, preco: i.preco })),
      subtotal, desconto: Number(desconto), total: totalComDesc, liquido, taxaValor, pagamento,
      clienteId: pagamento === "fiado" ? Number(clienteFiado) : null,
    };
    update((d) => {
      const novosProdutos = d.produtos.map((p) => {
        const item = carrinho.find((i) => i.id === p.id);
        return item ? { ...p, estoque: p.estoque - item.qty } : p;
      });
      let novoFiado = d.fiado;
      let novosClientes = d.clientes;
      if (pagamento === "fiado") {
        const cid = Number(clienteFiado);
        novoFiado = [...d.fiado, { id: d.nextId.fiado, clienteId: cid, vendaId: id, valor: totalComDesc, data: new Date().toISOString(), pago: false }];
        novosClientes = d.clientes.map((c) => (c.id === cid ? { ...c, saldo: c.saldo + totalComDesc } : c));
      }
      return { ...d, produtos: novosProdutos, vendas: [...d.vendas, venda], fiado: novoFiado, clientes: novosClientes,
        nextId: { ...d.nextId, venda: id + 1, fiado: pagamento === "fiado" ? d.nextId.fiado + 1 : d.nextId.fiado } };
    });
    setCarrinho([]); setDesconto(0); setPagamento("dinheiro"); setClienteFiado(""); setValorRecebido("");
    setSucesso(true); setTimeout(() => setSucesso(false), 2000);
  };

  const vendaHoje = data.vendas
    .filter((v) => new Date(v.data).toDateString() === new Date().toDateString())
    .reduce((s, v) => s + v.total, 0);

  const stMap = {
    ok:         { bg: "#163829", color: "#22c97a", border: "#22c97a" },
    warn:       { bg: "#2e2510", color: "#f0b429", border: "#f0b429" },
    nocadastro: { bg: "#2e2510", color: "#f0b429", border: "#f0b429" },
    notfound:   { bg: "#2e1018", color: "#e05260", border: "#e05260" },
    loading:    { bg: "#0e1e3a", color: "#4f8ef7", border: "#4f8ef7" },
  };
  const st = stMap[barcodeStatus] || {};

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20, flexWrap: "wrap", gap: 10 }}>
        <div className="section-title" style={{ margin: 0 }}>🛒 Caixa</div>
        <button
          className="btn"
          onClick={() => setShowServico(true)}
          style={{ background: "#1a1e35", border: "1.5px solid #7c5cf7", color: "#b57cf7", padding: "9px 16px", fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", gap: 7 }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} width={16} height={16}><circle cx={12} cy={12} r={10}/><path d="M12 8v4M12 16h.01"/></svg>
          Venda de Serviço
        </button>
      </div>

      {sucesso && (
        <div style={{ background: "#163829", border: "1px solid #22c97a", color: "#22c97a", padding: "12px 16px", borderRadius: 10, marginBottom: 16, fontWeight: 600, display: "flex", alignItems: "center", gap: 8 }}>
          {icons.check} {sucessoMsg || "Venda finalizada com sucesso!"}
        </div>
      )}

      {/* ── Modal Serviço / Troco na Maquininha ── */}
      {showServico && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 420 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 20 }}>💳</span> Venda de Serviço
            </div>
            <div style={{ fontSize: 12, color: "#6b7499", marginBottom: 20, lineHeight: 1.5 }}>
              Use para cobrar serviços na maquininha e calcular quanto você realmente recebe após a taxa.<br/>
              Ex: cobra R$6 no cartão → entrega R$5 em dinheiro → lucro é o que sobrar da taxa.
            </div>

            <div style={{ marginBottom: 12 }}>
              <div className="label">Descrição do Serviço (opcional)</div>
              <input className="input" placeholder="Ex: Troco na maquininha, Recarga, Serviço..." value={svcDescricao} onChange={e => setSvcDescricao(e.target.value)} />
            </div>

            <div className="label" style={{ marginBottom: 8 }}>Forma de Cobrança</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6, marginBottom: 14 }}>
              {["credito", "debito", "pix"].map(f => (
                <button key={f} className="btn" onClick={() => setSvcPagamento(f)}
                  style={{ padding: "8px 6px", fontSize: 12, fontWeight: 600,
                    background: svcPagamento === f ? "#1a2545" : "#1e2130",
                    color: svcPagamento === f ? "#4f8ef7" : "#6b7499",
                    border: `1.5px solid ${svcPagamento === f ? "#4f8ef7" : "#22263a"}` }}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}<br/>
                  <span style={{ fontSize: 10, opacity: .7 }}>taxa {data.taxas[f] ?? 0}%</span>
                </button>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
              <div>
                <div className="label">💳 Valor Cobrado (R$)</div>
                <input type="number" className="input" placeholder="0,00" value={svcValorCobrado} min={0} onChange={e => setSvcValorCobrado(e.target.value)} />
              </div>
              <div>
                <div className="label">💵 Valor Entregue (R$)</div>
                <input type="number" className="input" placeholder="0,00" value={svcValorEntregue} min={0} onChange={e => setSvcValorEntregue(e.target.value)} />
              </div>
            </div>

            {/* Resumo em tempo real */}
            {Number(svcValorCobrado) > 0 && (
              <div style={{ background: "#11141e", borderRadius: 12, padding: 14, marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6, color: "#6b7499" }}>
                  <span>Valor cobrado</span><span style={{ color: "#e8eaf0", fontWeight: 600 }}>{fmt(Number(svcValorCobrado))}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6, color: "#6b7499" }}>
                  <span>Taxa {svcPagamento} ({svcTaxa}%)</span>
                  <span style={{ color: "#e05260", fontWeight: 600 }}>- {fmt(svcTaxaValor)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6, color: "#6b7499", borderTop: "1px solid #22263a", paddingTop: 8 }}>
                  <span>Você recebe líquido</span>
                  <span style={{ color: "#4f8ef7", fontWeight: 700 }}>{fmt(svcLiquido)}</span>
                </div>
                {Number(svcValorEntregue) > 0 && (
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6, color: "#6b7499" }}>
                    <span>Valor entregue em dinheiro</span>
                    <span style={{ color: "#f0b429", fontWeight: 600 }}>- {fmt(Number(svcValorEntregue))}</span>
                  </div>
                )}
                <div style={{
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  borderTop: "1px solid #22263a", paddingTop: 10, marginTop: 4
                }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#a0a8c0" }}>SEU LUCRO</span>
                  <span style={{ fontSize: 22, fontWeight: 800, color: svcLucro >= 0 ? "#22c97a" : "#e05260" }}>
                    {fmt(svcLucro)}
                  </span>
                </div>
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-success" onClick={finalizarServico}
                disabled={!svcValorCobrado || Number(svcValorCobrado) <= 0}
                style={{ flex: 1, opacity: (!svcValorCobrado || Number(svcValorCobrado) <= 0) ? 0.5 : 1 }}>
                ✓ Registrar Serviço
              </button>
              <button className="btn btn-ghost" onClick={() => { setShowServico(false); setSvcDescricao(""); setSvcValorCobrado(""); setSvcValorEntregue(""); }}
                style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Leitor de Código de Barras ── */}
      <div style={{ marginBottom: 18 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <div style={{ position: "relative", flex: 1, maxWidth: 480 }}>
            <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 18, pointerEvents: "none" }}>🔖</span>
            <input
              className="input"
              placeholder="Escaneie ou digite o código de barras + Enter..."
              value={barcodeInput}
              onChange={(e) => { setBarcodeInput(e.target.value); setBarcodeStatus(null); setBarcodeMsg(""); }}
              onKeyDown={(e) => { if (e.key === "Enter") handleBarcodeCaixa(barcodeInput); }}
              style={{ paddingLeft: 40, fontFamily: "monospace", letterSpacing: 1.5, fontSize: 14 }}
              autoFocus
            />
          </div>
          <button className="btn btn-primary" onClick={() => handleBarcodeCaixa(barcodeInput)} disabled={barcodeStatus === "loading"} style={{ whiteSpace: "nowrap", minWidth: 110 }}>
            {barcodeStatus === "loading" ? "Buscando..." : "▶ Adicionar"}
          </button>
          <button
            className="btn"
            onClick={() => setShowCamera(true)}
            title="Abrir câmera para escanear código de barras"
            style={{ background: "#1a2545", color: "#4f8ef7", border: "1.5px solid #4f8ef7", padding: "9px 13px", fontSize: 18 }}
          >
            📷
          </button>
        </div>
        {barcodeMsg && (
          <div style={{ marginTop: 8, padding: "10px 14px", borderRadius: 8, background: st.bg, color: st.color, border: "1px solid " + st.border, fontSize: 13, fontWeight: 500, lineHeight: 1.5 }}>
            {barcodeMsg}
          </div>
        )}
        <div style={{ fontSize: 11, color: "#6b7499", marginTop: 6, paddingLeft: 2 }}>
          💡 Use o leitor USB, digite o código ou clique em 📷 para usar a câmera do celular.
        </div>
      </div>

      {/* ── Modal Câmera ── */}
      {showCamera && (
        <CameraScanner
          onDetected={(cod) => {
            setShowCamera(false);
            setBarcodeInput(cod);
            handleBarcodeCaixa(cod);
          }}
          onClose={() => setShowCamera(false)}
        />
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20 }}>
        {/* Produtos */}
        <div>
          <input className="input" placeholder="🔍 Buscar por nome ou código de barras..." value={busca} onChange={(e) => setBusca(e.target.value)} style={{ marginBottom: 10 }} />

          {estoqueAviso && (
            <div style={{ background: "#2e2510", border: "1px solid #f0b42966", borderRadius: 8, padding: "10px 14px", marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontSize: 13, color: "#f0b429" }}>
                ⚠️ <strong>{estoqueAviso.nome}</strong> — estoque: {estoqueAviso.estoque} un.{estoqueAviso.estoque <= 0 ? " (zerado)" : ", carrinho: " + estoqueAviso.qty + " un."}
              </div>
              <button onClick={() => setEstoqueAviso(null)} style={{ background: "none", border: "none", color: "#6b7499", cursor: "pointer", fontSize: 16, lineHeight: 1 }}>✕</button>
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 10, maxHeight: 360, overflowY: "auto" }}>
            {produtosFiltrados.map((p) => (
              <div key={p.id} onClick={() => addItem(p)} className="card" style={{ cursor: "pointer", transition: "border .15s", border: "1px solid #22263a" }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = "#4f8ef7")}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = "#22263a")}>
                {p.imagem && <img src={p.imagem} alt="" style={{ width: "100%", height: 44, objectFit: "contain", borderRadius: 6, background: "#fff", marginBottom: 6 }} onError={(e) => { e.target.style.display = "none"; }} />}
                <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 3 }}>{p.categoria}</div>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6, lineHeight: 1.3 }}>{p.nome}</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#4f8ef7" }}>{fmt(p.preco)}</div>
                <div style={{ fontSize: 11, color: "#6b7499", marginTop: 3 }}>Estoque: {p.estoque}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Carrinho */}
        <div>
          <div className="card">
            <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14, color: "#a0a8c0" }}>CARRINHO</div>
            {carrinho.length === 0 ? (
              <div style={{ textAlign: "center", color: "#6b7499", padding: "30px 0", fontSize: 13 }}>Nenhum item adicionado</div>
            ) : (
              <div style={{ maxHeight: 200, overflowY: "auto", marginBottom: 14 }}>
                {carrinho.map((item) => (
                  <div key={item.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                    <div style={{ flex: 1, fontSize: 12 }}>{item.nome}</div>
                    <input type="number" className="input" value={item.qty} min={1}
                      onChange={(e) => setQty(item.id, Number(e.target.value))}
                      style={{ width: 52, textAlign: "center", padding: "5px 4px" }} />
                    <div style={{ width: 70, fontSize: 12, fontWeight: 600, textAlign: "right" }}>{fmt(item.preco * item.qty)}</div>
                    <button className="btn btn-danger" onClick={() => removeItem(item.id)} style={{ padding: "5px 7px" }}>{icons.trash}</button>
                  </div>
                ))}
              </div>
            )}

            <div style={{ borderTop: "1px solid #22263a", paddingTop: 12, marginBottom: 12 }}>
              <div className="label" style={{ marginBottom: 5 }}>Desconto (R$)</div>
              <input type="number" className="input" value={desconto} min={0} onChange={(e) => setDesconto(e.target.value)} style={{ marginBottom: 10 }} />

              <div className="label" style={{ marginBottom: 5 }}>Forma de Pagamento</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 10 }}>
                {["dinheiro", "pix", "credito", "debito", "fiado"].map((f) => (
                  <button key={f} className="btn" onClick={() => setPagamento(f)}
                    style={{ padding: "7px 6px", fontSize: 11, fontWeight: 600, background: pagamento === f ? "#1a2545" : "#1e2130", color: pagamento === f ? "#4f8ef7" : "#6b7499", border: "1.5px solid " + (pagamento === f ? "#4f8ef7" : "#22263a") }}>
                    {f.charAt(0).toUpperCase() + f.slice(1)}
                  </button>
                ))}
              </div>

              {pagamento === "fiado" && (
                <div style={{ marginBottom: 10 }}>
                  <div className="label" style={{ marginBottom: 5 }}>Cliente</div>
                  <select className="input" value={clienteFiado} onChange={(e) => setClienteFiado(e.target.value)}>
                    <option value="">Selecione...</option>
                    {data.clientes.map((c) => (
                      <option key={c.id} value={c.id}>{c.nome}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* ── Troco — só para dinheiro ── */}
              {pagamento === "dinheiro" && (
                <div style={{ marginBottom: 10 }}>
                  <div className="label" style={{ marginBottom: 6 }}>💵 Valor Recebido (R$)</div>
                  <input
                    type="number"
                    className="input"
                    placeholder="0,00"
                    value={valorRecebido}
                    min={0}
                    onChange={(e) => setValorRecebido(e.target.value)}
                    style={{ marginBottom: 6 }}
                  />
                  {/* Botões de valor rápido */}
                  <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 6 }}>
                    {(() => {
                      const base = totalComDesc;
                      const notas = [2, 5, 10, 20, 50, 100, 200];
                      const sugestoes = notas.filter(n => n >= base).slice(0, 4);
                      if (sugestoes.length === 0) sugestoes.push(...notas.slice(-3));
                      return sugestoes.map(n => (
                        <button key={n} className="btn btn-ghost"
                          onClick={() => setValorRecebido(String(n))}
                          style={{ padding: "4px 10px", fontSize: 12, flex: 1,
                            background: Number(valorRecebido) === n ? "#1a2545" : "#1e2130",
                            color: Number(valorRecebido) === n ? "#4f8ef7" : "#a0a8c0",
                            border: `1px solid ${Number(valorRecebido) === n ? "#4f8ef7" : "#2a2f45"}` }}>
                          R${n}
                        </button>
                      ));
                    })()}
                  </div>
                  {/* Display do troco */}
                  <div style={{
                    padding: "12px 14px", borderRadius: 10,
                    background: Number(valorRecebido) <= 0 ? "#11141e" :
                      Number(valorRecebido) >= totalComDesc ? "#163829" : "#2e1018",
                    border: `1.5px solid ${Number(valorRecebido) <= 0 ? "#22263a" :
                      Number(valorRecebido) >= totalComDesc ? "#22c97a55" : "#e0526055"}`,
                    display: "flex", justifyContent: "space-between", alignItems: "center"
                  }}>
                    <span style={{ fontSize: 12, color: "#6b7499", fontWeight: 700, letterSpacing: .5 }}>TROCO</span>
                    <span style={{ fontSize: 22, fontWeight: 800,
                      color: Number(valorRecebido) <= 0 ? "#2a2f45" :
                        Number(valorRecebido) >= totalComDesc ? "#22c97a" : "#e05260" }}>
                      {Number(valorRecebido) <= 0
                        ? fmt(0)
                        : Number(valorRecebido) >= totalComDesc
                          ? fmt(Number(valorRecebido) - totalComDesc)
                          : `- ${fmt(totalComDesc - Number(valorRecebido))}`}
                    </span>
                  </div>
                </div>
              )}

              <div style={{ background: "#11141e", borderRadius: 10, padding: 12, marginBottom: 12, fontSize: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, color: "#6b7499" }}>
                  <span>Subtotal</span><span>{fmt(subtotal)}</span>
                </div>
                {Number(desconto) > 0 && (
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, color: "#e05260" }}>
                    <span>Desconto</span><span>- {fmt(Number(desconto))}</span>
                  </div>
                )}
                {taxaValor > 0 && (
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, color: "#f0b429" }}>
                    <span>Taxa ({data.taxas[pagamento]}%)</span><span>- {fmt(taxaValor)}</span>
                  </div>
                )}
                <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 15, color: "#22c97a", borderTop: "1px solid #22263a", paddingTop: 8, marginTop: 4 }}>
                  <span>Total Líquido</span><span>{fmt(liquido)}</span>
                </div>
              </div>
            </div>

            <button className="btn btn-success" onClick={finalizar} style={{ width: "100%", padding: "12px", fontSize: 14 }}>
              ✓ Finalizar Venda
            </button>

            <div style={{ marginTop: 14, textAlign: "center", fontSize: 12, color: "#6b7499" }}>
              Vendas hoje: <span style={{ color: "#22c97a", fontWeight: 700 }}>{fmt(vendaHoje)}</span>
            </div>

          </div>
        </div>
      </div>

    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// ABA ESTOQUE
// ══════════════════════════════════════════════════════════════════
function AbaEstoque({ data, update }) {
  const [subAba, setSubAba] = useState("produtos");
  const [busca, setBusca] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editando, setEditando] = useState(null);
  const [form, setForm] = useState({ nome: "", preco: "", custo: "", estoque: "", categoria: "", barcode: "", imagem: "" });
  const [barcodeInput, setBarcodeInput] = useState("");
  const [buscandoBarcode, setBuscandoBarcode] = useState(false);
  const [barcodeStatus, setBarcodeStatus] = useState(null);
  const [barcodeMsg, setBarcodeMsg] = useState("");

  const filtrados = data.produtos.filter((p) =>
(p.nome.toLowerCase().includes(busca.toLowerCase()) || (p.barcode && p.barcode.includes(busca)) || (p.codigo && p.codigo.toLowerCase().includes(busca.toLowerCase())))
  );

  const abrirNovo = () => {
    setForm({ nome: "", preco: "", custo: "", estoque: "", categoria: "", barcode: "", imagem: "", codigo: "" });
    setBarcodeInput(""); setBarcodeStatus(null); setBarcodeMsg("");
    setEditando(null); setShowForm(true);
  };

  const abrirEditar = (p) => {
    setForm({ nome: p.nome, preco: p.preco, custo: p.custo, estoque: p.estoque, categoria: p.categoria, barcode: p.barcode || "", imagem: p.imagem || "", codigo: p.codigo || "" });
    setBarcodeInput(p.barcode || ""); setBarcodeStatus(null); setBarcodeMsg("");
    setEditando(p.id); setShowForm(true);
  };

  const handleBarcodeSearch = async () => {
    const cod = barcodeInput.trim();
    if (!cod) return;
    const existente = data.produtos.find((p) => p.barcode === cod);
    if (existente && existente.id !== editando) {
      setBarcodeStatus("found"); setBarcodeMsg(`⚠️ Produto já cadastrado: "${existente.nome}"`); return;
    }
    setBuscandoBarcode(true); setBarcodeStatus(null); setBarcodeMsg("Buscando produto...");
    const resultado = await buscarPorBarcode(cod);
    setBuscandoBarcode(false);
    if (resultado && resultado.nome) {
      setForm((f) => ({ ...f, barcode: cod, nome: resultado.nome || f.nome, categoria: resultado.categoria || f.categoria, imagem: resultado.imagem || f.imagem }));
      setBarcodeStatus("found"); setBarcodeMsg(`✅ Produto encontrado via ${resultado.fonte}! Confira o nome e preencha preços.`);
    } else if (resultado && resultado.erro) {
      setForm((f) => ({ ...f, barcode: cod }));
      setBarcodeStatus("notfound"); setBarcodeMsg(`⚠️ ${resultado.erro}`);
    } else {
      setForm((f) => ({ ...f, barcode: cod }));
      setBarcodeStatus("notfound"); setBarcodeMsg("Produto não encontrado na base. Preencha os dados manualmente.");
    }
  };

  const handleBarcodeKey = (e) => { if (e.key === "Enter") { e.preventDefault(); handleBarcodeSearch(); } };

  const salvar = () => {
    if (!form.nome || !form.preco) return;
    update((d) => {
      if (editando) {
        return { ...d, produtos: d.produtos.map((p) => p.id === editando
          ? { ...p, ...form, preco: Number(form.preco), custo: Number(form.custo), estoque: Number(form.estoque) } : p) };
      }
      const id = d.nextId.produto;
      return { ...d, produtos: [...d.produtos, { id, ...form, preco: Number(form.preco), custo: Number(form.custo), estoque: Number(form.estoque) }], nextId: { ...d.nextId, produto: id + 1 } };
    });
    setShowForm(false);
  };

  const [confirmExcluir, setConfirmExcluir] = useState(null);
  const pedirExcluir = (p) => setConfirmExcluir({ id: p.id, nome: p.nome });
  const confirmarExcluir = () => {
    update((d) => ({ ...d, produtos: d.produtos.filter((p) => p.id !== confirmExcluir.id) }));
    setConfirmExcluir(null);
  };

  const totalValor = data.produtos.reduce((s, p) => s + p.preco * p.estoque, 0);
  const totalPerdas = (data.perdas || []).reduce((s, p) => s + (p.qty * p.custo), 0);
  return (
    <div>
      <div className="section-title">📦 Estoque</div>
      <div className="grid3" style={{ marginBottom: 16 }}>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>TOTAL DE PRODUTOS</div><div style={{ fontSize: 26, fontWeight: 700 }}>{data.produtos.length}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>VALOR EM ESTOQUE</div><div style={{ fontSize: 22, fontWeight: 700, color: "#4f8ef7" }}>{fmt(totalValor)}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>PERDAS REGISTRADAS</div><div style={{ fontSize: 22, fontWeight: 700, color: "#e05260" }}>{fmt(totalPerdas)}</div></div>
      </div>

      {/* Sub-abas */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {[["produtos","📦 Produtos"],["perdas","🗑️ Perdas"]].map(([k,l]) => (
          <button key={k} onClick={() => setSubAba(k)}
            style={{ padding: "8px 18px", borderRadius: 8, fontWeight: 600, fontSize: 13, border: "none", cursor: "pointer",
              background: subAba === k ? "#4f8ef7" : "#1a1d27", color: subAba === k ? "#fff" : "#6b7499" }}>
            {l}
          </button>
        ))}
      </div>

      {subAba === "produtos" && (<>
      {/* Barra de busca + botão */}
      <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
        <input className="input" placeholder="🔍 Buscar por nome ou código de barras..." value={busca} onChange={(e) => setBusca(e.target.value)} style={{ flex: 1 }} />
        <button className="btn btn-primary" onClick={abrirNovo} style={{ whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}>{icons.plus} Novo</button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 480, overflowY: "auto" }}>
        {filtrados.map((p) => {
          const margem = p.custo > 0 ? ((p.preco - p.custo) / p.preco * 100).toFixed(1) : null;
          return (
            <div key={p.id} style={{
              background: "#161923", border: "1px solid #22263a",
              borderLeft: "4px solid #22263a",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                    {p.imagem && <img src={p.imagem} alt="" style={{ width: 28, height: 28, objectFit: "contain", borderRadius: 4, background: "#fff" }} />}
                    <span style={{ fontWeight: 700, fontSize: 14, color: "#e8eaf0" }}>{p.nome}</span>
                  </div>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {p.categoria && <span className="tag tag-blue" style={{ fontSize: 10 }}>{p.categoria}</span>}
                    {p.barcode && <span style={{ fontSize: 10, color: "#6b7499", fontFamily: "monospace" }}>{p.barcode}</span>}
                    {p.codigo && <span style={{ fontSize: 10, color: "#4f8ef7", fontFamily: "monospace", background: "#11183a", borderRadius: 4, padding: "1px 6px" }}>#{p.codigo}</span>}
                  </div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0, marginLeft: 10 }}>
                  <div style={{ fontWeight: 800, fontSize: 15, color: "#4f8ef7" }}>{fmt(p.preco)}</div>
                  {p.custo > 0 && <div style={{ fontSize: 10, color: "#6b7499" }}>custo {fmt(p.custo)}</div>}
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, borderTop: "1px solid #22263a", paddingTop: 8 }}>
                <div style={{ display: "flex", gap: 14, fontSize: 12 }}>
                  <span>Estoque: <strong style={{ color: "#22c97a" }}>{p.estoque}</strong></span>
                  {margem && <span>Margem: <strong style={{ color: Number(margem) >= 30 ? "#22c97a" : "#f0b429" }}>{margem}%</strong></span>}
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button className="btn btn-ghost" onClick={() => abrirEditar(p)} style={{ padding: "5px 10px", fontSize: 11 }}>✏️</button>
                  <button className="btn btn-danger" onClick={() => pedirExcluir(p)} style={{ padding: "5px 8px" }}>{icons.trash}</button>
                </div>
              </div>
            </div>
          );
        })}
        {filtrados.length === 0 && (
          <div className="card" style={{ textAlign: "center", color: "#6b7499", padding: 40 }}>Nenhum produto encontrado</div>
        )}
      </div>

      {/* Modal ajuste rápido de estoque */}

      {showForm && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 500 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>{editando ? "Editar Produto" : "Novo Produto"}</div>
            <div style={{ fontSize: 12, color: "#6b7499", marginBottom: 18 }}>Use o código de barras para preencher automaticamente</div>
            <div style={{ marginBottom: 16 }}>
              <div className="label">Código de Barras (opcional)</div>
              <div style={{ display: "flex", gap: 8 }}>
                <input className="input" placeholder="Digite ou escaneie..." value={barcodeInput}
                  onChange={(e) => { setBarcodeInput(e.target.value); setBarcodeStatus(null); setBarcodeMsg(""); }}
                  onKeyDown={handleBarcodeKey} style={{ fontFamily: "monospace", letterSpacing: 1 }} autoFocus={!editando} />
                <button className="btn btn-primary" onClick={handleBarcodeSearch} disabled={buscandoBarcode || !barcodeInput.trim()} style={{ whiteSpace: "nowrap", minWidth: 90 }}>
                  {buscandoBarcode ? "⏳ ..." : "🔍 Buscar"}
                </button>
              </div>
              {barcodeMsg && (
                <div style={{ marginTop: 8, padding: "9px 12px", borderRadius: 8, fontSize: 12, fontWeight: 500,
                  background: barcodeStatus === "found" && !barcodeMsg.includes("⚠️") ? "#163829" : barcodeStatus === "notfound" ? "#2e2510" : "#2e1018",
                  color: barcodeStatus === "found" && !barcodeMsg.includes("⚠️") ? "#22c97a" : barcodeStatus === "notfound" ? "#f0b429" : "#e05260" }}>
                  {barcodeMsg}
                </div>
              )}
              {form.imagem && barcodeStatus === "found" && (
                <div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: "#11141e", borderRadius: 8 }}>
                  <img src={form.imagem} alt="produto" style={{ width: 52, height: 52, objectFit: "contain", borderRadius: 6, background: "#fff", padding: 4 }} />
                  <div style={{ fontSize: 12, color: "#a0a8c0" }}>Imagem encontrada</div>
                </div>
              )}
            </div>
            <div style={{ borderTop: "1px solid #22263a", paddingTop: 14, marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 12, fontWeight: 600 }}>DADOS DO PRODUTO</div>
              {[["nome", "Nome do Produto *", "text"], ["categoria", "Categoria", "text"]].map(([k, l, t]) => (
                <div key={k} style={{ marginBottom: 12 }}>
                  <div className="label">{l}</div>
                  <input type={t} className="input" value={form[k]} onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))} />
                </div>
              ))}
              <div style={{ marginBottom: 12 }}>
                <div className="label">Código Interno (opcional)</div>
                <input className="input" placeholder="Ex: PAO01, FRT-BANANA, 001..." value={form.codigo} onChange={(e) => setForm((f) => ({ ...f, codigo: e.target.value }))} style={{ fontFamily: "monospace" }} />
                <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>Use para produtos sem código de barras. Serve para busca rápida no caixa e estoque.</div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 12 }}>
                {[["custo","Custo (R$)"],["preco","Preço Venda *"],["estoque","Qtd. Estoque"]].map(([k, l]) => (
                  <div key={k}>
                    <div className="label">{l}</div>
                    <input type="number" className="input" value={form[k]} onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))} />
                  </div>
                ))}
              </div>
              {form.custo > 0 && form.preco > 0 && (
                <div style={{ padding: "10px 14px", background: "#11141e", borderRadius: 8, marginBottom: 14, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                  <span style={{ color: "#6b7499" }}>Margem de lucro</span>
                  <span style={{ fontWeight: 700, color: "#22c97a" }}>
                    {((Number(form.preco) - Number(form.custo)) / Number(form.preco) * 100).toFixed(1)}%
                    &nbsp;({fmt(Number(form.preco) - Number(form.custo))} por un.)
                  </span>
                </div>
              )}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-success" onClick={salvar} style={{ flex: 1 }}>Salvar</button>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {confirmExcluir && (
        <ConfirmModal
          titulo="Excluir produto?"
          descricao={`Tem certeza que deseja excluir "${confirmExcluir.nome}"? Esta ação não pode ser desfeita.`}
          onConfirm={confirmarExcluir}
          onCancel={() => setConfirmExcluir(null)}
        />
      )}
      </>)}

      {subAba === "perdas" && (
        <AbaPerdas data={data} update={update} />
      )}
    </div>
  );
}

function AbaPerdas({ data, update }) {
  const MOTIVOS = ["Furto externo", "Furto interno", "Validade vencida", "Avaria", "Consumo interno", "Erro operacional"];
  const [showForm, setShowForm] = useState(false);
  const [busca, setBusca] = useState("");
  const [filtroMotivo, setFiltroMotivo] = useState("todos");
  const [form, setForm] = useState({ produtoId: "", qty: "", motivo: "Validade vencida", obs: "" });

  const perdas = data.perdas || [];
  const perdasFiltradas = perdas.filter(p => {
    const matchBusca = !busca.trim() || p.nome.toLowerCase().includes(busca.toLowerCase());
    const matchMotivo = filtroMotivo === "todos" || p.motivo === filtroMotivo;
    return matchBusca && matchMotivo;
  }).slice().reverse();

  const totalMes = perdas.filter(p => {
    const d = new Date(p.data);
    const hoje = new Date();
    return d.getMonth() === hoje.getMonth() && d.getFullYear() === hoje.getFullYear();
  }).reduce((s, p) => s + p.qty * p.custo, 0);

  const registrarPerda = () => {
    if (!form.produtoId || !form.qty || Number(form.qty) <= 0) return;
    const produto = data.produtos.find(p => p.id === Number(form.produtoId));
    if (!produto) return;
    update((d) => {
      const id = (d.nextId.perda || 1);
      const novaPerda = {
        id, produtoId: produto.id, nome: produto.nome,
        qty: Number(form.qty), custo: produto.custo || 0,
        motivo: form.motivo, obs: form.obs,
        data: new Date().toISOString()
      };
      const novosProdutos = d.produtos.map(p =>
        p.id === produto.id ? { ...p, estoque: Math.max(0, p.estoque - Number(form.qty)) } : p
      );
      return {
        ...d,
        perdas: [...(d.perdas || []), novaPerda],
        produtos: novosProdutos,
        nextId: { ...d.nextId, perda: id + 1 }
      };
    });
    setForm({ produtoId: "", qty: "", motivo: "Validade vencida", obs: "" });
    setShowForm(false);
  };

  const corMotivo = (m) => {
    if (m === "Furto externo" || m === "Furto interno") return "#e05260";
    if (m === "Validade vencida") return "#f0b429";
    if (m === "Avaria") return "#a78bfa";
    if (m === "Consumo interno") return "#4f8ef7";
    return "#6b7499";
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 13, color: "#6b7499" }}>Perda do mês</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: "#e05260" }}>{fmt(totalMes)}</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)} style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {icons.plus} Registrar Perda
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
        <input className="input" placeholder="🔍 Buscar produto..." value={busca} onChange={e => setBusca(e.target.value)} style={{ flex: 1, minWidth: 150 }} />
        <select className="input" value={filtroMotivo} onChange={e => setFiltroMotivo(e.target.value)} style={{ width: "auto" }}>
          <option value="todos">Todos os motivos</option>
          {MOTIVOS.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>

      {perdasFiltradas.length === 0 ? (
        <div className="card" style={{ textAlign: "center", color: "#6b7499", padding: 40 }}>
          Nenhuma perda registrada
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <table className="table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Produto</th>
                <th>Qtd</th>
                <th>Custo</th>
                <th>Motivo</th>
              </tr>
            </thead>
            <tbody>
              {perdasFiltradas.map(p => (
                <tr key={p.id}>
                  <td style={{ color: "#6b7499", fontSize: 12 }}>{new Date(p.data).toLocaleDateString("pt-BR")}</td>
                  <td style={{ fontWeight: 600 }}>{p.nome}{p.obs ? <div style={{ fontSize: 10, color: "#6b7499" }}>{p.obs}</div> : null}</td>
                  <td style={{ fontWeight: 700, color: "#e05260" }}>{p.qty} un.</td>
                  <td style={{ color: "#f0b429" }}>{fmt(p.qty * p.custo)}</td>
                  <td><span style={{ fontSize: 11, fontWeight: 600, color: corMotivo(p.motivo) }}>{p.motivo}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showForm && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 420 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>🗑️ Registrar Perda</div>
            <div style={{ marginBottom: 12 }}>
              <div className="label">Produto *</div>
              <select className="input" value={form.produtoId} onChange={e => setForm(f => ({ ...f, produtoId: e.target.value }))}>
                <option value="">Selecione o produto...</option>
                {data.produtos.map(p => (
                  <option key={p.id} value={p.id}>{p.nome} (estoque: {p.estoque})</option>
                ))}
              </select>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div>
                <div className="label">Quantidade perdida *</div>
                <input type="number" className="input" value={form.qty} onChange={e => setForm(f => ({ ...f, qty: e.target.value }))} min={1} placeholder="0" />
              </div>
              <div>
                <div className="label">Motivo *</div>
                <select className="input" value={form.motivo} onChange={e => setForm(f => ({ ...f, motivo: e.target.value }))}>
                  {MOTIVOS.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div className="label">Observação (opcional)</div>
              <input className="input" value={form.obs} onChange={e => setForm(f => ({ ...f, obs: e.target.value }))} placeholder="Ex: lote vencido em 10/03..." />
            </div>
            {form.produtoId && Number(form.qty) > 0 && data.produtos.find(p => p.id === Number(form.produtoId)) && data.produtos.find(p => p.id === Number(form.produtoId)).custo > 0 && (
              <div style={{ background: "#2e1018", borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: "#e05260" }}>
                Prejuízo estimado: <strong>{fmt(Number(form.qty) * (data.produtos.find(p => p.id === Number(form.produtoId)).custo))}</strong>
              </div>
            )}
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-danger" onClick={registrarPerda} disabled={!form.produtoId || !form.qty} style={{ flex: 1 }}>
                Confirmar Perda
              </button>
              <button className="btn btn-ghost" onClick={() => { setShowForm(false); setForm({ produtoId: "", qty: "", motivo: "Validade vencida", obs: "" }); }} style={{ flex: 1 }}>
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ModalCancelarFiado({ fiado, vendas, onConfirm, onCancel }) {
  const venda = vendas?.find(v => v.id === fiado.vendaId);
  return (
    <div className="modal-overlay" style={{ zIndex: 300 }}>
      <div className="modal" style={{ maxWidth: 400 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 10, color: "#f0b429" }}>⚠️ Cancelar venda no fiado?</div>
        <div style={{ fontSize: 13, color: "#a0a8c0", marginBottom: 12, lineHeight: 1.6 }}>
          O saldo de <strong style={{ color: "#e8eaf0" }}>{fmt(fiado.valor)}</strong> será removido da dívida do cliente
          {venda ? " e o estoque dos produtos será devolvido." : "."}
        </div>
        {venda && venda.itens && (
          <div style={{ background: "#11141e", borderRadius: 8, padding: "10px 12px", marginBottom: 14 }}>
            {venda.itens.map((item, idx) => (
              <div key={idx} style={{ fontSize: 12, color: "#a0a8c0", marginBottom: 3 }}>
                {item.qty}x {item.nome}
              </div>
            ))}
          </div>
        )}
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-danger" onClick={() => onConfirm(fiado)} style={{ flex: 1 }}>
            Confirmar Cancelamento
          </button>
          <button className="btn btn-ghost" onClick={onCancel} style={{ flex: 1 }}>
            Voltar
          </button>
        </div>
      </div>
    </div>
  );
}

function AbaFiado({ data, update }) {
  const [sel, setSel] = useState(null);
  const [busca, setBusca] = useState("");
  const [pagParcial, setPagParcial] = useState("");
  const [clienteDetalhe, setClienteDetalhe] = useState(null);
  const [confirmCancelarFiado, setConfirmCancelarFiado] = useState(null);

  const totalFiado = data.clientes.reduce((s, c) => s + c.saldo, 0);
  const comDivida = data.clientes.filter((c) => c.saldo > 0);

  const clientesFiltrados = data.clientes.filter(c =>
    !busca.trim() || c.nome.toLowerCase().includes(busca.toLowerCase()) || (c.telefone || "").includes(busca)
  );

  const pagarFiado = (clienteId, valor) => {
    const valorPago = Number(valor) || 0;
    if (valorPago <= 0) return;
    update((d) => {
      const cliente = d.clientes.find(c => c.id === clienteId);
      if (!cliente) return d;
      const novoSaldo = Math.max(0, cliente.saldo - valorPago);
      // Marca fiados como pagos na ordem (do mais antigo para o mais novo)
      let restante = valorPago;
      const novosFiado = d.fiado.map((f) => {
        if (f.clienteId !== clienteId || f.pago || restante <= 0) return f;
        restante -= f.valor;
        return { ...f, pago: true, dataPagamento: new Date().toISOString() };
      });
      const novosClientes = d.clientes.map((c) => (c.id === clienteId ? { ...c, saldo: novoSaldo } : c));
      return { ...d, fiado: novosFiado, clientes: novosClientes };
    });
    setSel(null); setPagParcial("");
  };

  const cancelarFiado = (fiado) => {
    update((d) => {
      // Reverte o saldo do cliente
      const novosClientes = d.clientes.map((c) =>
        c.id === fiado.clienteId ? { ...c, saldo: Math.max(0, c.saldo - fiado.valor) } : c
      );
      // Devolve estoque dos produtos da venda
      const venda = d.vendas?.find(v => v.id === fiado.vendaId);
      const novosProdutos = venda ? d.produtos.map((p) => {
        const item = (venda.itens || []).find(i => i.id === p.id);
        return item ? { ...p, estoque: p.estoque + item.qty } : p;
      }) : d.produtos;
      // Marca o fiado como cancelado
      const novosFiado = d.fiado.map(f =>
        f.id === fiado.id ? { ...f, pago: true, cancelado: true, dataPagamento: new Date().toISOString() } : f
      );
      // Marca a venda como cancelada
      const novasVendas = venda
        ? d.vendas.map(v => v.id === venda.id ? { ...v, cancelada: true } : v)
        : d.vendas;
      return { ...d, clientes: novosClientes, produtos: novosProdutos, fiado: novosFiado, vendas: novasVendas };
    });
    // Atualiza o clienteDetalhe com o novo saldo
    setClienteDetalhe(prev => prev ? { ...prev, saldo: Math.max(0, prev.saldo - fiado.valor) } : null);
    setConfirmCancelarFiado(null);
  };

  // Histórico de compras do cliente selecionado
  const fiadosDoCliente = clienteDetalhe
    ? data.fiado.filter(f => f.clienteId === clienteDetalhe.id).reverse()
    : [];

  return (
    <div>
      <div className="section-title">👥 Fiado</div>
      <div className="grid2" style={{ marginBottom: 20 }}>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>TOTAL EM ABERTO</div><div style={{ fontSize: 24, fontWeight: 700, color: "#e05260" }}>{fmt(totalFiado)}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>CLIENTES COM DÍVIDA</div><div style={{ fontSize: 26, fontWeight: 700 }}>{comDivida.length}</div></div>
      </div>

      {/* Busca */}
      <input className="input" placeholder="🔍 Buscar cliente por nome ou telefone..." value={busca} onChange={e => setBusca(e.target.value)} style={{ marginBottom: 14 }} />

      {/* Cards de clientes */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 24 }}>
        {clientesFiltrados.map((c) => {
          const pct = c.limite > 0 ? Math.min(100, (c.saldo / c.limite) * 100) : 0;
          const cor = c.saldo === 0 ? "#22c97a" : pct > 80 ? "#e05260" : "#f0b429";
          return (
            <div key={c.id} style={{ background: "#161923", border: `1px solid ${c.saldo > 0 ? "#2e2510" : "#22263a"}`, borderLeft: `4px solid ${cor}`, borderRadius: 12, padding: "12px 14px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: "#e8eaf0" }}>{c.nome}</div>
                  {c.telefone && <div style={{ fontSize: 11, color: "#6b7499", marginTop: 2 }}>📞 {c.telefone}</div>}
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontWeight: 800, fontSize: 16, color: cor }}>{fmt(c.saldo)}</div>
                  <div style={{ fontSize: 10, color: "#6b7499" }}>limite {fmt(c.limite)}</div>
                </div>
              </div>
              {c.limite > 0 && c.saldo > 0 && (
                <div style={{ background: "#22263a", borderRadius: 4, height: 4, marginBottom: 10 }}>
                  <div style={{ background: cor, width: `${pct}%`, height: "100%", borderRadius: 4, transition: "width .3s" }} />
                </div>
              )}
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn btn-ghost" onClick={() => setClienteDetalhe(c)} style={{ flex: 1, fontSize: 12 }}>📋 Histórico</button>
                {c.saldo > 0 && (
                  <button className="btn btn-success" onClick={() => { setSel(c); setPagParcial(c.saldo.toFixed(2)); }} style={{ flex: 1, fontSize: 12 }}>💵 Receber</button>
                )}
              </div>
            </div>
          );
        })}
        {clientesFiltrados.length === 0 && (
          <div className="card" style={{ textAlign: "center", color: "#6b7499", padding: 32 }}>Nenhum cliente encontrado</div>
        )}
      </div>

      {/* Histórico recente */}
      <div>
        <div style={{ fontWeight: 600, marginBottom: 12, fontSize: 14 }}>Histórico Recente de Fiados</div>
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <table className="table">
            <thead><tr><th>Data</th><th>Cliente</th><th>Valor</th><th>Status</th></tr></thead>
            <tbody>
              {[...data.fiado].reverse().slice(0, 20).map((f) => {
                const cli = data.clientes.find((c) => c.id === f.clienteId);
                return (
                  <tr key={f.id}>
                    <td style={{ color: "#6b7499", fontSize: 12 }}>{new Date(f.data).toLocaleDateString("pt-BR")}</td>
                    <td style={{ fontWeight: 600 }}>{cli?.nome ?? "-"}</td>
                    <td style={{ fontWeight: 600, color: f.pago ? "#6b7499" : "#e05260" }}>{fmt(f.valor)}</td>
                    <td><span className={`tag ${f.pago ? "tag-green" : "tag-red"}`}>{f.pago ? "Pago" : "Pendente"}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal receber fiado (com pagamento parcial) */}
      {sel && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 400 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>💵 Receber Fiado</div>
            <div style={{ color: "#6b7499", marginBottom: 18, fontSize: 13 }}>{sel.nome}</div>
            <div style={{ background: "#11141e", borderRadius: 10, padding: 16, marginBottom: 18 }}>
              <div style={{ fontSize: 13, color: "#6b7499", marginBottom: 4 }}>Valor total em aberto</div>
              <div style={{ fontSize: 32, fontWeight: 700, color: "#e05260", marginBottom: 2 }}>{fmt(sel.saldo)}</div>
              <div style={{ fontSize: 11, color: "#6b7499" }}>Limite: {fmt(sel.limite)}</div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div className="label">Valor a receber agora</div>
              <input type="number" className="input" value={pagParcial} onChange={e => setPagParcial(e.target.value)} placeholder="R$" min={0.01} max={sel.saldo} step={0.01} />
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button className="btn btn-ghost" onClick={() => setPagParcial(sel.saldo.toFixed(2))} style={{ flex: 1, fontSize: 12 }}>Valor total</button>
                <button className="btn btn-ghost" onClick={() => setPagParcial((sel.saldo / 2).toFixed(2))} style={{ flex: 1, fontSize: 12 }}>Metade</button>
              </div>
            </div>
            {pagParcial && Number(pagParcial) < sel.saldo && (
              <div style={{ background: "#2e2510", borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: "#f0b429" }}>
                ⚠️ Pagamento parcial — restará {fmt(sel.saldo - Number(pagParcial))} em aberto
              </div>
            )}
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-success" onClick={() => pagarFiado(sel.id, pagParcial)} disabled={!pagParcial || Number(pagParcial) <= 0} style={{ flex: 1 }}>
                Confirmar Recebimento
              </button>
              <button className="btn btn-ghost" onClick={() => { setSel(null); setPagParcial(""); }} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal histórico do cliente */}
      {clienteDetalhe && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>📋 {clienteDetalhe.nome}</div>
                <div style={{ fontSize: 12, color: "#6b7499" }}>Histórico completo de fiados</div>
              </div>
              <button className="btn btn-ghost" onClick={() => setClienteDetalhe(null)} style={{ padding: "4px 10px" }}>✕</button>
            </div>
            <div style={{ background: "#11141e", borderRadius: 10, padding: 14, marginBottom: 14 }}>
              <div className="grid2">
                <div><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 2 }}>SALDO ATUAL</div><div style={{ fontWeight: 700, color: "#e05260", fontSize: 18 }}>{fmt(clienteDetalhe.saldo)}</div></div>
                <div><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 2 }}>TOTAL HISTÓRICO</div><div style={{ fontWeight: 700, color: "#4f8ef7", fontSize: 18 }}>{fmt(fiadosDoCliente.reduce((s,f) => s+f.valor, 0))}</div></div>
              </div>
            </div>
            <div style={{ maxHeight: 320, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
              {fiadosDoCliente.length === 0 && <div style={{ textAlign: "center", color: "#6b7499", padding: 32 }}>Nenhum registro</div>}
              {fiadosDoCliente.map((f) => {
                // Busca os itens da venda correspondente
                const venda = data.vendas?.find(v => v.id === f.vendaId);
                return (
                  <div key={f.id} style={{ background: "#1a1d27", borderRadius: 8, padding: "10px 12px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: venda ? 6 : 0 }}>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: f.pago ? "#6b7499" : "#e8eaf0" }}>{fmt(f.valor)}</div>
                        <div style={{ fontSize: 10, color: "#6b7499" }}>{new Date(f.data).toLocaleString("pt-BR")}</div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span className={`tag ${f.cancelado ? "tag-red" : f.pago ? "tag-green" : "tag-red"}`}>
                          {f.cancelado ? "Cancelado" : f.pago ? "Pago" : "Pendente"}
                        </span>
                        {!f.pago && (
                          <button className="btn btn-ghost" onClick={() => setConfirmCancelarFiado(f)}
                            style={{ padding: "3px 8px", fontSize: 11, color: "#e05260", border: "1px solid #3a1a1a" }}>
                            Cancelar
                          </button>
                        )}
                      </div>
                    </div>
                    {venda && venda.itens && (
                      <div style={{ fontSize: 11, color: "#a0a8c0" }}>
                        {venda.itens.slice(0,3).map(i => `${i.qty}x ${i.nome}`).join(", ")}
                        {venda.itens.length > 3 && ` +${venda.itens.length-3}`}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
              {clienteDetalhe.saldo > 0 && (
                <button className="btn btn-success" onClick={() => { setSel(clienteDetalhe); setPagParcial(clienteDetalhe.saldo.toFixed(2)); setClienteDetalhe(null); }} style={{ flex: 1 }}>
                  💵 Receber Pagamento
                </button>
              )}
              <button className="btn btn-ghost" onClick={() => setClienteDetalhe(null)} style={{ flex: 1 }}>Fechar</button>
            </div>
          </div>
        </div>
      )}
      {/* Modal confirmar cancelamento de fiado */}
      {confirmCancelarFiado && (
        <ModalCancelarFiado
          fiado={confirmCancelarFiado}
          vendas={data.vendas}
          onConfirm={cancelarFiado}
          onCancel={() => setConfirmCancelarFiado(null)}
        />
      )}
    </div>
  );
}

function AbaRelatorios({ data, update }) {
  const [periodo, setPeriodo] = useState("dia");
  const [buscaVenda, setBuscaVenda] = useState("");
  const [detalheVenda, setDetalheVenda] = useState(null);
  const [confirmCancelarVenda, setConfirmCancelarVenda] = useState(null);
  const [exportMsg, setExportMsg] = useState(false);

  const vendas = filterByPeriod(data.vendas, periodo);
  const totalBruto = vendas.reduce((s, v) => s + v.total, 0);
  const totalLiquido = vendas.reduce((s, v) => s + v.liquido, 0);
  const totalTaxas = vendas.reduce((s, v) => s + (v.taxaValor ?? 0), 0);
  const totalDescontos = vendas.reduce((s, v) => s + (v.desconto ?? 0), 0);
  const qtdVendas = vendas.length;

  // ── Margem total do estoque ──────────────────────────────────────
  const produtosComCusto = data.produtos.filter(p => p.custo > 0 && p.preco > 0);
  const totalCustoEstoque  = data.produtos.reduce((s, p) => s + (p.custo || 0) * p.estoque, 0);
  const totalVendaEstoque  = data.produtos.reduce((s, p) => s + p.preco * p.estoque, 0);
  const lucroEstoque       = totalVendaEstoque - totalCustoEstoque;
  const margemMediaPond    = totalVendaEstoque > 0
    ? (lucroEstoque / totalVendaEstoque) * 100 : 0;
  // Margem por produto (ponderada pelo valor de venda em estoque)
  const porProduto = data.produtos
    .filter(p => p.custo > 0 && p.preco > 0 && p.estoque > 0)
    .map(p => ({
      nome: p.nome,
      margem: ((p.preco - p.custo) / p.preco * 100),
      lucroUnit: p.preco - p.custo,
      estoqueValor: p.preco * p.estoque,
    }))
    .sort((a, b) => b.margem - a.margem);

  const porForma = {};
  vendas.forEach((v) => {
    if (!porForma[v.pagamento]) porForma[v.pagamento] = { bruto: 0, liquido: 0, qtd: 0 };
    porForma[v.pagamento].bruto += v.total;
    porForma[v.pagamento].liquido += v.liquido;
    porForma[v.pagamento].qtd += 1;
  });

  // ── Métricas completas de produtos ──────────────────────────────
  // Usa TODAS as vendas (não filtradas por período) para calcular giro histórico
  const todasVendas = data.vendas;
  const prodMetrics = {};
  data.produtos.forEach(p => {
    prodMetrics[p.id] = {
      id: p.id, nome: p.nome, categoria: p.categoria,
      preco: p.preco, custo: p.custo || 0, estoque: p.estoque,
      estoqueMin: p.estoqueMin || 0,
      qtyVendida: 0, totalVendido: 0, lucroGerado: 0,
      ultimaVenda: null,
    };
  });
  todasVendas.forEach(v => v.itens?.forEach(i => {
    if (!prodMetrics[i.id]) return;
    prodMetrics[i.id].qtyVendida += i.qty;
    prodMetrics[i.id].totalVendido += i.qty * i.preco;
    prodMetrics[i.id].lucroGerado += i.qty * (i.preco - (prodMetrics[i.id].custo || 0));
    if (!prodMetrics[i.id].ultimaVenda || v.data > prodMetrics[i.id].ultimaVenda)
      prodMetrics[i.id].ultimaVenda = v.data;
  }));

  // Giro: dias desde início das vendas / qty vendida
  const primeiraVenda = todasVendas.length ? new Date(todasVendas[0].data) : new Date();
  const diasAtivos = Math.max(1, Math.ceil((new Date() - primeiraVenda) / 86400000));
  const metricsList = Object.values(prodMetrics).map(p => ({
    ...p,
    vendaDia: p.qtyVendida / diasAtivos,
    diasParaZerar: p.vendaDia > 0 ? Math.floor(p.estoque / (p.qtyVendida / diasAtivos)) : null,
    diasSemVenda: p.ultimaVenda ? Math.floor((new Date() - new Date(p.ultimaVenda)) / 86400000) : null,
  }));

  // Rankings
  const maisVendidos  = [...metricsList].filter(p => p.qtyVendida > 0).sort((a,b) => b.qtyVendida - a.qtyVendida).slice(0, 10);
  const menosVendidos = [...metricsList].filter(p => p.qtyVendida > 0).sort((a,b) => a.qtyVendida - b.qtyVendida).slice(0, 5);
  const semVenda      = metricsList.filter(p => p.qtyVendida === 0);
  const recomprar     = metricsList.filter(p => p.diasParaZerar !== null && p.diasParaZerar <= 7 && p.estoque > 0)
                          .sort((a,b) => a.diasParaZerar - b.diasParaZerar);
  const estoqueBaixo  = metricsList.filter(p => p.estoque <= 3 && p.estoque > 0);

  const maxQty = maisVendidos[0]?.qtyVendida || 1;

  const diasCor = (d) => d <= 3 ? "#e05260" : d <= 7 ? "#f0b429" : "#22c97a";

  const labels = { dia: "Hoje", semana: "Esta Semana", mes: "Este Mês", ano: "Este Ano" };
  const pagColors = { dinheiro: "#f0b429", pix: "#22c97a", credito: "#4f8ef7", debito: "#b57cf7", fiado: "#e05260" };

  const margemCor = (m) => m >= 40 ? "#22c97a" : m >= 20 ? "#f0b429" : "#e05260";

  return (
    <div>
      <div className="section-title">📊 Relatórios</div>

      {/* ── Painel Margem do Estoque ── */}
      <div className="card" style={{ marginBottom: 24, border: "1px solid #2a2f45" }}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#e8eaf0", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 18 }}>📈</span> Margem Total do Estoque
        </div>
        <div className="grid4" style={{ marginBottom: 18 }}>
          <div style={{ background: "#11141e", borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6, fontWeight: 600 }}>MARGEM MÉDIA</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: margemCor(margemMediaPond) }}>
              {margemMediaPond.toFixed(1)}%
            </div>
            <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>ponderada pelo estoque</div>
          </div>
          <div style={{ background: "#11141e", borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6, fontWeight: 600 }}>VALOR DE CUSTO</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#e05260" }}>{fmt(totalCustoEstoque)}</div>
            <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>investido em estoque</div>
          </div>
          <div style={{ background: "#11141e", borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6, fontWeight: 600 }}>VALOR DE VENDA</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#4f8ef7" }}>{fmt(totalVendaEstoque)}</div>
            <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>se vender tudo</div>
          </div>
          <div style={{ background: "#11141e", borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6, fontWeight: 600 }}>LUCRO POTENCIAL</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#22c97a" }}>{fmt(lucroEstoque)}</div>
            <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>se vender tudo</div>
          </div>
        </div>

        {/* Barra visual da margem */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#6b7499", marginBottom: 5 }}>
            <span>Custo {fmt(totalCustoEstoque)}</span>
            <span>Lucro {fmt(lucroEstoque)}</span>
          </div>
          <div style={{ background: "#22263a", borderRadius: 6, height: 10, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 6,
              background: `linear-gradient(90deg, #e05260 ${100 - margemMediaPond}%, #22c97a ${100 - margemMediaPond}%)`,
              width: "100%"
            }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#6b7499", marginTop: 4 }}>
            <span>■ Custo ({(100 - margemMediaPond).toFixed(1)}%)</span>
            <span>■ Margem ({margemMediaPond.toFixed(1)}%)</span>
          </div>
        </div>

        {/* Ranking de margens por produto */}
        {porProduto.length > 0 && (
          <div>
            <div style={{ fontSize: 11, color: "#6b7499", fontWeight: 600, marginBottom: 10, textTransform: "uppercase", letterSpacing: .5 }}>
              Margem por Produto ({produtosComCusto.length} com custo cadastrado)
            </div>
            <div style={{ maxHeight: 200, overflowY: "auto" }}>
              {porProduto.map((p) => (
                <div key={p.nome} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <div style={{ width: 44, textAlign: "right", fontWeight: 800, fontSize: 13, color: margemCor(p.margem), flexShrink: 0 }}>
                    {p.margem.toFixed(1)}%
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.nome}</div>
                    <div style={{ background: "#22263a", borderRadius: 4, height: 5 }}>
                      <div style={{ background: margemCor(p.margem), width: `${Math.min(p.margem, 100)}%`, height: "100%", borderRadius: 4, transition: "width .3s" }} />
                    </div>
                  </div>
                  <div style={{ fontSize: 11, color: "#6b7499", flexShrink: 0, textAlign: "right" }}>
                    +{fmt(p.lucroUnit)}/un
                  </div>
                </div>
              ))}
            </div>
            {data.produtos.filter(p => !p.custo || p.custo === 0).length > 0 && (
              <div style={{ marginTop: 10, padding: "8px 12px", background: "#2e2510", borderRadius: 8, fontSize: 12, color: "#f0b429" }}>
                ⚠️ {data.produtos.filter(p => !p.custo || p.custo === 0).length} produto(s) sem custo cadastrado — não entram no cálculo.
              </div>
            )}
          </div>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 24, flexWrap: "wrap" }}>
        {Object.entries(labels).map(([k, l]) => (
          <button key={k} className="btn" onClick={() => setPeriodo(k)}
            style={{ padding: "9px 18px", fontWeight: 600, fontSize: 13, background: periodo === k ? "#1a2545" : "#1e2130", color: periodo === k ? "#4f8ef7" : "#6b7499", border: `1.5px solid ${periodo === k ? "#4f8ef7" : "#22263a"}` }}>
            {l}
          </button>
        ))}
      </div>

      <div className="grid4" style={{ marginBottom: 20 }}>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>VENDAS BRUTAS</div><div style={{ fontSize: 20, fontWeight: 700, color: "#e8eaf0" }}>{fmt(totalBruto)}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>VALOR LÍQUIDO</div><div style={{ fontSize: 20, fontWeight: 700, color: "#22c97a" }}>{fmt(totalLiquido)}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>TAXAS PAGAS</div><div style={{ fontSize: 20, fontWeight: 700, color: "#e05260" }}>{fmt(totalTaxas)}</div></div>
        <div className="stat-card"><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>Nº DE VENDAS</div><div style={{ fontSize: 26, fontWeight: 700 }}>{qtdVendas}</div></div>
      </div>

      <div className="grid2" style={{ marginBottom: 20 }}>
        <div className="card">
          <div style={{ fontWeight: 700, fontSize: 13, color: "#a0a8c0", marginBottom: 14 }}>POR FORMA DE PAGAMENTO</div>
          {Object.keys(porForma).length === 0 ? <div style={{ color: "#6b7499", fontSize: 13 }}>Nenhuma venda no período</div> : (
            Object.entries(porForma).map(([f, v]) => (
              <div key={f} style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontWeight: 600, fontSize: 13, color: pagColors[f] ?? "#e8eaf0" }}>{f.charAt(0).toUpperCase() + f.slice(1)} ({v.qtd})</span>
                  <span style={{ fontSize: 12, color: "#6b7499" }}>Líq: {fmt(v.liquido)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                  <span style={{ color: "#6b7499" }}>Bruto: {fmt(v.bruto)}</span>
                  <span style={{ color: "#e05260" }}>Taxa: {fmt(v.bruto - v.liquido)}</span>
                </div>
                <div style={{ background: "#22263a", borderRadius: 4, height: 4, marginTop: 6 }}>
                  <div style={{ background: pagColors[f] ?? "#4f8ef7", width: `${(v.bruto / totalBruto) * 100}%`, height: "100%", borderRadius: 4 }} />
                </div>
              </div>
            ))
          )}
        </div>

        <div className="card">
          <div style={{ fontWeight: 700, fontSize: 13, color: "#a0a8c0", marginBottom: 14 }}>🔥 TOP 5 NO PERÍODO</div>
          {(() => {
            const prodMap = {};
            vendas.forEach(v => v.itens?.forEach(i => {
              if (!prodMap[i.id]) prodMap[i.id] = { nome: i.nome, qty: 0, total: 0 };
              prodMap[i.id].qty += i.qty;
              prodMap[i.id].total += i.qty * i.preco;
            }));
            const topProd = Object.values(prodMap).sort((a,b) => b.total - a.total).slice(0,5);
            return topProd.length === 0
              ? <div style={{ color: "#6b7499", fontSize: 13 }}>Nenhuma venda no período</div>
              : topProd.map((p, i) => (
                <div key={p.nome} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 24, height: 24, background: "#1a2545", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#4f8ef7" }}>{i + 1}</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{p.nome}</div>
                      <div style={{ fontSize: 11, color: "#6b7499" }}>{p.qty} unidades</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#22c97a" }}>{fmt(p.total)}</div>
                </div>
              ));
          })()}
        </div>
      </div>

      {/* ══ PAINEL DE MÉTRICAS DE PRODUTOS ══ */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: "#e8eaf0", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
          <span>🛒</span> Métricas de Produtos — Controle de Recompra
        </div>

        {/* Alertas de recompra */}
        {(recomprar.length > 0 || estoqueBaixo.length > 0) && (
          <div style={{ background: "#2e1a08", border: "1.5px solid #f0b42955", borderRadius: 14, padding: 16, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#f0b429", marginBottom: 10, display: "flex", alignItems: "center", gap: 7 }}>
              ⚠️ Recomprar em breve ({recomprar.length + estoqueBaixo.filter(e => !recomprar.find(r => r.id === e.id)).length} produto{recomprar.length !== 1 ? "s" : ""})
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
              {[...recomprar, ...estoqueBaixo.filter(e => !recomprar.find(r => r.id === e.id))].slice(0,8).map(p => (
                <div key={p.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "#11141e", borderRadius: 8, padding: "8px 12px" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{p.nome}</div>
                    <div style={{ fontSize: 11, color: "#6b7499" }}>{p.categoria}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: p.estoque <= 1 ? "#e05260" : "#f0b429" }}>
                      {p.estoque} em estoque
                    </div>
                    {p.diasParaZerar !== null && (
                      <div style={{ fontSize: 11, color: diasCor(p.diasParaZerar) }}>
                        zera em ~{p.diasParaZerar}d
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid2" style={{ marginBottom: 16 }}>
          {/* Mais vendidos */}
          <div className="card">
            <div style={{ fontWeight: 700, fontSize: 13, color: "#22c97a", marginBottom: 14, display: "flex", alignItems: "center", gap: 7 }}>
              🏆 Mais Vendidos (histórico)
            </div>
            {maisVendidos.length === 0
              ? <div style={{ color: "#6b7499", fontSize: 13 }}>Nenhuma venda registrada ainda</div>
              : maisVendidos.map((p, i) => (
                <div key={p.id} style={{ marginBottom: 10 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 3 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: i < 3 ? "#f0b429" : "#6b7499", width: 16 }}>#{i+1}</span>
                      <span style={{ fontSize: 12, fontWeight: 600, maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.nome}</span>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <span style={{ fontSize: 12, fontWeight: 700, color: "#22c97a" }}>{p.qtyVendida} un</span>
                    </div>
                  </div>
                  <div style={{ background: "#22263a", borderRadius: 4, height: 5 }}>
                    <div style={{ background: "#22c97a", width: `${(p.qtyVendida / maxQty) * 100}%`, height: "100%", borderRadius: 4 }} />
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#6b7499", marginTop: 2 }}>
                    <span>Estoque: {p.estoque}</span>
                    <span>{p.vendaDia > 0 ? `~${p.vendaDia.toFixed(1)}/dia` : ""}</span>
                    {p.diasParaZerar !== null && (
                      <span style={{ color: diasCor(p.diasParaZerar), fontWeight: 600 }}>
                        zera em {p.diasParaZerar}d
                      </span>
                    )}
                  </div>
                </div>
              ))
            }
          </div>

          {/* Menos vendidos + sem venda */}
          <div className="card">
            <div style={{ fontWeight: 700, fontSize: 13, color: "#e05260", marginBottom: 14, display: "flex", alignItems: "center", gap: 7 }}>
              📉 Menos Vendidos
            </div>
            {menosVendidos.length === 0 && semVenda.length === 0
              ? <div style={{ color: "#6b7499", fontSize: 13 }}>Nenhuma venda registrada ainda</div>
              : <>
                {menosVendidos.map(p => (
                  <div key={p.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #1a1d27" }}>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 600 }}>{p.nome}</div>
                      <div style={{ fontSize: 10, color: "#6b7499" }}>{p.categoria} · Estoque: {p.estoque}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: "#e05260" }}>{p.qtyVendida} un</div>
                      {p.diasSemVenda !== null && (
                        <div style={{ fontSize: 10, color: "#6b7499" }}>{p.diasSemVenda}d sem vender</div>
                      )}
                    </div>
                  </div>
                ))}
                {semVenda.length > 0 && (
                  <div style={{ marginTop: 10 }}>
                    <div style={{ fontSize: 11, color: "#f0b429", fontWeight: 600, marginBottom: 6 }}>⚠️ Nunca vendidos ({semVenda.length})</div>
                    {semVenda.slice(0, 5).map(p => (
                      <div key={p.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 0", borderBottom: "1px solid #1a1d27" }}>
                        <span style={{ fontSize: 12 }}>{p.nome}</span>
                        <span style={{ fontSize: 11, color: "#6b7499" }}>{p.estoque} em estoque</span>
                      </div>
                    ))}
                    {semVenda.length > 5 && <div style={{ fontSize: 11, color: "#6b7499", marginTop: 4 }}>+ {semVenda.length - 5} outros...</div>}
                  </div>
                )}
              </>
            }
          </div>
        </div>

        {/* Tabela completa de giro */}
        <div className="card">
          <div style={{ fontWeight: 700, fontSize: 13, color: "#a0a8c0", marginBottom: 14 }}>📋 Giro de Estoque — Todos os Produtos</div>
          <div style={{ overflowX: "auto" }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Produto</th>
                  <th>Categoria</th>
                  <th style={{ textAlign: "right" }}>Un. Vendidas</th>
                  <th style={{ textAlign: "right" }}>Faturado</th>
                  <th style={{ textAlign: "right" }}>Lucro Gerado</th>
                  <th style={{ textAlign: "right" }}>Estoque</th>
                  <th style={{ textAlign: "right" }}>Média/dia</th>
                  <th style={{ textAlign: "center" }}>Situação</th>
                </tr>
              </thead>
              <tbody>
                {[...metricsList].sort((a,b) => b.qtyVendida - a.qtyVendida).map(p => {
                  const situacao = p.qtyVendida === 0
                    ? { label: "Sem venda", color: "#f0b429", bg: "#2e2510" }
                    : p.diasParaZerar !== null && p.diasParaZerar <= 3
                    ? { label: "Urgente!", color: "#e05260", bg: "#2e1018" }
                    : p.diasParaZerar !== null && p.diasParaZerar <= 7
                    ? { label: "Recomprar", color: "#f0b429", bg: "#2e2510" }
                    : p.estoque === 0
                    ? { label: "Zerado", color: "#e05260", bg: "#2e1018" }
                    : { label: "OK", color: "#22c97a", bg: "#163829" };
                  return (
                    <tr key={p.id}>
                      <td style={{ fontWeight: 600, fontSize: 12 }}>{p.nome}</td>
                      <td style={{ color: "#6b7499", fontSize: 11 }}>{p.categoria || "—"}</td>
                      <td style={{ textAlign: "right", fontWeight: 700 }}>{p.qtyVendida}</td>
                      <td style={{ textAlign: "right", color: "#4f8ef7" }}>{fmt(p.totalVendido)}</td>
                      <td style={{ textAlign: "right", color: p.lucroGerado > 0 ? "#22c97a" : "#6b7499" }}>
                        {p.custo > 0 ? fmt(p.lucroGerado) : "—"}
                      </td>
                      <td style={{ textAlign: "right", color: p.estoque <= 3 ? "#e05260" : "#e8eaf0", fontWeight: 600 }}>{p.estoque}</td>
                      <td style={{ textAlign: "right", fontSize: 11, color: "#6b7499" }}>
                        {p.vendaDia > 0 ? p.vendaDia.toFixed(2) : "—"}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <span style={{ background: situacao.bg, color: situacao.color, padding: "3px 8px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>
                          {situacao.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ── Gráfico por hora do dia ── */}
      {(() => {
        const porHora = Array(24).fill(0);
        vendas.forEach(v => { const h = new Date(v.data).getHours(); porHora[h] += v.total; });
        const maxHora = Math.max(...porHora, 1);
        const horasPico = porHora.map((v,h) => ({h,v})).sort((a,b) => b.v - a.v).slice(0,3).map(x => x.h);
        return (
          <div className="card" style={{ marginBottom: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#a0a8c0", marginBottom: 14 }}>🕐 Vendas por Hora do Dia</div>
            {vendas.length === 0
              ? <div style={{ color: "#6b7499", fontSize: 13 }}>Nenhuma venda no período</div>
              : <>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 80, marginBottom: 8 }}>
                  {porHora.map((v, h) => (
                    <div key={h} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                      <div style={{
                        width: "100%", borderRadius: 3,
                        height: `${(v / maxHora) * 72}px`,
                        background: horasPico.includes(h) ? "#4f8ef7" : "#22263a",
                        minHeight: v > 0 ? 3 : 0,
                        transition: "height .3s"
                      }} />
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#6b7499" }}>
                  {[0,6,12,18,23].map(h => <span key={h}>{String(h).padStart(2,"0")}h</span>)}
                </div>
                <div style={{ marginTop: 10, fontSize: 12, color: "#6b7499" }}>
                  Picos: {horasPico.filter(h => porHora[h] > 0).map(h => `${String(h).padStart(2,"0")}h (${fmt(porHora[h])})`).join(", ") || "—"}
                </div>
              </>
            }
          </div>
        );
      })()}

      {/* ── Histórico de Vendas com busca ── */}
      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: "#a0a8c0" }}>🧾 Histórico de Vendas</div>
          <div style={{ display: "flex", gap: 8 }}>
            
            <button
              className="btn btn-ghost"
              onClick={() => {
                const linhas = [
                  `Relatório PDV — ${new Date().toLocaleDateString("pt-BR")}`,
                  `Período: ${labels[periodo]}`,
                  `Vendas: ${qtdVendas} | Bruto: ${fmt(totalBruto)} | Líquido: ${fmt(totalLiquido)}`,
                  "",
                  ...([...vendas].reverse().slice(0,50).map(v =>
                    `${new Date(v.data).toLocaleString("pt-BR")} | ${v.pagamento} | ${fmt(v.total)} | ${v.itens?.map(i => i.nome).join(", ")}`
                  ))
                ].join("\n");
                navigator.clipboard?.writeText(linhas);
                setExportMsg(true); setTimeout(() => setExportMsg(false), 2500);
              }}
              style={{ fontSize: 11, padding: "5px 12px" }}
            >
              {exportMsg ? "✅ Copiado!" : "📋 Copiar Relatório"}
            </button>
          </div>
        </div>

        <input
          className="input"
          placeholder="🔍 Buscar por produto, forma de pagamento..."
          value={buscaVenda}
          onChange={e => setBuscaVenda(e.target.value)}
          style={{ marginBottom: 12 }}
        />

        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {(() => {
            const filtradas = [...vendas].reverse().filter(v => {
              if (!buscaVenda.trim()) return true;
              const b = buscaVenda.toLowerCase();
              return v.pagamento?.includes(b) ||
                (v.itens || []).some(i => i.nome.toLowerCase().includes(b));
            }).slice(0, 30);

            if (filtradas.length === 0) return (
              <div style={{ textAlign: "center", color: "#6b7499", padding: 24, fontSize: 13 }}>Nenhuma venda encontrada</div>
            );

            return filtradas.map(v => (
              <div key={v.id} onClick={() => setDetalheVenda(v)} style={{
                background: v.cancelada ? "#1a1014" : "#1a1d27",
                borderRadius: 10, padding: "10px 14px", cursor: "pointer",
                opacity: v.cancelada ? 0.6 : 1,
                borderLeft: `3px solid ${v.cancelada ? "#e05260" : v.pagamento === "fiado" ? "#e05260" : v.pagamento === "pix" ? "#22c97a" : "#4f8ef7"}`
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: 12, color: "#6b7499" }}>{new Date(v.data).toLocaleString("pt-BR")}</div>
                    <div style={{ fontSize: 11, color: "#a0a8c0", marginTop: 2 }}>
                      {(v.itens || []).slice(0,3).map(i => `${i.qty}x ${i.nome}`).join(", ")}
                      {(v.itens || []).length > 3 && " ..."}
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontWeight: 700, color: v.cancelada ? "#e05260" : "#22c97a" }}>{fmt(v.total)}</div>
                    <span className={`tag badge-${v.pagamento}`} style={{ fontSize: 10 }}>{v.cancelada ? "Cancelada" : v.pagamento}</span>
                  </div>
                </div>
              </div>
            ));
          })()}
        </div>
      </div>

      {/* Modal Detalhe de Venda */}
      {detalheVenda && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontWeight: 700, fontSize: 16 }}>🧾 Venda #{detalheVenda.id} {detalheVenda.cancelada && <span className="tag tag-red" style={{ marginLeft: 6 }}>Cancelada</span>}</div>
              <button className="btn btn-ghost" onClick={() => setDetalheVenda(null)} style={{ padding: "4px 10px" }}>✕</button>
            </div>

            <div style={{ background: "#11141e", borderRadius: 10, padding: 14, marginBottom: 14, fontSize: 13 }}>
              <div className="grid2" style={{ gap: 10 }}>
                <div><div style={{ color: "#6b7499", fontSize: 11 }}>DATA</div><div>{new Date(detalheVenda.data).toLocaleString("pt-BR")}</div></div>
                <div><div style={{ color: "#6b7499", fontSize: 11 }}>PAGAMENTO</div><div style={{ fontWeight: 600 }}>{detalheVenda.pagamento}</div></div>
                <div><div style={{ color: "#6b7499", fontSize: 11 }}>BRUTO</div><div style={{ fontWeight: 700 }}>{fmt(detalheVenda.total)}</div></div>
                <div><div style={{ color: "#6b7499", fontSize: 11 }}>LÍQUIDO</div><div style={{ fontWeight: 700, color: "#22c97a" }}>{fmt(detalheVenda.liquido)}</div></div>
                {detalheVenda.desconto > 0 && <div><div style={{ color: "#6b7499", fontSize: 11 }}>DESCONTO</div><div style={{ color: "#e05260" }}>{fmt(detalheVenda.desconto)}</div></div>}
                {detalheVenda.taxaValor > 0 && <div><div style={{ color: "#6b7499", fontSize: 11 }}>TAXA</div><div style={{ color: "#f0b429" }}>{fmt(detalheVenda.taxaValor)}</div></div>}
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#6b7499", marginBottom: 8, textTransform: "uppercase" }}>Itens vendidos</div>
              {(detalheVenda.itens || []).map((i, idx) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", background: "#1a1d27", borderRadius: 8, padding: "8px 12px", marginBottom: 4, fontSize: 13 }}>
                  <span style={{ fontWeight: 600 }}>{i.nome}</span>
                  <div style={{ display: "flex", gap: 12, color: "#6b7499" }}>
                    <span>{i.qty}x {fmt(i.preco)}</span>
                    <span style={{ fontWeight: 700, color: "#4f8ef7" }}>{fmt(i.qty * i.preco)}</span>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              {!detalheVenda.cancelada && update && (
                <button className="btn btn-danger" onClick={() => { setConfirmCancelarVenda(detalheVenda); }} style={{ flex: 1 }}>
                  🚫 Cancelar Venda
                </button>
              )}
              <button className="btn btn-ghost" onClick={() => setDetalheVenda(null)} style={{ flex: 1 }}>Fechar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Confirmar Cancelar Venda */}
      {confirmCancelarVenda && (
        <div className="modal-overlay" style={{ zIndex: 300 }}>
          <div className="modal" style={{ maxWidth: 380 }}>
            <div style={{ fontWeight: 700, fontSize: 16, color: "#e05260", marginBottom: 12 }}>🚫 Cancelar Venda?</div>
            <div style={{ fontSize: 13, color: "#a0a8c0", marginBottom: 12, lineHeight: 1.6 }}>
              O estoque dos produtos será <strong style={{ color: "#e8eaf0" }}>devolvido automaticamente</strong>.
            </div>
            <div style={{ background: "#2e1018", borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 12 }}>
              {(confirmCancelarVenda.itens || []).map((i,idx) => (
                <div key={idx} style={{ color: "#22c97a" }}>+ {i.qty}x {i.nome} (volta ao estoque)</div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-danger" onClick={() => {
                update(d => ({
                  ...d,
                  vendas: d.vendas.map(v => v.id === confirmCancelarVenda.id ? { ...v, cancelada: true } : v),
                  produtos: d.produtos.map(p => {
                    const item = (confirmCancelarVenda.itens || []).find(i => i.id === p.id);
                    return item ? { ...p, estoque: p.estoque + item.qty } : p;
                  })
                }));
                setConfirmCancelarVenda(null);
                setDetalheVenda(null);
              }} style={{ flex: 1 }}>Confirmar</button>
              <button className="btn btn-ghost" onClick={() => setConfirmCancelarVenda(null)} style={{ flex: 1 }}>Voltar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// ABA CADASTRO
// ══════════════════════════════════════════════════════════════════
function AbaCadastro({ data, update }) {
  const [showForm, setShowForm] = useState(false);
  const [editando, setEditando] = useState(null);
  const [busca, setBusca] = useState("");
  const [detalheCliente, setDetalheCliente] = useState(null);
  const [form, setForm] = useState({ nome: "", telefone: "", limite: 200, endereco: "", obs: "", aniversario: "" });

  const clientesFiltrados = data.clientes.filter(c =>
    !busca.trim() ||
    c.nome.toLowerCase().includes(busca.toLowerCase()) ||
    (c.telefone || "").includes(busca) ||
    (c.endereco || "").toLowerCase().includes(busca.toLowerCase())
  );

  const abrirNovo = () => {
    setForm({ nome: "", telefone: "", limite: 200, endereco: "", obs: "", aniversario: "" });
    setEditando(null); setShowForm(true);
  };
  const abrirEditar = (c) => {
    setForm({ nome: c.nome, telefone: c.telefone, limite: c.limite, endereco: c.endereco || "", obs: c.obs || "", aniversario: c.aniversario || "" });
    setEditando(c.id); setShowForm(true);
  };

  const salvar = () => {
    if (!form.nome) return;
    update((d) => {
      if (editando) return { ...d, clientes: d.clientes.map((c) => c.id === editando ? { ...c, ...form, limite: Number(form.limite) } : c) };
      const id = d.nextId.cliente;
      return { ...d, clientes: [...d.clientes, { id, nome: form.nome, telefone: form.telefone, limite: Number(form.limite), saldo: 0, endereco: form.endereco, obs: form.obs, aniversario: form.aniversario }], nextId: { ...d.nextId, cliente: id + 1 } };
    });
    setShowForm(false);
  };

  const [confirmExcluir, setConfirmExcluir] = useState(null);
  const pedirExcluir = (c) => setConfirmExcluir({ id: c.id, nome: c.nome });
  const confirmarExcluir = () => {
    update((d) => ({ ...d, clientes: d.clientes.filter((c) => c.id !== confirmExcluir.id) }));
    setConfirmExcluir(null);
  };

  // Histórico de compras do cliente
  const comprasCliente = detalheCliente
    ? data.vendas.filter(v => v.clienteId === detalheCliente.id || (v.pagamento === "fiado" && v.clienteId === detalheCliente.id)).reverse()
    : [];

  // Aniversariantes de hoje
  const hoje = new Date();
  const aniversariantes = data.clientes.filter(c => {
    if (!c.aniversario) return false;
    const parts = c.aniversario.split("-");
    const mes = parts[1]; const dia = parts[2];
    return mes && dia && Number(mes) === hoje.getMonth() + 1 && Number(dia) === hoje.getDate();
  });

  return (
    <div>
      <div className="section-title">👤 Cadastro de Clientes</div>

      {aniversariantes.length > 0 && (
        <div style={{ background: "#1a1e35", border: "1.5px solid #b57cf7", borderRadius: 12, padding: "12px 16px", marginBottom: 16, fontSize: 13 }}>
          🎂 <strong style={{ color: "#b57cf7" }}>Aniversariante(s) hoje:</strong> {aniversariantes.map(c => c.nome).join(", ")}
        </div>
      )}

      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <input className="input" placeholder="🔍 Buscar por nome, telefone ou endereço..." value={busca} onChange={e => setBusca(e.target.value)} style={{ flex: 1 }} />
        <button className="btn btn-primary" onClick={abrirNovo} style={{ whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}>{icons.plus} Novo</button>
      </div>

      {/* Cards de clientes */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {clientesFiltrados.map((c) => (
          <div key={c.id} style={{ background: "#161923", border: `1px solid ${c.saldo > 0 ? "#2e2510" : "#22263a"}`, borderLeft: `4px solid ${c.saldo > 0 ? "#f0b429" : "#22263a"}`, borderRadius: 12, padding: "12px 14px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#e8eaf0" }}>{c.nome}</div>
                <div style={{ fontSize: 11, color: "#6b7499", marginTop: 3, display: "flex", gap: 10, flexWrap: "wrap" }}>
                  {c.telefone && <span>📞 {c.telefone}</span>}
                  {c.endereco && <span>📍 {c.endereco}</span>}
                  {c.aniversario && <span>🎂 {new Date(c.aniversario + "T12:00").toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}</span>}
                </div>
                {c.obs && <div style={{ fontSize: 11, color: "#a0a8c0", marginTop: 3 }}>📝 {c.obs}</div>}
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontWeight: 700, color: c.saldo > 0 ? "#e05260" : "#22c97a", fontSize: 14 }}>{fmt(c.saldo)}</div>
                <div style={{ fontSize: 10, color: "#6b7499" }}>limite {fmt(c.limite)}</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 10, borderTop: "1px solid #22263a", paddingTop: 8 }}>
              <button className="btn btn-ghost" onClick={() => setDetalheCliente(c)} style={{ flex: 1, fontSize: 12 }}>📋 Histórico</button>
              <button className="btn btn-ghost" onClick={() => abrirEditar(c)} style={{ flex: 1, fontSize: 12 }}>✏️ Editar</button>
              <button className="btn btn-danger" onClick={() => pedirExcluir(c)} style={{ padding: "7px 12px" }}>{icons.trash}</button>
            </div>
          </div>
        ))}
        {clientesFiltrados.length === 0 && (
          <div className="card" style={{ textAlign: "center", color: "#6b7499", padding: 40 }}>Nenhum cliente encontrado</div>
        )}
      </div>

      {/* Modal histórico do cliente */}
      {detalheCliente && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>📋 {detalheCliente.nome}</div>
                <div style={{ fontSize: 12, color: "#6b7499" }}>Histórico de compras</div>
              </div>
              <button className="btn btn-ghost" onClick={() => setDetalheCliente(null)} style={{ padding: "4px 10px" }}>✕</button>
            </div>
            <div style={{ background: "#11141e", borderRadius: 10, padding: 14, marginBottom: 14 }}>
              <div className="grid2">
                <div><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 2 }}>SALDO FIADO</div><div style={{ fontWeight: 700, color: detalheCliente.saldo > 0 ? "#e05260" : "#22c97a", fontSize: 18 }}>{fmt(detalheCliente.saldo)}</div></div>
                <div><div style={{ fontSize: 11, color: "#6b7499", marginBottom: 2 }}>TOTAL COMPRADO</div><div style={{ fontWeight: 700, color: "#4f8ef7", fontSize: 18 }}>{fmt(comprasCliente.reduce((s,v) => s+v.total, 0))}</div></div>
              </div>
            </div>
            <div style={{ maxHeight: 320, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
              {comprasCliente.length === 0 && <div style={{ textAlign: "center", color: "#6b7499", padding: 32 }}>Nenhuma compra registrada</div>}
              {comprasCliente.map((v) => (
                <div key={v.id} style={{ background: "#1a1d27", borderRadius: 8, padding: "10px 12px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                    <div style={{ fontSize: 11, color: "#6b7499" }}>{new Date(v.data).toLocaleString("pt-BR")}</div>
                    <div style={{ fontWeight: 700, color: v.pagamento === "fiado" ? "#e05260" : "#4f8ef7" }}>{fmt(v.total)}</div>
                  </div>
                  <div style={{ fontSize: 11, color: "#a0a8c0", marginBottom: 4 }}>
                    {(v.itens || []).slice(0,3).map(i => `${i.qty}x ${i.nome}`).join(", ")}
                    {(v.itens || []).length > 3 && ` +${v.itens.length-3}`}
                  </div>
                  <span className="tag tag-blue" style={{ fontSize: 10 }}>{v.pagamento}</span>
                </div>
              ))}
            </div>
            <button className="btn btn-ghost" onClick={() => setDetalheCliente(null)} style={{ width: "100%", marginTop: 14 }}>Fechar</button>
          </div>
        </div>
      )}

      {/* Modal form cliente */}
      {showForm && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 18 }}>{editando ? "Editar Cliente" : "Novo Cliente"}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <div style={{ gridColumn: "1/-1" }}>
                <div className="label">Nome Completo *</div>
                <input type="text" className="input" value={form.nome} onChange={e => setForm(f => ({...f, nome: e.target.value}))} />
              </div>
              <div>
                <div className="label">Telefone</div>
                <input type="tel" className="input" value={form.telefone} onChange={e => setForm(f => ({...f, telefone: e.target.value}))} placeholder="(00) 00000-0000" />
              </div>
              <div>
                <div className="label">Limite de Fiado (R$)</div>
                <input type="number" className="input" value={form.limite} onChange={e => setForm(f => ({...f, limite: e.target.value}))} />
              </div>
              <div style={{ gridColumn: "1/-1" }}>
                <div className="label">Endereço</div>
                <input type="text" className="input" value={form.endereco} onChange={e => setForm(f => ({...f, endereco: e.target.value}))} placeholder="Rua, número, bairro..." />
              </div>
              <div>
                <div className="label">Data de Aniversário</div>
                <input type="date" className="input" value={form.aniversario} onChange={e => setForm(f => ({...f, aniversario: e.target.value}))} />
              </div>
              <div>
                <div className="label">Observações</div>
                <input type="text" className="input" value={form.obs} onChange={e => setForm(f => ({...f, obs: e.target.value}))} placeholder="Ex: cliente vip, paga dia 5..." />
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
              <button className="btn btn-success" onClick={salvar} style={{ flex: 1 }}>Salvar</button>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {confirmExcluir && (
        <ConfirmModal
          titulo="Excluir cliente?"
          descricao={`Tem certeza que deseja excluir "${confirmExcluir.nome}"? O histórico de fiado vinculado também será afetado.`}
          onConfirm={confirmarExcluir}
          onCancel={() => setConfirmExcluir(null)}
        />
      )}
    </div>
  );
}

function AbaCompras({ data, update }) {
  const [subAba, setSubAba] = useState("compras");       // "compras" | "fornecedores"
  const [busca, setBusca] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editandoCompra, setEditandoCompra] = useState(null); // compra sendo editada
  const [detalhe, setDetalhe] = useState(null);          // compra selecionada para ver detalhe
  const [confirmCancelar, setConfirmCancelar] = useState(null); // compra a cancelar
  const [itens, setItens] = useState([]);
  const [fornecedorSel, setFornecedorSel] = useState(""); // id do fornecedor
  const [fornecedorTexto, setFornecedorTexto] = useState(""); // texto livre
  const [prodSel, setProdSel] = useState("");
  const [prodBusca, setProdBusca] = useState("");
  const [showProdLista, setShowProdLista] = useState(false);
  const [qtdSel, setQtdSel] = useState(1);
  const [custoSel, setCustoSel] = useState("");
  const [notaFiscal, setNotaFiscal] = useState("");
  const [obs, setObs] = useState("");

  // Fornecedores state
  const [showFornForm, setShowFornForm] = useState(false);
  const [editForn, setEditForn] = useState(null);
  const [forn, setForn] = useState({ nome: "", telefone: "", cnpj: "", email: "", produtos: "", obs: "" });
  const [buscaForn, setBuscaForn] = useState("");
  const [confirmDelForn, setConfirmDelForn] = useState(null);

  const fornecedores = data.fornecedores || [];

  // ── Nome do fornecedor para exibição ─────────────────────────
  const nomeForn = (c) => {
    if (c.fornecedorId) {
      const f = fornecedores.find(f => f.id === c.fornecedorId);
      return f ? f.nome : c.fornecedor || "-";
    }
    return c.fornecedor || "-";
  };

  // ── Compras filtradas pela busca ──────────────────────────────
  const comprasFiltradas = [...data.compras].reverse().filter(c => {
    if (!busca.trim()) return true;
    const b = busca.toLowerCase();
    const nome = nomeForn(c).toLowerCase();
    const nota = (c.notaFiscal || "").toLowerCase();
    const produtos = (c.itens || []).map(i => i.nome.toLowerCase()).join(" ");
    return nome.includes(b) || nota.includes(b) || produtos.includes(b);
  });

  // ── Stats ─────────────────────────────────────────────────────
  const totalComprado = data.compras.filter(c => !c.cancelada).reduce((s, c) => s + (c.total || 0), 0);
  const comprasAtivas = data.compras.filter(c => !c.cancelada).length;
  const comprasCanceladas = data.compras.filter(c => c.cancelada).length;

  // ── Adicionar item à compra em edição ─────────────────────────
  const addItem = () => {
    if (!prodSel || qtdSel < 1) return;
    const prod = data.produtos.find((p) => p.id === Number(prodSel));
    if (!prod) return;
    setItens((it) => {
      const ex = it.find((i) => i.id === prod.id);
      if (ex) return it.map((i) => i.id === prod.id
        ? { ...i, qty: i.qty + Number(qtdSel), custo: Number(custoSel) || i.custo }
        : i);
      return [...it, { id: prod.id, nome: prod.nome, qty: Number(qtdSel), custo: Number(custoSel) || prod.custo }];
    });
    setProdSel(""); setQtdSel(1); setCustoSel("");
  };

  const removeItemForm = (id) => setItens(it => it.filter(i => i.id !== id));

  const total = itens.reduce((s, i) => s + i.qty * (i.custo || 0), 0);

  // ── Finalizar compra ──────────────────────────────────────────
  const finalizar = () => {
    if (!itens.length) return;
    const fId = fornecedorSel ? Number(fornecedorSel) : null;
    const fNome = fId ? (fornecedores.find(f => f.id === fId)?.nome || "") : fornecedorTexto;

    update((d) => {
      if (editandoCompra) {
        // 1) Reverte estoque da compra original
        let prods = d.produtos.map((p) => {
          const item = (editandoCompra.itens || []).find(i => i.id === p.id);
          return item ? { ...p, estoque: Math.max(0, p.estoque - item.qty) } : p;
        });
        // 2) Aplica estoque da nova versão
        prods = prods.map((p) => {
          const item = itens.find(i => i.id === p.id);
          return item ? { ...p, estoque: p.estoque + item.qty, custo: item.custo || p.custo } : p;
        });
        const novaTotal = itens.reduce((s, i) => s + i.qty * (i.custo || 0), 0);
        return {
          ...d,
          produtos: prods,
          compras: d.compras.map(c => c.id === editandoCompra.id
            ? { ...c, fornecedor: fNome, fornecedorId: fId, itens, total: novaTotal, notaFiscal, obs, editadaEm: new Date().toISOString() }
            : c),
        };
      }

      // Nova compra
      const id = d.nextId.compra;
      const novosProdutos = d.produtos.map((p) => {
        const item = itens.find((i) => i.id === p.id);
        return item ? { ...p, estoque: p.estoque + item.qty, custo: item.custo || p.custo } : p;
      });
      const novaCompra = {
        id, data: new Date().toISOString(),
        fornecedor: fNome, fornecedorId: fId,
        itens, total, notaFiscal, obs, cancelada: false,
      };
      return { ...d, produtos: novosProdutos, compras: [...d.compras, novaCompra], nextId: { ...d.nextId, compra: id + 1 } };
    });

    setItens([]); setFornecedorSel(""); setFornecedorTexto(""); setNotaFiscal(""); setObs("");
    setEditandoCompra(null); setShowForm(false);
  };

  // ── Cancelar compra (estorno de estoque) ──────────────────────
  const cancelarCompra = (compra) => {
    update((d) => {
      // Reverte o estoque dos itens
      const novosProdutos = d.produtos.map((p) => {
        const item = (compra.itens || []).find((i) => i.id === p.id);
        return item ? { ...p, estoque: Math.max(0, p.estoque - item.qty) } : p;
      });
      return {
        ...d,
        produtos: novosProdutos,
        compras: d.compras.map(c => c.id === compra.id ? { ...c, cancelada: true, dataCancelamento: new Date().toISOString() } : c),
      };
    });
    setConfirmCancelar(null);
    setDetalhe(null);
  };

  // ── Abrir compra para edição ──────────────────────────────────
  const abrirEditarCompra = (compra) => {
    setEditandoCompra(compra);
    setItens(compra.itens || []);
    const fId = compra.fornecedorId ? String(compra.fornecedorId) : "";
    setFornecedorSel(fId);
    setFornecedorTexto(fId ? "" : (compra.fornecedor || ""));
    setNotaFiscal(compra.notaFiscal || "");
    setObs(compra.obs || "");
    setDetalhe(null);
    setShowForm(true);
  };

  // ── CRUD Fornecedores ─────────────────────────────────────────
  const abrirFornForm = (f) => {
    if (f) { setEditForn(f); setForn({ nome: f.nome, telefone: f.telefone || "", cnpj: f.cnpj || "", email: f.email || "", produtos: f.produtos || "", obs: f.obs || "" }); }
    else   { setEditForn(null); setForn({ nome: "", telefone: "", cnpj: "", email: "", produtos: "", obs: "" }); }
    setShowFornForm(true);
  };

  const salvarForn = () => {
    if (!forn.nome.trim()) return;
    update((d) => {
      const lista = d.fornecedores || [];
      if (editForn) {
        return { ...d, fornecedores: lista.map(f => f.id === editForn.id ? { ...f, ...forn } : f) };
      }
      const id = (d.nextId.fornecedor || 1);
      return { ...d, fornecedores: [...lista, { id, ...forn }], nextId: { ...d.nextId, fornecedor: id + 1 } };
    });
    setShowFornForm(false);
  };

  const excluirForn = (id) => {
    update((d) => ({ ...d, fornecedores: (d.fornecedores || []).filter(f => f.id !== id) }));
    setConfirmDelForn(null);
  };

  const fornFiltrados = fornecedores.filter(f => {
    if (!buscaForn.trim()) return true;
    const b = buscaForn.toLowerCase();
    return f.nome.toLowerCase().includes(b) || (f.cnpj || "").includes(b) || (f.produtos || "").toLowerCase().includes(b);
  });

  // ── RENDER ────────────────────────────────────────────────────
  return (
    <div>
      <div className="section-title">🏪 Compras</div>

      {/* Sub-abas */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["compras","📦 Compras"],["fornecedores","🤝 Fornecedores"]].map(([k,l]) => (
          <button key={k} className={`btn ${subAba===k?"btn-primary":"btn-ghost"}`} onClick={() => setSubAba(k)} style={{ fontSize: 13 }}>{l}</button>
        ))}
      </div>

      {/* ════ ABA COMPRAS ════ */}
      {subAba === "compras" && (<>
        {/* Stats */}
        <div className="grid3" style={{ marginBottom: 20 }}>
          <div className="stat-card">
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>TOTAL COMPRADO</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: "#4f8ef7" }}>{fmt(totalComprado)}</div>
          </div>
          <div className="stat-card">
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>COMPRAS ATIVAS</div>
            <div style={{ fontSize: 26, fontWeight: 700, color: "#22c97a" }}>{comprasAtivas}</div>
          </div>
          <div className="stat-card">
            <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 6 }}>CANCELADAS</div>
            <div style={{ fontSize: 26, fontWeight: 700, color: "#e05260" }}>{comprasCanceladas}</div>
          </div>
        </div>

        {/* Barra de busca + botão nova compra */}
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          <input className="input" placeholder="🔍 Buscar por fornecedor, produto ou nota fiscal..." value={busca} onChange={e => setBusca(e.target.value)} style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={() => setShowForm(true)} style={{ whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}>
            {icons.plus} Nova Compra
          </button>
        </div>

        {/* Tabela de compras */}
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <table className="table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Fornecedor</th>
                <th>Produtos</th>
                <th>Total</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {comprasFiltradas.length === 0 && (
                <tr><td colSpan={5} style={{ textAlign: "center", color: "#6b7499", padding: 32 }}>Nenhuma compra encontrada</td></tr>
              )}
              {comprasFiltradas.map((c) => (
                <tr key={c.id} onClick={() => setDetalhe(c)}
                  style={{ opacity: c.cancelada ? 0.5 : 1, cursor: "pointer" }}
                  onMouseEnter={(e) => e.currentTarget.style.background = "#1a1d27"}
                  onMouseLeave={(e) => e.currentTarget.style.background = ""}>
                  <td style={{ color: "#6b7499", fontSize: 12, whiteSpace: "nowrap" }}>
                    {new Date(c.data).toLocaleDateString("pt-BR")}
                    <div style={{ fontSize: 10 }}>{new Date(c.data).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</div>
                  </td>
                  <td style={{ fontWeight: 500 }}>{nomeForn(c)}</td>
                  <td style={{ fontSize: 12, color: "#a0a8c0" }}>
                    {(c.itens || []).slice(0,2).map(i => i.nome).join(", ")}
                    {(c.itens || []).length > 2 && <span style={{ color: "#6b7499" }}> +{(c.itens||[]).length-2}</span>}
                  </td>
                  <td style={{ fontWeight: 700, color: c.cancelada ? "#e05260" : "#4f8ef7", whiteSpace: "nowrap" }}>{fmt(c.total)}</td>
                  <td>
                    {c.cancelada
                      ? <span className="tag tag-red">Cancelada</span>
                      : <span className="tag tag-green">Ativa</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ fontSize: 11, color: "#6b7499", textAlign: "center", marginTop: 8 }}>👆 Toque em uma compra para ver detalhes</div>
      </>)}

      {/* ════ ABA FORNECEDORES ════ */}
      {subAba === "fornecedores" && (<>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          <input className="input" placeholder="🔍 Buscar fornecedor..." value={buscaForn} onChange={e => setBuscaForn(e.target.value)} style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={() => abrirFornForm(null)} style={{ whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}>
            {icons.plus} Novo Fornecedor
          </button>
        </div>

        {fornFiltrados.length === 0 && (
          <div className="card" style={{ textAlign: "center", color: "#6b7499", padding: 40 }}>
            Nenhum fornecedor cadastrado ainda.
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {fornFiltrados.map(f => {
            const comprasDoForn = data.compras.filter(c => !c.cancelada && (c.fornecedorId === f.id || c.fornecedor === f.nome));
            const totalForn = comprasDoForn.reduce((s,c) => s + (c.total||0), 0);
            return (
              <div key={f.id} className="card" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{f.nome}</div>
                    <div style={{ fontSize: 12, color: "#6b7499", display: "flex", gap: 12, flexWrap: "wrap" }}>
                      {f.telefone && <span>📞 {f.telefone}</span>}
                      {f.cnpj    && <span>📋 {f.cnpj}</span>}
                      {f.email   && <span>✉️ {f.email}</span>}
                    </div>
                    {f.produtos && <div style={{ fontSize: 12, color: "#a0a8c0", marginTop: 4 }}>Produtos: {f.produtos}</div>}
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button className="btn btn-ghost" onClick={() => abrirFornForm(f)} style={{ fontSize: 11, padding: "5px 10px" }}>✏️</button>
                    <button className="btn btn-danger" onClick={() => setConfirmDelForn(f)} style={{ fontSize: 11, padding: "5px 10px" }}>{icons.trash}</button>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 16, fontSize: 12, borderTop: "1px solid #22263a", paddingTop: 8, color: "#6b7499" }}>
                  <span>🛒 <strong style={{ color: "#e8eaf0" }}>{comprasDoForn.length}</strong> compras</span>
                  <span>💰 Total comprado: <strong style={{ color: "#4f8ef7" }}>{fmt(totalForn)}</strong></span>
                  {f.obs && <span>📝 {f.obs}</span>}
                </div>
              </div>
            );
          })}
        </div>
      </>)}

      {/* ════ MODAL DETALHE DA COMPRA ════ */}
      {detalhe && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 520 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontWeight: 700, fontSize: 16 }}>
                📦 Compra #{detalhe.id}
                {detalhe.cancelada && <span className="tag tag-red" style={{ marginLeft: 8 }}>Cancelada</span>}
              </div>
              <button className="btn btn-ghost" onClick={() => setDetalhe(null)} style={{ padding: "4px 10px" }}>✕</button>
            </div>

            <div style={{ background: "#11141e", borderRadius: 10, padding: 14, marginBottom: 14, fontSize: 13 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div><div style={{ color: "#6b7499", fontSize: 11, marginBottom: 2 }}>DATA</div><div>{new Date(detalhe.data).toLocaleString("pt-BR")}</div></div>
                <div><div style={{ color: "#6b7499", fontSize: 11, marginBottom: 2 }}>FORNECEDOR</div><div style={{ fontWeight: 600 }}>{nomeForn(detalhe)}</div></div>
                {detalhe.notaFiscal && <div><div style={{ color: "#6b7499", fontSize: 11, marginBottom: 2 }}>NOTA FISCAL</div><div>{detalhe.notaFiscal}</div></div>}
                {detalhe.cancelada && <div><div style={{ color: "#6b7499", fontSize: 11, marginBottom: 2 }}>CANCELADA EM</div><div style={{ color: "#e05260" }}>{new Date(detalhe.dataCancelamento).toLocaleString("pt-BR")}</div></div>}
              </div>
              {detalhe.obs && <div style={{ marginTop: 10, color: "#a0a8c0" }}>📝 {detalhe.obs}</div>}
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#6b7499", marginBottom: 8, textTransform: "uppercase", letterSpacing: ".5px" }}>Produtos comprados</div>
              {(detalhe.itens || []).map((i, idx) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", background: "#1a1d27", borderRadius: 8, marginBottom: 6, fontSize: 13 }}>
                  <span style={{ fontWeight: 500 }}>{i.nome}</span>
                  <div style={{ display: "flex", gap: 16, color: "#6b7499" }}>
                    <span>{i.qty}x {fmt(i.custo)}</span>
                    <span style={{ fontWeight: 700, color: "#4f8ef7" }}>{fmt(i.qty * i.custo)}</span>
                  </div>
                </div>
              ))}
              <div style={{ textAlign: "right", fontWeight: 700, fontSize: 15, color: "#4f8ef7", marginTop: 8 }}>
                Total: {fmt(detalhe.total)}
              </div>
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              {!detalhe.cancelada && (
                <button className="btn btn-primary" onClick={() => abrirEditarCompra(detalhe)} style={{ flex: 1 }}>
                  ✏️ Alterar
                </button>
              )}
              {!detalhe.cancelada && (
                <button className="btn btn-danger" onClick={() => setConfirmCancelar(detalhe)} style={{ flex: 1 }}>
                  🚫 Cancelar
                </button>
              )}
              <button className="btn btn-ghost" onClick={() => setDetalhe(null)} style={{ flex: 1 }}>Fechar</button>
            </div>
          </div>
        </div>
      )}

      {/* ════ MODAL CONFIRMAR CANCELAMENTO ════ */}
      {confirmCancelar && (
        <div className="modal-overlay" style={{ zIndex: 300 }}>
          <div className="modal" style={{ maxWidth: 400 }}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12, color: "#e05260" }}>🚫 Cancelar Compra?</div>
            <div style={{ fontSize: 13, color: "#a0a8c0", marginBottom: 6, lineHeight: 1.6 }}>
              Esta ação vai <strong style={{ color: "#e8eaf0" }}>estornar o estoque</strong> de todos os produtos dessa compra.
            </div>
            <div style={{ background: "#2e1018", borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 12 }}>
              {(confirmCancelar.itens || []).map((i,idx) => (
                <div key={idx} style={{ color: "#e05260" }}>- {i.nome}: -{i.qty} unid.</div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-danger" onClick={() => cancelarCompra(confirmCancelar)} style={{ flex: 1 }}>Confirmar Cancelamento</button>
              <button className="btn btn-ghost" onClick={() => setConfirmCancelar(null)} style={{ flex: 1 }}>Voltar</button>
            </div>
          </div>
        </div>
      )}

      {/* ════ MODAL NOVA COMPRA ════ */}
      {showForm && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 580 }}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 18 }}>{editandoCompra ? "✏️ Editar Compra #" + editandoCompra.id : "📦 Nova Compra"}</div>

            <div className="grid2" style={{ marginBottom: 14 }}>
              <div>
                <div className="label">Fornecedor cadastrado</div>
                <select className="input" value={fornecedorSel} onChange={e => { setFornecedorSel(e.target.value); setFornecedorTexto(""); }}>
                  <option value="">Selecione ou digite abaixo...</option>
                  {fornecedores.map(f => <option key={f.id} value={f.id}>{f.nome}</option>)}
                </select>
              </div>
              <div>
                <div className="label">Ou digite o nome</div>
                <input className="input" value={fornecedorTexto} onChange={e => { setFornecedorTexto(e.target.value); setFornecedorSel(""); }} placeholder="Nome do fornecedor" disabled={!!fornecedorSel} />
              </div>
            </div>

            <div className="grid2" style={{ marginBottom: 14 }}>
              <div>
                <div className="label">Nota Fiscal (opcional)</div>
                <input className="input" value={notaFiscal} onChange={e => setNotaFiscal(e.target.value)} placeholder="Número da NF" />
              </div>
              <div>
                <div className="label">Observações</div>
                <input className="input" value={obs} onChange={e => setObs(e.target.value)} placeholder="Ex: entrega parcial..." />
              </div>
            </div>

            <div style={{ background: "#11141e", borderRadius: 10, padding: 14, marginBottom: 14 }}>
              <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 12, color: "#a0a8c0" }}>Adicionar Produto</div>

              {/* Busca de produto com lista filtrada */}
              <div style={{ marginBottom: 10, position: "relative" }}>
                <div className="label">Produto</div>
                <input
                  className="input"
                  placeholder="🔍 Digite para buscar..."
                  value={prodBusca}
                  onChange={e => { setProdBusca(e.target.value); setShowProdLista(true); setProdSel(""); }}
                  onFocus={() => setShowProdLista(true)}
                  style={{ fontWeight: prodSel ? 600 : 400, color: prodSel ? "#e8eaf0" : "#a0a8c0" }}
                />
                {showProdLista && prodBusca && (
                  <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "#1a1d27", border: "1px solid #2a2f45", borderRadius: 8, zIndex: 50, maxHeight: 200, overflowY: "auto", marginTop: 2 }}>
                    {data.produtos
                      .filter(p => p.nome.toLowerCase().includes(prodBusca.toLowerCase()))
                      .slice(0, 12)
                      .map(p => (
                        <div key={p.id} onClick={() => {
                          setProdSel(String(p.id));
                          setProdBusca(p.nome);
                          setCustoSel(p.custo || "");
                          setShowProdLista(false);
                        }} style={{ padding: "9px 12px", cursor: "pointer", fontSize: 13, borderBottom: "1px solid #22263a", display: "flex", justifyContent: "space-between" }}
                          onMouseEnter={e => e.currentTarget.style.background = "#22263a"}
                          onMouseLeave={e => e.currentTarget.style.background = ""}
                        >
                          <span>{p.nome}</span>
                          <span style={{ color: "#6b7499", fontSize: 11 }}>Estoque: {p.estoque}</span>
                        </div>
                      ))
                    }
                    {data.produtos.filter(p => p.nome.toLowerCase().includes(prodBusca.toLowerCase())).length === 0 && (
                      <div style={{ padding: "10px 12px", fontSize: 13, color: "#6b7499" }}>Nenhum produto encontrado</div>
                    )}
                  </div>
                )}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 8, alignItems: "end" }}>
                <div>
                  <div className="label">Qtd</div>
                  <input type="number" className="input" value={qtdSel} min={1} onChange={(e) => setQtdSel(e.target.value)} />
                </div>
                <div>
                  <div className="label">Custo Unit.</div>
                  <input type="number" className="input" value={custoSel} onChange={(e) => setCustoSel(e.target.value)} placeholder="R$" />
                </div>
                <button className="btn btn-primary" onClick={() => { addItem(); setProdBusca(""); }} style={{ height: 38 }} disabled={!prodSel}>{icons.plus}</button>
              </div>
            </div>

            {itens.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                {itens.map((i) => (
                  <div key={i.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 10px", background: "#1a1d27", borderRadius: 8, marginBottom: 6, fontSize: 13 }}>
                    <span style={{ flex: 1 }}>{i.nome}</span>
                    <span style={{ color: "#6b7499", marginRight: 12 }}>{i.qty}x {fmt(i.custo)}</span>
                    <span style={{ fontWeight: 700, color: "#4f8ef7", marginRight: 12 }}>{fmt(i.qty * i.custo)}</span>
                    <button className="btn btn-danger" onClick={() => removeItemForm(i.id)} style={{ padding: "3px 8px" }}>{icons.trash}</button>
                  </div>
                ))}
                <div style={{ textAlign: "right", fontWeight: 700, fontSize: 15, color: "#4f8ef7", marginTop: 8 }}>Total: {fmt(total)}</div>
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-success" onClick={finalizar} disabled={!itens.length} style={{ flex: 1 }}>✅ Confirmar Compra</button>
              <button className="btn btn-ghost" onClick={() => { setShowForm(false); setEditandoCompra(null); setItens([]); setFornecedorSel(""); setFornecedorTexto(""); setNotaFiscal(""); setObs(""); setProdBusca(""); setProdSel(""); }} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ════ MODAL FORM FORNECEDOR ════ */}
      {showFornForm && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 18 }}>
              {editForn ? "✏️ Editar Fornecedor" : "🤝 Novo Fornecedor"}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div><div className="label">Nome *</div><input className="input" value={forn.nome} onChange={e => setForn(f => ({...f, nome: e.target.value}))} placeholder="Nome do fornecedor" /></div>
              <div className="grid2">
                <div><div className="label">Telefone</div><input className="input" value={forn.telefone} onChange={e => setForn(f => ({...f, telefone: e.target.value}))} placeholder="(00) 00000-0000" /></div>
                <div><div className="label">CNPJ</div><input className="input" value={forn.cnpj} onChange={e => setForn(f => ({...f, cnpj: e.target.value}))} placeholder="00.000.000/0000-00" /></div>
              </div>
              <div><div className="label">E-mail</div><input className="input" value={forn.email} onChange={e => setForn(f => ({...f, email: e.target.value}))} placeholder="email@fornecedor.com" /></div>
              <div><div className="label">Produtos que fornece</div><input className="input" value={forn.produtos} onChange={e => setForn(f => ({...f, produtos: e.target.value}))} placeholder="Ex: Bebidas, Laticínios..." /></div>
              <div><div className="label">Observações</div><input className="input" value={forn.obs} onChange={e => setForn(f => ({...f, obs: e.target.value}))} placeholder="Dias de entrega, contato, etc." /></div>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              <button className="btn btn-success" onClick={salvarForn} style={{ flex: 1 }}>Salvar</button>
              <button className="btn btn-ghost" onClick={() => setShowFornForm(false)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ════ MODAL CONFIRMAR EXCLUIR FORNECEDOR ════ */}
      {confirmDelForn && (
        <div className="modal-overlay" style={{ zIndex: 300 }}>
          <div className="modal" style={{ maxWidth: 360 }}>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 10 }}>Excluir fornecedor?</div>
            <div style={{ fontSize: 13, color: "#a0a8c0", marginBottom: 20 }}>
              "<strong style={{ color: "#e8eaf0" }}>{confirmDelForn.nome}</strong>" será removido. As compras já feitas não são afetadas.
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-danger" onClick={() => excluirForn(confirmDelForn.id)} style={{ flex: 1 }}>Excluir</button>
              <button className="btn btn-ghost" onClick={() => setConfirmDelForn(null)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// ABA TAXAS
// ══════════════════════════════════════════════════════════════════
function AbaTaxas({ data, update }) {
  const [taxas, setTaxas] = useState({ ...data.taxas });
  const [salvo, setSalvo] = useState(false);

  const salvar = () => {
    update((d) => ({ ...d, taxas: { pix: Number(taxas.pix), credito: Number(taxas.credito), debito: Number(taxas.debito) } }));
    setSalvo(true);
    setTimeout(() => setSalvo(false), 2000);
  };

  const formas = [
    { key: "pix", label: "PIX", icon: "📱", desc: "Taxa cobrada pelo processador de pagamento PIX" },
    { key: "credito", label: "Cartão de Crédito", icon: "💳", desc: "Taxa da maquininha para crédito à vista" },
    { key: "debito", label: "Cartão de Débito", icon: "🏧", desc: "Taxa da maquininha para débito" },
  ];

  const exemplos = [100, 250, 500, 1000];

  return (
    <div>
      <div className="section-title">💰 Taxas de Pagamento</div>

      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, color: "#6b7499", lineHeight: 1.6, maxWidth: 520, marginBottom: 20 }}>
          Configure as taxas da maquininha e meios de pagamento. O sistema calculará automaticamente o valor líquido recebido em cada venda.
        </div>

        {salvo && (
          <div style={{ background: "#163829", border: "1px solid #22c97a", color: "#22c97a", padding: "10px 16px", borderRadius: 10, marginBottom: 16, fontWeight: 600, display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
            {icons.check} Taxas salvas com sucesso!
          </div>
        )}

        <div className="grid3" style={{ marginBottom: 24 }}>
          {formas.map((f) => (
            <div key={f.key} className="card">
              <div style={{ fontSize: 24, marginBottom: 10 }}>{f.icon}</div>
              <div style={{ fontWeight: 700, marginBottom: 4, fontSize: 14 }}>{f.label}</div>
              <div style={{ fontSize: 11, color: "#6b7499", marginBottom: 14, lineHeight: 1.4 }}>{f.desc}</div>
              <div className="label">Taxa (%)</div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <input type="number" className="input" step="0.1" min={0} max={20} value={taxas[f.key]} onChange={(e) => setTaxas((t) => ({ ...t, [f.key]: e.target.value }))} style={{ width: "100%" }} />
                <span style={{ color: "#6b7499", whiteSpace: "nowrap", fontSize: 13 }}>%</span>
              </div>
              {Number(taxas[f.key]) > 0 && (
                <div style={{ marginTop: 10, padding: "8px 10px", background: "#11141e", borderRadius: 8, fontSize: 12, color: "#6b7499" }}>
                  Em R$100: recebe <span style={{ color: "#22c97a", fontWeight: 700 }}>{fmt(100 * (1 - Number(taxas[f.key]) / 100))}</span>
                </div>
              )}
            </div>
          ))}
        </div>

        <button className="btn btn-success" onClick={salvar} style={{ padding: "12px 28px", fontSize: 14 }}>Salvar Taxas</button>
      </div>

      <div className="card">
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Simulador de Retorno Líquido</div>
        <table className="table">
          <thead>
            <tr>
              <th>Valor da Venda</th>
              <th>Dinheiro (0%)</th>
              <th>PIX ({taxas.pix}%)</th>
              <th>Crédito ({taxas.credito}%)</th>
              <th>Débito ({taxas.debito}%)</th>
            </tr>
          </thead>
          <tbody>
            {exemplos.map((v) => (
              <tr key={v}>
                <td style={{ fontWeight: 600, color: "#e8eaf0" }}>{fmt(v)}</td>
                <td style={{ color: "#f0b429", fontWeight: 600 }}>{fmt(v)}</td>
                <td style={{ color: "#22c97a", fontWeight: 600 }}>{fmt(v * (1 - Number(taxas.pix) / 100))}</td>
                <td style={{ color: "#4f8ef7", fontWeight: 600 }}>{fmt(v * (1 - Number(taxas.credito) / 100))}</td>
                <td style={{ color: "#b57cf7", fontWeight: 600 }}>{fmt(v * (1 - Number(taxas.debito) / 100))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Auto-render para Netlify / hospedagem estática ────────────────
// Quando carregado via <script type="text/babel"> no index.html,
// renderiza automaticamente no #root. No Claude.ai artifacts, o
// elemento #root não existe e este bloco é ignorado com segurança.
(function () {
  if (typeof document === "undefined") return;
  const rootEl = document.getElementById("root");
  if (!rootEl) return;
  try {
    if (typeof ReactDOM !== "undefined" && ReactDOM.createRoot) {
      ReactDOM.createRoot(rootEl).render(React.createElement(PDV));
    } else if (typeof ReactDOM !== "undefined") {
      ReactDOM.render(React.createElement(PDV), rootEl);
    }
  } catch (e) {
    console.error("[PDV] Erro ao montar app:", e);
  }
})();
